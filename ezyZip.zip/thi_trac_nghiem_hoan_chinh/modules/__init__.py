"""
Gói modules chứa các module nghiệp vụ của chương trình thi trắc nghiệm.

Nhiệm vụ chính:
- Đánh dấu thư mục modules là một package Python để các file khác có thể import
  bằng dạng modules.exam, modules.file_manager, modules.models,...

File này thuộc phần:
- Hạ tầng import của dự án, không chứa logic nghiệp vụ.

File này import:
- Không import module nào.

File này được gọi hoặc sử dụng bởi:
- Python import system khi main.py, app_gui.py hoặc các module khác import
  thành phần bên trong thư mục modules.

Các lớp và hàm chính:
- Không có lớp hoặc hàm.

Dữ liệu đi vào và đi ra:
- Không nhận dữ liệu và không trả dữ liệu. File chỉ giúp Python nhận diện package.

Quan hệ với các file còn lại:
- Các file trong dự án import qua namespace modules.* nhờ sự tồn tại của file này.
"""


