"""
Module cài đặt cấu trúc dữ liệu danh sách liên kết đơn.

Nhiệm vụ chính:
- Cung cấp lớp Node để lưu một phần tử và liên kết đến phần tử kế tiếp.
- Cung cấp lớp LinkedList để lưu nhiều đối tượng theo thứ tự.
- Hỗ trợ các thao tác append, truy cập theo chỉ số, xóa theo chỉ số,
  tìm kiếm tuần tự, đổi chỗ hai phần tử, sao chép nông và duyệt bằng for.

Module được gọi bởi:
- modules.file_manager để lưu danh sách Question và ExamResult đọc từ file.
- modules.exam để lưu chủ đề, câu hỏi đủ điều kiện, đề thi và bộ đếm điểm.
- modules.results để lưu kết quả lọc theo từ khóa.
- app_gui.py để lưu lựa chọn chủ đề, nút câu hỏi và dữ liệu giao diện.
- modules.text_utils để trả về danh sách trường sau khi tách một dòng text.

Module sử dụng:
- Không import module nào. Đây là cấu trúc dữ liệu tự cài đặt của dự án.

Dữ liệu đi vào:
- Bất kỳ đối tượng Python nào mà chương trình cần lưu tuần tự:
  Question, ExamResult, AnswerOption, chuỗi, số hoặc widget Tkinter.

Dữ liệu đi ra:
- Dữ liệu được lấy qua get(), __getitem__(), __iter__(), remove_at()
  hoặc qua các thao tác duyệt tuần tự.

Quan hệ với các file còn lại:
- Các module khác không dùng list có sẵn cho dữ liệu chính, mà dùng LinkedList
  để đáp ứng yêu cầu môn học về cấu trúc dữ liệu tự cài đặt.

Nên đọc file này như thế nào:
1. Đọc class Node trước để hiểu mỗi mắt xích chứa data và next.
2. Đọc LinkedList.__init__() để hiểu danh sách rỗng.
3. Đọc append(), __iter__(), get() vì đây là các thao tác được dùng nhiều nhất.
4. Đọc swap() sau cùng nếu muốn hiểu thuật toán xáo trộn Fisher-Yates.
"""


class Node:
    """
    Đại diện cho một mắt xích trong danh sách liên kết đơn.

    Vì sao cần lớp này:
    - LinkedList không lưu phần tử liên tiếp như list có sẵn.
    - Mỗi Node giữ một phần dữ liệu và địa chỉ của Node kế tiếp.

    Thuộc tính:
    - data: object, dữ liệu thật được lưu trong node. Dữ liệu này có thể là
      Question, ExamResult, AnswerOption, chuỗi, số hoặc widget.
    - next: Node hoặc None, tham chiếu đến node đứng sau node hiện tại.
      Nếu next là None thì node hiện tại là node cuối danh sách.

    Đối tượng được tạo ở:
    - LinkedList.append().

    Quan hệ với LinkedList:
    - LinkedList.head trỏ đến Node đầu tiên.
    - LinkedList.tail trỏ đến Node cuối cùng.
    - Khi duyệt, biến current đi từ head sang các node kế tiếp bằng current.next.
    """

    def __init__(self, data):
        """
        Khởi tạo một node mới chứa dữ liệu.

        Hàm được gọi bởi:
        - LinkedList.append().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            data:
                object, dữ liệu cần lưu trong node.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Gán data cho node mới và đặt next là None vì node mới chưa nối
            với node nào phía sau.

        Vị trí trong luồng hoạt động:
            Mỗi khi chương trình thêm một câu hỏi, kết quả hoặc giá trị trung gian
            vào LinkedList, append() sẽ tạo Node trước rồi mới nối vào danh sách.
        """

        # data là phần dữ liệu thật. Node chỉ bọc dữ liệu để có thể nối với Node khác.
        self.data = data

        # next trỏ đến node kế tiếp. Khi mới tạo, node chưa có phần tử đứng sau.
        self.next = None


class LinkedList:
    """
    Danh sách liên kết đơn do dự án tự cài đặt.

    Vì sao cần lớp này:
    - Đề tài yêu cầu tiếp tục dùng cấu trúc dữ liệu tự cài đặt thay vì list có sẵn.
    - LinkedList giúp lưu dữ liệu theo thứ tự và duyệt tuần tự trong toàn bộ dự án.

    Thuộc tính:
    - head: Node hoặc None, node đầu tiên. Nếu head là None thì danh sách rỗng.
    - tail: Node hoặc None, node cuối cùng. tail giúp append nhanh hơn vì không
      phải duyệt từ đầu đến cuối mỗi lần thêm.
    - _size: int, số phần tử đang có trong danh sách.

    Phương thức quan trọng:
    - append(): thêm phần tử vào cuối, độ phức tạp O(1) nhờ tail.
    - get() / __getitem__(): lấy phần tử theo vị trí, độ phức tạp O(n)
      vì phải duyệt từ head.
    - remove_at(): xóa phần tử theo vị trí, độ phức tạp O(n).
    - contains(): tìm kiếm tuần tự, độ phức tạp O(n).
    - swap(): đổi dữ liệu của hai node, dùng trong Fisher-Yates.
    - copy_shallow(): sao chép danh sách node nhưng giữ cùng đối tượng data.
    - __iter__(): cho phép duyệt bằng for.

    Đối tượng được tạo ở:
    - modules.file_manager.load_questions(), load_results().
    - modules.exam trong nhiều bước lọc, chọn và chấm điểm.
    - app_gui.py trong phần giao diện và đề thi.

    Dữ liệu được truyền sang:
    - modules.random_utils.shuffle() để xáo trộn.
    - modules.exam.generate_exam(), calculate_exam_counts().
    - modules.results.show_results().
    """

    def __init__(self):
        """
        Tạo một danh sách liên kết rỗng.

        Hàm được gọi bởi:
        - Mọi nơi cần tạo LinkedList mới trong dự án.

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Gán trạng thái ban đầu cho danh sách hiện tại.

        Trường hợp đặc biệt:
            Danh sách rỗng được biểu diễn bằng head = None, tail = None,
            _size = 0.
        """

        # head lưu node đầu tiên. None nghĩa là chưa có phần tử nào.
        self.head = None

        # tail lưu node cuối cùng để thêm vào cuối danh sách nhanh hơn.
        self.tail = None

        # _size đếm số phần tử, giúp len(linked_list) trả kết quả O(1).
        self._size = 0

    def append(self, data):
        """
        Thêm một phần tử vào cuối LinkedList.

        Hàm được gọi bởi:
        - file_manager khi đọc câu hỏi/kết quả từ file.
        - exam khi tạo danh sách chủ đề, câu hỏi đủ điều kiện và đề thi.
        - text_utils khi tách các trường của một dòng dữ liệu.
        - app_gui khi gom widget hoặc lựa chọn giao diện.

        Hàm gọi:
        - Node() để bọc dữ liệu vào một node mới.

        Tham số:
            data:
                object, dữ liệu cần thêm vào cuối danh sách.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Thay đổi head/tail/_size của LinkedList hiện tại.

        Trường hợp đặc biệt:
            Nếu danh sách đang rỗng, node mới vừa là head vừa là tail.

        Vị trí trong luồng hoạt động:
            Đây là thao tác nền cho việc xây dựng danh sách câu hỏi, đề thi
            và danh sách kết quả.
        """

        # new_node là node mới chứa data. Node mới chưa trỏ đến phần tử nào phía sau.
        new_node = Node(data)

        if self.head is None:
            # Danh sách rỗng: phần tử đầu tiên cũng là phần tử cuối cùng.
            self.head = new_node
            self.tail = new_node
        else:
            # Danh sách đã có phần tử: nối node cuối cũ sang node mới,
            # rồi cập nhật tail để tail luôn trỏ đến node cuối hiện tại.
            self.tail.next = new_node
            self.tail = new_node

        self._size += 1

    def get(self, index):
        """
        Lấy dữ liệu tại vị trí index.

        Hàm được gọi bởi:
        - __getitem__() khi dùng cú pháp linked_list[index].
        - Các module khác gián tiếp thông qua cú pháp [].

        Hàm gọi:
        - _get_node() để tìm node tại vị trí cần lấy.

        Tham số:
            index:
                int, vị trí cần lấy, bắt đầu từ 0.

        Trả về:
            object, dữ liệu nằm trong node tại vị trí index.

        Trường hợp đặc biệt:
            _get_node() sẽ báo IndexError nếu index nằm ngoài phạm vi.

        Độ phức tạp:
            O(n) vì phải duyệt tuần tự từ head đến vị trí cần lấy.
        """

        return self._get_node(index).data

    def remove_at(self, index):
        """
        Xóa phần tử tại vị trí index và trả về dữ liệu bị xóa.

        Hàm được gọi bởi:
        - Hiện tại không còn luồng thí sinh nào gọi trực tiếp.
        - Phương thức vẫn được giữ vì là thao tác cơ bản của LinkedList tự cài đặt.

        Hàm gọi:
        - _get_node() để tìm node đứng trước node cần xóa khi index > 0.

        Tham số:
            index:
                int, vị trí phần tử cần xóa, bắt đầu từ 0.

        Trả về:
            object, dữ liệu được lưu trong node bị xóa.

        Dữ liệu bị thay đổi:
            Thay đổi liên kết next, head, tail và _size của danh sách hiện tại.

        Trường hợp đặc biệt:
            - Nếu index không hợp lệ, hàm ném IndexError.
            - Nếu xóa phần tử đầu tiên, head phải trỏ sang node kế tiếp.
            - Nếu xóa phần tử cuối cùng, tail phải được cập nhật.
        """

        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số xóa nằm ngoài phạm vi danh sách.")

        if index == 0:
            # removed_node là node đầu cũ. Sau khi xóa, head đi sang node kế tiếp.
            removed_node = self.head
            self.head = self.head.next
            self._size -= 1

            if self._size == 0:
                # Nếu vừa xóa phần tử duy nhất, danh sách quay về trạng thái rỗng.
                self.tail = None

            return removed_node.data

        # previous là node đứng ngay trước node cần xóa.
        previous = self._get_node(index - 1)
        removed_node = previous.next

        # Bỏ qua removed_node bằng cách nối previous sang node sau removed_node.
        previous.next = removed_node.next

        if removed_node is self.tail:
            # Nếu xóa node cuối, node trước đó trở thành tail mới.
            self.tail = previous

        self._size -= 1
        return removed_node.data

    def contains(self, item):
        """
        Kiểm tra một giá trị có nằm trong LinkedList hay không bằng tìm kiếm tuần tự.

        Hàm được gọi bởi:
        - __contains__() khi dùng cú pháp item in linked_list.

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            item:
                object, giá trị cần tìm.

        Trả về:
            bool, True nếu tìm thấy, False nếu duyệt hết danh sách mà không thấy.

        Dữ liệu bị thay đổi:
            Không thay đổi danh sách.

        Độ phức tạp:
            O(n), vì trong trường hợp xấu nhất phải đi qua toàn bộ node.
        """

        # current trỏ đến node đang được kiểm tra. Bắt đầu từ head.
        current = self.head

        while current is not None:
            if current.data == item:
                return True

            # Đi sang node kế tiếp. Khi current thành None nghĩa là đã qua tail.
            current = current.next

        return False

    def swap(self, first_index, second_index):
        """
        Đổi chỗ dữ liệu của hai node trong danh sách.

        Hàm được gọi bởi:
        - modules.random_utils.shuffle() trong thuật toán Fisher-Yates.

        Hàm gọi:
        - _get_node() hai lần để lấy hai node cần đổi dữ liệu.

        Tham số:
            first_index:
                int, vị trí thứ nhất.
            second_index:
                int, vị trí thứ hai.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Chỉ đổi thuộc tính data giữa hai node, không đổi liên kết next.

        Lưu ý:
            Đổi data thay vì đổi node giúp thao tác đơn giản hơn và vẫn giữ
            đúng số phần tử, không tạo trùng và không làm mất phần tử.
        """

        if first_index == second_index:
            return

        first_node = self._get_node(first_index)
        second_node = self._get_node(second_index)

        # temporary giữ tạm dữ liệu của node thứ nhất để không bị mất khi gán đè.
        temporary = first_node.data
        first_node.data = second_node.data
        second_node.data = temporary

    def copy_shallow(self):
        """
        Tạo một LinkedList mới chứa cùng dữ liệu với danh sách hiện tại.

        Hàm được gọi bởi:
        - modules.exam.generate_exam() trước khi xáo trộn danh sách ứng viên.
        - app_gui.py khi truyền toàn bộ chủ đề đang có sang bước lọc trong kiểm thử.

        Hàm gọi:
        - LinkedList() để tạo danh sách mới.
        - append() để thêm từng phần tử.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            LinkedList mới.

        Dữ liệu bị thay đổi:
            Không thay đổi danh sách gốc.

        Lưu ý:
            Đây là sao chép nông: node mới được tạo, nhưng data bên trong vẫn là
            cùng đối tượng. Vì vậy generate_exam() tiếp tục clone từng Question
            trước khi xáo trộn đáp án.
        """

        copied = LinkedList()

        # current duyệt từ head của danh sách gốc sang tail.
        current = self.head

        while current is not None:
            copied.append(current.data)
            current = current.next

        return copied

    def _get_node(self, index):
        """
        Tìm và trả về node tại vị trí index.

        Hàm được gọi bởi:
        - get().
        - remove_at().
        - swap().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            index:
                int, vị trí node cần lấy.

        Trả về:
            Node tại vị trí index.

        Trường hợp đặc biệt:
            Nếu index âm hoặc lớn hơn/vượt bằng _size, hàm ném IndexError.

        Vị trí trong luồng hoạt động:
            Đây là hàm nội bộ giúp các thao tác theo chỉ số hoạt động trên
            LinkedList vốn chỉ có liên kết một chiều.
        """

        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số truy cập nằm ngoài phạm vi danh sách.")

        # current là node đang đứng trong quá trình duyệt.
        current = self.head

        # current_index là vị trí của current, dùng để biết khi nào đến index.
        current_index = 0

        while current_index < index:
            current = current.next
            current_index += 1

        return current

    def __len__(self):
        """
        Trả về số phần tử trong LinkedList.

        Hàm được gọi bởi:
        - len(linked_list) trong toàn bộ dự án.

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Trả về:
            int, giá trị _size hiện tại.

        Độ phức tạp:
            O(1) vì _size luôn được cập nhật khi thêm hoặc xóa.
        """

        return self._size

    def __iter__(self):
        """
        Cho phép duyệt LinkedList bằng vòng lặp for.

        Hàm được gọi bởi:
        - Mọi câu lệnh dạng for item in linked_list trong dự án.

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Trả về:
            Iterator sinh lần lượt data của từng node.

        Dữ liệu bị thay đổi:
            Không thay đổi danh sách.

        Cách hoạt động:
            Bắt đầu từ head, trả ra data của node hiện tại, rồi đi sang next
            cho đến khi current bằng None.
        """

        current = self.head

        while current is not None:
            yield current.data
            current = current.next

    def __getitem__(self, index):
        """
        Cho phép dùng cú pháp linked_list[index].

        Hàm được gọi bởi:
        - Các đoạn mã lấy câu hỏi, phương án hoặc kết quả theo vị trí.

        Hàm gọi:
        - get().

        Tham số:
            index:
                int, vị trí cần truy cập.

        Trả về:
            object, dữ liệu tại vị trí index.
        """

        return self.get(index)

    def __contains__(self, item):
        """
        Cho phép dùng cú pháp item in linked_list.

        Hàm được gọi bởi:
        - Bất kỳ nơi nào kiểm tra phần tử bằng toán tử in.

        Hàm gọi:
        - contains().

        Tham số:
            item:
                object, dữ liệu cần tìm.

        Trả về:
            bool, kết quả tìm kiếm tuần tự.
        """

        return self.contains(item)


# ============================================================
# SƠ ĐỒ CẤU TRÚC LINKEDLIST
#
# LinkedList
# ├── head ──► Node(data) ──► Node(data) ──► ... ──► None
# ├── tail ────────────────────────────────▲
# └── _size = số phần tử hiện có
#
# Thêm phần tử:
# append(data)
# ├── Node(data)
# ├── nếu danh sách rỗng: head = tail = new_node
# └── nếu đã có phần tử: tail.next = new_node, tail = new_node
#
# Duyệt danh sách:
# current = head
# while current is not None:
#     xử lý current.data
#     current = current.next
#
# Truy cập theo chỉ số:
# linked_list[index]
# └── __getitem__() -> get() -> _get_node(index)
#
# Xáo trộn:
# modules.random_utils.shuffle()
# └── linked_list.swap(i, j)
#
# Ghi nhớ:
# - Node là hộp chứa dữ liệu và đường dẫn sang node sau.
# - data là dữ liệu thật; node chỉ là cách nối dữ liệu lại với nhau.
# - head/tail là con trỏ quản lý danh sách, không phải dữ liệu câu hỏi.
# ============================================================
