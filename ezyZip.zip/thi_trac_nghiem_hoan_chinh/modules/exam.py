import time
from datetime import datetime

from modules.file_manager import (
    append_result,
    load_questions,
    load_results,
    next_exam_id,
)
from modules.linked_list import LinkedList
from modules.models import AnswerOption, ExamResult
from modules.random_utils import shuffle
from modules.text_utils import format_seconds


DIFFICULTY_ALL = "ALL"


def contains_subject(subjects, subject):


    for existing_subject in subjects:
        if existing_subject.lower() == subject.lower():
            return True

    return False


def get_unique_subjects(questions):


    subjects = LinkedList()

    for question in questions:
        if not contains_subject(subjects, question.subject):
            subjects.append(question.subject)

    return subjects


def choose_one_subject(available_subjects):


    print("\n========== CHỌN MÔN ==========")


    index = 1

    for subject in available_subjects:
        print(f"{index}. {subject}")
        index += 1

    selected_index = int(input("Chọn môn: ").strip()) - 1
    return available_subjects[selected_index]


def get_unique_topics_by_subject(questions, selected_subject):


    topics = LinkedList()

    for question in questions:
        if question.subject.lower() == selected_subject.lower():
            if not contains_subject(topics, question.topic):
                topics.append(question.topic)

    return topics


def choose_topics(available_topics):


    print("\n========== CHỌN CHỦ ĐỀ ==========")


    index = 1

    for topic in available_topics:
        print(f"{index}. {topic}")
        index += 1

    raw_choices = input(
        "Nhập các số muốn chọn, cách nhau bởi dấu cách (ví dụ 1 3): "
    )


    selected_topics = LinkedList()


    current_choice = ""

    for character in raw_choices + " ":
        if character.isspace():
            if current_choice != "":
                selected_index = int(current_choice) - 1
                selected_topic = available_topics[selected_index]

                if not contains_subject(selected_topics, selected_topic):
                    selected_topics.append(selected_topic)

                current_choice = ""
        else:
            current_choice += character

    return selected_topics


def collect_eligible_questions(questions, selected_subject, selected_topics, difficulty):


    eligible = LinkedList()

    for question in questions:
        subject_match = question.subject.lower() == selected_subject.lower()
        topic_match = contains_subject(selected_topics, question.topic)
        difficulty_match = (
            difficulty == DIFFICULTY_ALL or question.difficulty == difficulty
        )

        if subject_match and topic_match and difficulty_match:
            eligible.append(question)

    return eligible


def exam_scope_to_text(subject, topics):


    result = subject + " - "


    index = 0

    for topic in topics:
        if index > 0:
            result += ", "
        result += topic
        index += 1

    return result


def shuffle_question_options(question):


    options = LinkedList()
    options.append(AnswerOption(question.option_a, question.correct_answer == "A"))
    options.append(AnswerOption(question.option_b, question.correct_answer == "B"))
    options.append(AnswerOption(question.option_c, question.correct_answer == "C"))
    options.append(AnswerOption(question.option_d, question.correct_answer == "D"))


    shuffle(options)


    question.option_a = options[0].text
    question.option_b = options[1].text
    question.option_c = options[2].text
    question.option_d = options[3].text


    if options[0].is_correct:
        question.correct_answer = "A"
    elif options[1].is_correct:
        question.correct_answer = "B"
    elif options[2].is_correct:
        question.correct_answer = "C"
    else:
        question.correct_answer = "D"


def generate_exam(eligible_questions, number_of_questions):


    shuffled_candidates = eligible_questions.copy_shallow()
    shuffle(shuffled_candidates)

    exam_questions = LinkedList()


    index = 0

    if number_of_questions > len(shuffled_candidates):
        number_of_questions = len(shuffled_candidates)

    while index < number_of_questions:


        exam_question = shuffled_candidates[index].clone()
        shuffle_question_options(exam_question)
        exam_questions.append(exam_question)
        index += 1

    return exam_questions


def display_question_progress(exam_questions, current_index):


    progress_line = ""


    index = 0

    for question in exam_questions:
        if question.is_answered:
            symbol = "✓"
        elif question.is_skipped:
            symbol = "×"
        else:
            symbol = "•"

        number = index + 1

        if index == current_index:
            progress_line += f"[{number}{symbol}] "
        else:
            progress_line += f" {number}{symbol}  "

        index += 1

    print("Tiến độ:", progress_line.strip())


def display_exam_question(question, current_index, total, remaining_seconds):


    print("\n" + "=" * 72)
    print(
        f"CÂU {current_index + 1}/{total} | "
        f"Môn: {question.subject} | "
        f"Chủ đề: {question.topic} | "
        f"Còn lại: {format_seconds(remaining_seconds)}"
    )
    print("-" * 72)
    print(question.content)
    print(f"A. {question.option_a}")
    print(f"B. {question.option_b}")
    print(f"C. {question.option_c}")
    print(f"D. {question.option_d}")

    if question.is_answered:
        print(f"Đáp án đã chọn: {question.user_answer}")
    elif question.is_skipped:
        print("Câu này: đã đánh dấu bỏ qua")


def run_exam_session(exam_questions, limit_seconds):


    try:
        from inputimeout import TimeoutOccurred, inputimeout
    except ImportError:
        print("Chưa cài thư viện inputimeout. Hãy chạy file cai_thu_vien.bat trước.")
        return None


    start_time = time.monotonic()


    deadline = start_time + limit_seconds


    current_index = 0

    while True:


        remaining = deadline - time.monotonic()

        if remaining <= 0:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break

        current_question = exam_questions[current_index]
        display_exam_question(
            current_question,
            current_index,
            len(exam_questions),
            remaining,
        )
        display_question_progress(exam_questions, current_index)
        print("Lệnh: A/B/C/D = trả lời | N = tiếp | P = trước | S = bỏ qua | Q = nộp")

        try:
            command = inputimeout(
                prompt="Nhập lựa chọn: ",
                timeout=max(0.1, remaining),
            ).strip().upper()
        except TimeoutOccurred:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break


        if time.monotonic() >= deadline:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break

        if command == "A" or command == "B" or command == "C" or command == "D":

            current_question.user_answer = command
            current_question.is_answered = True
            current_question.is_skipped = False

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "N":
            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("Bạn đang ở câu cuối cùng.")
        elif command == "P":
            if current_index > 0:
                current_index -= 1
            else:
                print("Bạn đang ở câu đầu tiên.")
        elif command == "S":
            current_question.user_answer = ""
            current_question.is_answered = False
            current_question.is_skipped = True

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "Q":
            remaining = deadline - time.monotonic()

            try:
                confirmation = inputimeout(
                    prompt="Xác nhận nộp bài? (Y/N): ",
                    timeout=max(0.1, remaining),
                ).strip().upper()
            except TimeoutOccurred:
                print("\nĐã hết giờ. Bài làm được kết thúc.")
                break

            if confirmation == "Y":
                break
        else:
            print("Lệnh không hợp lệ. Vui lòng nhập lại.")


    used_seconds = int(time.monotonic() - start_time)

    if used_seconds > limit_seconds:
        used_seconds = limit_seconds

    return used_seconds


def calculate_exam_counts(exam_questions):


    correct_count = 0
    wrong_count = 0

    for question in exam_questions:
        if question.user_answer == "":
            wrong_count += 1
        elif question.user_answer == question.correct_answer:
            correct_count += 1
        else:
            wrong_count += 1

    counts = LinkedList()
    counts.append(correct_count)
    counts.append(wrong_count)
    return counts


def show_exam_review(exam_questions):


    print("\n========== ĐỐI CHIẾU ĐÁP ÁN ==========")


    index = 1

    for question in exam_questions:
        user_answer = question.user_answer

        if user_answer == "":
            user_answer = "Bỏ qua"

        if question.user_answer == question.correct_answer:
            review_result = "ĐÚNG"
        else:
            review_result = "SAI"
        print("-" * 72)
        print(f"Câu {index}: {question.content}")
        print(f"Bạn chọn: {user_answer}")
        print(f"Đáp án đúng: {question.correct_answer}")
        print(f"Kết quả: {review_result}")
        index += 1


def start_exam():


    questions = load_questions()

    if len(questions) == 0:
        print("Không có câu hỏi trong hệ thống.")
        return


    print("\n========== THÔNG TIN THÍ SINH ==========")
    candidate_id = input("Nhập mã thí sinh: ").strip()
    candidate_name = input("Nhập họ và tên: ").strip()


    available_subjects = get_unique_subjects(questions)
    selected_subject = choose_one_subject(available_subjects)


    available_topics = get_unique_topics_by_subject(questions, selected_subject)
    selected_topics = choose_topics(available_topics)

    if len(selected_topics) == 0:
        print("Bạn chưa chọn chủ đề nào.")
        return

    print("\n========== CHỌN ĐỘ KHÓ ==========")
    print("1. Dễ")
    print("2. Khó")
    print("3. Dễ và Khó")
    difficulty_choice = input("Chọn độ khó: ").strip()

    if difficulty_choice == "1":
        difficulty = "DE"
    elif difficulty_choice == "2":
        difficulty = "KHO"
    else:
        difficulty = DIFFICULTY_ALL


    eligible_questions = collect_eligible_questions(
        questions, selected_subject, selected_topics, difficulty
    )

    if len(eligible_questions) == 0:
        print("Không có câu hỏi phù hợp.")
        return

    print(f"Số câu phù hợp hiện có: {len(eligible_questions)}")

    number_of_questions = int(input("Nhập số lượng câu hỏi của đề: ").strip())

    minutes = int(input("Nhập thời gian làm bài (phút): ").strip())

    if number_of_questions <= 0 or minutes <= 0:
        print("Số câu hỏi và thời gian làm bài phải lớn hơn 0.")
        return

    if number_of_questions > len(eligible_questions):
        print("Số câu yêu cầu lớn hơn số câu hiện có, hệ thống sẽ dùng toàn bộ câu phù hợp.")

    limit_seconds = minutes * 60


    exam_questions = generate_exam(
        eligible_questions,
        number_of_questions,
    )

    input("Nhấn Enter để bắt đầu làm bài")


    used_seconds = run_exam_session(exam_questions, limit_seconds)

    if used_seconds is None:
        return


    counts = calculate_exam_counts(exam_questions)
    correct_count = counts[0]
    wrong_count = counts[1]


    score_ten = correct_count * 10.0 / len(exam_questions)


    previous_results = load_results()
    result = ExamResult(
        next_exam_id(previous_results),
        candidate_id,
        candidate_name,
        datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        exam_scope_to_text(selected_subject, selected_topics),
        len(exam_questions),
        correct_count,
        wrong_count,
        score_ten,
        limit_seconds,
        used_seconds,
    )
    append_result(result)


    print("\n========== KẾT QUẢ BÀI THI ==========")
    print(f"Số câu đúng  : {correct_count}")
    print(f"Số câu sai   : {wrong_count}")
    print(f"Điểm hệ 10   : {score_ten:.2f}")
    print(f"Thời gian dùng: {format_seconds(used_seconds)}")

    review_choice = input("Bạn có muốn xem đáp án chi tiết? (Y/N): ").strip().upper()

    if review_choice == "Y":
        show_exam_review(exam_questions)
