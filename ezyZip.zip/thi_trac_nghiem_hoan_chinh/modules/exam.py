
"""
Module tổ chức toàn bộ quá trình thi trắc nghiệm ở phần console.

Nên đọc file này như thế nào:
1. Đọc start_exam() trước để thấy luồng lớn từ lúc đọc câu hỏi đến lúc lưu kết quả.
2. Khi start_exam() gọi hàm nào thì quay lên đọc hàm đó:
   get_unique_subjects(), choose_subjects(), collect_eligible_questions(),
   generate_exam(), run_exam_session(), calculate_exam_counts().
3. Đọc shuffle_question_options() sau generate_exam() để hiểu đáp án đúng được cập nhật
   như thế nào sau khi xáo trộn.

Nhiệm vụ chính:
- Nhận thông tin thí sinh và cấu hình đề thi từ console.
- Lọc câu hỏi theo chủ đề và mức độ.
- Sinh đề bằng cách chọn ngẫu nhiên câu hỏi không trùng.
- Xáo trộn đáp án của từng câu và cập nhật lại đáp án đúng.
- Tổ chức phiên làm bài có giới hạn thời gian.
- Chấm điểm, tính đúng/sai và lưu kết quả.

Module được gọi bởi:
- main.py khi thí sinh chọn "Bắt đầu thi".
- app_gui.py cũng dùng một số hàm chung như generate_exam() và calculate_exam_counts().

Module sử dụng:
- modules.file_manager để đọc câu hỏi, đọc lịch sử và ghi kết quả.
- modules.linked_list.LinkedList để lưu chủ đề, câu hỏi, đề thi và bộ đếm.
- modules.models.AnswerOption và ExamResult để biểu diễn đáp án tạm và kết quả thi.
- modules.random_utils.shuffle để xáo trộn câu hỏi/đáp án.
- modules.text_utils.format_seconds để hiển thị thời gian.

Dữ liệu đi vào:
- DATA/questions.txt thông qua load_questions().
- Thông tin thí sinh, chủ đề, độ khó, số câu và thời gian nhập từ console.

Dữ liệu đi ra:
- ExamResult được append_result() ghi vào DATA/results.txt.
- Thông tin câu hỏi, thời gian, tiến độ và kết quả được in ra console.

Luồng dữ liệu ngắn gọn:
DATA/questions.txt -> load_questions() -> LinkedList<Question>
-> collect_eligible_questions() -> generate_exam()
-> run_exam_session() -> calculate_exam_counts()
-> ExamResult -> append_result() -> DATA/results.txt.
"""

import time
from datetime import datetime

from modules.file_manager import (
    append_result,
    load_questions,
    load_results,
    next_exam_id,
)
from modules.linked_list import LinkedList
from modules.models import AnswerOption, ExamResult
from modules.random_utils import shuffle
from modules.text_utils import format_seconds


DIFFICULTY_ALL = "ALL"


def contains_subject(subjects, subject):
    """
    Kiểm tra một chủ đề đã có trong LinkedList chủ đề hay chưa.

    Hàm được gọi bởi:
    - get_unique_subjects() để tránh thêm trùng chủ đề.
    - choose_subjects() để tránh chọn trùng chủ đề khi người dùng nhập lặp số.
    - collect_eligible_questions() để kiểm tra câu hỏi thuộc chủ đề đã chọn.

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        subjects:
            LinkedList chứa các chuỗi chủ đề.
        subject:
            str, chủ đề cần kiểm tra.

    Trả về:
        bool, True nếu subject đã tồn tại trong subjects, False nếu chưa.
    """
    for existing_subject in subjects:
        if existing_subject.lower() == subject.lower():
            return True

    return False


def get_unique_subjects(questions):
    """
    Lấy danh sách chủ đề không trùng từ ngân hàng câu hỏi.

    Hàm được gọi bởi:
    - start_exam() trong console.
    - app_gui.QuizApplication.show_exam_setup_screen().

    Hàm gọi:
    - LinkedList() để tạo danh sách chủ đề.
    - contains_subject() để kiểm tra trùng.
    - LinkedList.append() để thêm chủ đề mới.

    Tham số:
        questions:
            LinkedList<Question>, toàn bộ câu hỏi đọc từ DATA/questions.txt.

    Trả về:
        LinkedList chứa các chuỗi chủ đề duy nhất.

    """

    # subjects là danh sách chủ đề duy nhất, khác với selected_subjects
    # là danh sách chủ đề thí sinh chọn cho một lần thi cụ thể.
    subjects = LinkedList()

    for question in questions:
        if not contains_subject(subjects, question.subject):
            subjects.append(question.subject)

    return subjects


def choose_subjects(available_subjects):
    """
    Nhận lựa chọn chủ đề từ người dùng console.

    Hàm được gọi bởi:
    - start_exam().

    Hàm gọi:
    - LinkedList() để lưu chủ đề đã chọn.
    - contains_subject() để tránh chọn trùng.
    - LinkedList.append() để thêm chủ đề.

    Tham số:
        available_subjects:
            LinkedList chứa các chủ đề có trong ngân hàng câu hỏi.

    Trả về:
        LinkedList chứa các chủ đề người dùng đã chọn.

    """

    print("\n========== CHỌN MÔN/CHỦ ĐỀ ==========")

    # index là số thứ tự hiển thị cho từng chủ đề trên màn hình.
    index = 1

    for subject in available_subjects:
        print(f"{index}. {subject}")
        index += 1

    raw_choices = input(
        "Nhập các số muốn chọn, cách nhau bởi dấu cách (ví dụ 1 3): "
    )

    # selected_subjects là các chủ đề thực sự được chọn để lọc câu hỏi.
    selected_subjects = LinkedList()

    # current_choice gom từng chữ số trong raw_choices cho đến khi gặp khoảng trắng.
    current_choice = ""

    for character in raw_choices + " ":
        if character.isspace():
            if current_choice != "":
                selected_index = int(current_choice) - 1
                selected_subject = available_subjects[selected_index]

                if not contains_subject(selected_subjects, selected_subject):
                    selected_subjects.append(selected_subject)

                current_choice = ""
        else:
            current_choice += character

    return selected_subjects


def collect_eligible_questions(questions, selected_subjects, difficulty):
    """
    Lọc câu hỏi phù hợp với chủ đề và mức độ đã chọn.

    Hàm được gọi bởi:
    - start_exam() trong console.
    - app_gui.QuizApplication.update_eligible_question_count().
    - app_gui.QuizApplication.begin_exam_from_setup().

    Hàm gọi:
    - LinkedList() để chứa câu hỏi phù hợp.
    - contains_subject() để kiểm tra chủ đề.
    - LinkedList.append() để thêm câu hỏi đạt điều kiện.

    Tham số:
        questions:
            LinkedList<Question>, ngân hàng câu hỏi gốc đọc từ file.
        selected_subjects:
            LinkedList<str>, các chủ đề thí sinh chọn.
        difficulty:
            str, "DE", "KHO" hoặc DIFFICULTY_ALL.

    Trả về:
        LinkedList<Question> chứa các câu hỏi phù hợp.
    """

    # eligible là danh sách ứng viên, chưa phải đề thi cuối cùng.
    eligible = LinkedList()

    for question in questions:
        subject_match = contains_subject(selected_subjects, question.subject)
        difficulty_match = (
            difficulty == DIFFICULTY_ALL or question.difficulty == difficulty
        )

        if subject_match and difficulty_match:
            eligible.append(question)

    return eligible


def subject_list_to_text(subjects):
    """
    Chuyển LinkedList chủ đề thành một chuỗi để lưu vào kết quả thi.

    Hàm được gọi bởi:
    - start_exam() khi tạo ExamResult.
    - app_gui.QuizApplication.submit_exam().

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        subjects:
            LinkedList<str>, các chủ đề trong đề thi.

    Trả về:
        str, chuỗi chủ đề phân tách bằng dấu phẩy.

    """

    result = ""

    # index dùng để biết khi nào cần thêm dấu phẩy trước chủ đề tiếp theo.
    index = 0

    for subject in subjects:
        if index > 0:
            result += ", "
        result += subject
        index += 1

    return result


def shuffle_question_options(question):
    """
    Xáo trộn bốn phương án trả lời của một câu hỏi trong đề thi.

    Hàm được gọi bởi:
    - generate_exam() sau khi clone một câu hỏi được chọn.

    Hàm gọi:
    - LinkedList() để lưu bốn AnswerOption tạm.
    - AnswerOption() để ghép nội dung phương án với cờ đúng/sai.
    - shuffle() để đảo thứ tự bốn phương án.

    Tham số:
        question:
            Question, bản sao câu hỏi dùng trong đề thi.

    Trả về:
        None. Hàm sửa trực tiếp các thuộc tính option_a/b/c/d và correct_answer
        của question.

    """

    # options chứa bốn phương án kèm thông tin phương án nào là đúng.
    options = LinkedList()
    options.append(AnswerOption(question.option_a, question.correct_answer == "A"))
    options.append(AnswerOption(question.option_b, question.correct_answer == "B"))
    options.append(AnswerOption(question.option_c, question.correct_answer == "C"))
    options.append(AnswerOption(question.option_d, question.correct_answer == "D"))

    # Xáo trộn nội dung phương án. Dấu is_correct đi cùng nội dung phương án.
    shuffle(options)

    # Gán lại nội dung A/B/C/D theo thứ tự mới.
    question.option_a = options[0].text
    question.option_b = options[1].text
    question.option_c = options[2].text
    question.option_d = options[3].text

    # Cập nhật ký hiệu đáp án đúng theo vị trí mới sau khi xáo trộn.
    if options[0].is_correct:
        question.correct_answer = "A"
    elif options[1].is_correct:
        question.correct_answer = "B"
    elif options[2].is_correct:
        question.correct_answer = "C"
    else:
        question.correct_answer = "D"


def generate_exam(eligible_questions, number_of_questions):
    """
    Sinh một đề thi từ danh sách câu hỏi phù hợp.

    Hàm được gọi bởi:
    - start_exam() trong console.
    - app_gui.QuizApplication.begin_exam_from_setup().

    Hàm gọi:
    - eligible_questions.copy_shallow() để không xáo trộn danh sách ứng viên gốc.
    - shuffle() để xáo trộn danh sách ứng viên trước khi chọn câu.
    - Question.clone() để tạo bản sao câu hỏi cho đề thi.
    - shuffle_question_options() để xáo trộn đáp án từng câu.
    - LinkedList.append() để thêm câu hỏi vào đề.

    Tham số:
        eligible_questions:
            LinkedList<Question>, các câu hỏi đã qua bước lọc.
        number_of_questions:
            int, số câu thí sinh yêu cầu.

    Trả về:
        LinkedList<Question> chứa đề thi đã chọn; thứ tự câu đã ngẫu nhiên vì
        được lấy từ shuffled_candidates sau khi danh sách này đã xáo trộn.
    """

    shuffled_candidates = eligible_questions.copy_shallow()
    shuffle(shuffled_candidates)

    exam_questions = LinkedList()

    # index là số câu đã lấy vào đề.
    index = 0

    if number_of_questions > len(shuffled_candidates):
        number_of_questions = len(shuffled_candidates)

    while index < number_of_questions:
        # exam_question là bản sao của câu hỏi gốc. Đáp án xáo trộn chỉ áp dụng
        # trên bản sao này để không làm thay đổi DATA/questions.txt.
        exam_question = shuffled_candidates[index].clone()
        shuffle_question_options(exam_question)
        exam_questions.append(exam_question)
        index += 1

    return exam_questions


def display_question_progress(exam_questions, current_index):
    """
    Hiển thị tiến độ đã trả lời/bỏ qua/chưa làm của các câu trong đề.

    Hàm được gọi bởi:
    - run_exam_session() sau khi in nội dung câu hiện tại.

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        exam_questions:
            LinkedList<Question>, đề thi đang làm.
        current_index:
            int, vị trí câu hiện tại trong đề, không phải question_id.

    Trả về:
        None.
    """

    # progress_line là chuỗi tóm tắt tiến độ của toàn bộ câu hỏi.
    progress_line = ""

    # index là vị trí câu trong đề, bắt đầu từ 0; number là số hiển thị bắt đầu từ 1.
    index = 0

    for question in exam_questions:
        if question.is_answered:
            symbol = "✓"
        elif question.is_skipped:
            symbol = "×"
        else:
            symbol = "•"

        number = index + 1

        if index == current_index:
            progress_line += f"[{number}{symbol}] "
        else:
            progress_line += f" {number}{symbol}  "

        index += 1

    print("Tiến độ:", progress_line.strip())


def display_exam_question(question, current_index, total, remaining_seconds):
    """
    In một câu hỏi và bốn phương án ra console.

    Hàm được gọi bởi:
    - run_exam_session() mỗi vòng lặp làm bài.

    Hàm gọi:
    - format_seconds() để hiển thị thời gian còn lại.

    Tham số:
        question:
            Question, câu đang được hiển thị.
        current_index:
            int, vị trí câu hiện tại trong đề.
        total:
            int, tổng số câu trong đề.
        remaining_seconds:
            float, thời gian còn lại tính bằng giây.

    Trả về:
        None.
    """

    print("\n" + "=" * 72)
    print(
        f"CÂU {current_index + 1}/{total} | "
        f"Môn: {question.subject} | "
        f"Còn lại: {format_seconds(remaining_seconds)}"
    )
    print("-" * 72)
    print(question.content)
    print(f"A. {question.option_a}")
    print(f"B. {question.option_b}")
    print(f"C. {question.option_c}")
    print(f"D. {question.option_d}")

    if question.is_answered:
        print(f"Đáp án đã chọn: {question.user_answer}")
    elif question.is_skipped:
        print("Câu này: đã đánh dấu bỏ qua")


def run_exam_session(exam_questions, limit_seconds):
    """
    Tổ chức phiên làm bài trên console và theo dõi thời gian.

    Hàm được gọi bởi:
    - start_exam() sau khi đề thi đã được sinh.

    Hàm gọi:
    - inputimeout.inputimeout() để đọc lệnh có giới hạn thời gian.
    - display_exam_question() để in câu hỏi hiện tại.
    - display_question_progress() để in tiến độ toàn đề.
    - time.monotonic() để tính thời gian đã dùng và còn lại.

    Tham số:
        exam_questions:
            LinkedList<Question>, đề thi đã chọn và xáo trộn.
        limit_seconds:
            int, tổng thời gian làm bài tính bằng giây.

    Trả về:
        int hoặc None, thời gian đã dùng tính bằng giây. None nghĩa là phiên thi
        không thể bắt đầu do thiếu thư viện nhập liệu có giới hạn thời gian.

    Dữ liệu bị thay đổi:
        Cập nhật user_answer, is_answered, is_skipped của từng Question trong đề.

    Cơ chế thời gian:
        - start_time lưu thời điểm bắt đầu bằng time.monotonic().
        - deadline = start_time + limit_seconds là thời điểm hết giờ.
        - remaining = deadline - time.monotonic() là thời gian còn lại.
        - Nếu remaining <= 0 hoặc inputimeout hết thời gian, phiên làm bài kết thúc.
    """

    try:
        from inputimeout import TimeoutOccurred, inputimeout
    except ImportError:
        print("Chưa cài thư viện inputimeout. Hãy chạy file cai_thu_vien.bat trước.")
        return None

    # start_time là mốc bắt đầu làm bài. time.monotonic() phù hợp để đo khoảng thời gian.
    start_time = time.monotonic()

    # deadline là thời điểm phải tự động kết thúc bài.
    deadline = start_time + limit_seconds

    # current_index là vị trí câu đang hiển thị trong đề thi.
    current_index = 0

    while True:
        # remaining khác với limit_seconds: limit_seconds là tổng thời gian,
        # remaining là thời gian còn lại ở thời điểm hiện tại.
        remaining = deadline - time.monotonic()

        if remaining <= 0:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break

        current_question = exam_questions[current_index]
        display_exam_question(
            current_question,
            current_index,
            len(exam_questions),
            remaining,
        )
        display_question_progress(exam_questions, current_index)
        print("Lệnh: A/B/C/D = trả lời | N = tiếp | P = trước | S = bỏ qua | Q = nộp")

        try:
            command = inputimeout(
                prompt="Nhập lựa chọn: ",
                timeout=max(0.1, remaining),
            ).strip().upper()
        except TimeoutOccurred:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break

        # Kiểm tra lại sau khi nhập để tránh trường hợp vừa nhập xong thì quá hạn.
        if time.monotonic() >= deadline:
            print("\nĐã hết giờ. Bài làm được kết thúc.")
            break

        if command == "A" or command == "B" or command == "C" or command == "D":
            # user_answer lưu ký hiệu A/B/C/D sau khi đáp án đã được xáo trộn.
            current_question.user_answer = command
            current_question.is_answered = True
            current_question.is_skipped = False

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "N":
            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("Bạn đang ở câu cuối cùng.")
        elif command == "P":
            if current_index > 0:
                current_index -= 1
            else:
                print("Bạn đang ở câu đầu tiên.")
        elif command == "S":
            current_question.user_answer = ""
            current_question.is_answered = False
            current_question.is_skipped = True

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "Q":
            remaining = deadline - time.monotonic()

            try:
                confirmation = inputimeout(
                    prompt="Xác nhận nộp bài? (Y/N): ",
                    timeout=max(0.1, remaining),
                ).strip().upper()
            except TimeoutOccurred:
                print("\nĐã hết giờ. Bài làm được kết thúc.")
                break

            if confirmation == "Y":
                break
        else:
            print("Lệnh không hợp lệ. Vui lòng nhập lại.")

    # used_seconds là thời gian đã dùng từ lúc bắt đầu đến khi nộp/kết thúc bài.
    used_seconds = int(time.monotonic() - start_time)

    if used_seconds > limit_seconds:
        used_seconds = limit_seconds

    return used_seconds


def calculate_exam_counts(exam_questions):
    """
    Đếm số câu đúng và sai trong một đề đã làm.

    Hàm được gọi bởi:
    - start_exam() sau khi phiên console kết thúc.
    - app_gui.QuizApplication.submit_exam() sau khi nộp bài trên GUI.

    Hàm gọi:
    - LinkedList() để đóng gói hai kết quả đếm.
    - LinkedList.append() để giữ cấu trúc hai số của dữ liệu kết quả.

    Tham số:
        exam_questions:
            LinkedList<Question>, đề thi đã có user_answer của thí sinh.

    Trả về:
        LinkedList gồm hai số nguyên:
        - vị trí 0: số câu đúng.
        - vị trí 1: số câu sai, bao gồm cả câu bỏ qua/chưa trả lời.
    """
    correct_count = 0
    wrong_count = 0

    for question in exam_questions:
        if question.user_answer == "":
            wrong_count += 1
        elif question.user_answer == question.correct_answer:
            correct_count += 1
        else:
            wrong_count += 1

    counts = LinkedList()
    counts.append(correct_count)
    counts.append(wrong_count)
    return counts


def show_exam_review(exam_questions):
    """
    Hiển thị đối chiếu đáp án sau khi thí sinh đã nộp bài.

    Hàm được gọi bởi:
    - start_exam() nếu người dùng console chọn xem đáp án chi tiết.

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        exam_questions:
            LinkedList<Question>, đề thi đã làm và đã chấm.

    Trả về:
        None.
    """

    print("\n========== ĐỐI CHIẾU ĐÁP ÁN ==========")

    # index là số thứ tự hiển thị của câu trong đề sau khi xáo trộn.
    index = 1

    for question in exam_questions:
        user_answer = question.user_answer

        if user_answer == "":
            user_answer = "Bỏ qua"

        if question.user_answer == question.correct_answer:
            review_result = "ĐÚNG"
        else:
            review_result = "SAI"
        print("-" * 72)
        print(f"Câu {index}: {question.content}")
        print(f"Bạn chọn: {user_answer}")
        print(f"Đáp án đúng: {question.correct_answer}")
        print(f"Kết quả: {review_result}")
        index += 1


def start_exam():
    """
    Điều phối toàn bộ quá trình làm bài thi trên console.

    Hàm được gọi bởi:
    - main.main() khi thí sinh chọn "Bắt đầu thi".

    Hàm gọi:
    - load_questions() để đọc ngân hàng câu hỏi.
    - get_unique_subjects() và choose_subjects() để lấy chủ đề.
    - collect_eligible_questions() để lọc câu hỏi phù hợp.
    - generate_exam() để chọn câu hỏi ngẫu nhiên không trùng và xáo trộn đáp án.
    - run_exam_session() để nhận câu trả lời có giới hạn thời gian và lấy thời gian đã dùng.
    - calculate_exam_counts() để chấm điểm.
    - load_results(), next_exam_id(), ExamResult() và append_result() để lưu kết quả.

    Tham số:
        Không có tham số. Dữ liệu đến từ file và từ nhập liệu console.

    Trả về:
        None.
    """

    # ============================================================
    # GIAI ĐOẠN 1: ĐỌC NGÂN HÀNG CÂU HỎI
    # ============================================================
    # questions là ngân hàng câu hỏi gốc đọc từ DATA/questions.txt.
    questions = load_questions()

    if len(questions) == 0:
        print("Không có câu hỏi trong hệ thống.")
        return

    # ============================================================
    # GIAI ĐOẠN 2: NHẬN THÔNG TIN THÍ SINH
    # ============================================================
    print("\n========== THÔNG TIN THÍ SINH ==========")
    candidate_id = input("Nhập mã thí sinh: ").strip()
    candidate_name = input("Nhập họ và tên: ").strip()

    # ============================================================
    # GIAI ĐOẠN 3: NHẬN CẤU HÌNH ĐỀ THI
    # ============================================================
    available_subjects = get_unique_subjects(questions)
    selected_subjects = choose_subjects(available_subjects)

    print("\n========== CHỌN ĐỘ KHÓ ==========")
    print("1. Dễ")
    print("2. Khó")
    print("3. Dễ và Khó")
    difficulty_choice = input("Chọn độ khó: ").strip()

    if difficulty_choice == "1":
        difficulty = "DE"
    elif difficulty_choice == "2":
        difficulty = "KHO"
    else:
        difficulty = DIFFICULTY_ALL

    # eligible_questions là tập câu hỏi phù hợp điều kiện, chưa phải đề thi.
    eligible_questions = collect_eligible_questions(
        questions, selected_subjects, difficulty
    )

    if len(eligible_questions) == 0:
        print("Không có câu hỏi phù hợp.")
        return

    print(f"Số câu phù hợp hiện có: {len(eligible_questions)}")

    number_of_questions = int(input("Nhập số lượng câu hỏi của đề: ").strip())

    minutes = int(input("Nhập thời gian làm bài (phút): ").strip())

    if number_of_questions <= 0 or minutes <= 0:
        print("Số câu hỏi và thời gian làm bài phải lớn hơn 0.")
        return

    if number_of_questions > len(eligible_questions):
        print("Số câu yêu cầu lớn hơn số câu hiện có, hệ thống sẽ dùng toàn bộ câu phù hợp.")

    limit_seconds = minutes * 60

    # ============================================================
    # GIAI ĐOẠN 4: SINH ĐỀ NGẪU NHIÊN VÀ XÁO TRỘN
    # ============================================================
    exam_questions = generate_exam(
        eligible_questions,
        number_of_questions,
    )

    input("Nhấn Enter để bắt đầu làm bài")

    # ============================================================
    # GIAI ĐOẠN 5: LÀM BÀI CÓ GIỚI HẠN THỜI GIAN
    # ============================================================
    used_seconds = run_exam_session(exam_questions, limit_seconds)

    if used_seconds is None:
        return

    # ============================================================
    # GIAI ĐOẠN 6: CHẤM ĐIỂM
    # ============================================================
    counts = calculate_exam_counts(exam_questions)
    correct_count = counts[0]
    wrong_count = counts[1]

    # Điểm hệ 10 = số câu đúng / tổng số câu * 10.
    score_ten = correct_count * 10.0 / len(exam_questions)

    # ============================================================
    # GIAI ĐOẠN 7: TẠO VÀ LƯU KẾT QUẢ THI
    # ============================================================
    previous_results = load_results()
    result = ExamResult(
        next_exam_id(previous_results),
        candidate_id,
        candidate_name,
        datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        subject_list_to_text(selected_subjects),
        len(exam_questions),
        correct_count,
        wrong_count,
        score_ten,
        limit_seconds,
        used_seconds,
    )
    append_result(result)

    # ============================================================
    # GIAI ĐOẠN 8: HIỂN THỊ KẾT QUẢ SAU KHI NỘP
    # ============================================================
    print("\n========== KẾT QUẢ BÀI THI ==========")
    print(f"Số câu đúng  : {correct_count}")
    print(f"Số câu sai   : {wrong_count}")
    print(f"Điểm hệ 10   : {score_ten:.2f}")
    print(f"Thời gian dùng: {format_seconds(used_seconds)}")

    review_choice = input("Bạn có muốn xem đáp án chi tiết? (Y/N): ").strip().upper()

    if review_choice == "Y":
        show_exam_review(exam_questions)


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MODULE EXAM
#
# start_exam()
# ├── load_questions()
# ├── get_unique_subjects(questions)
# │   └── contains_subject(subjects, question.subject)
# ├── choose_subjects(available_subjects)
# │   └── contains_subject(selected_subjects, selected_subject)
# ├── collect_eligible_questions(questions, selected_subjects, difficulty)
# │   └── contains_subject(selected_subjects, question.subject)
# ├── generate_exam(eligible_questions, number_of_questions)
# │   ├── eligible_questions.copy_shallow()
# │   ├── shuffle(shuffled_candidates)
# │   ├── Question.clone()
# │   ├── shuffle_question_options(exam_question)
# │   │   ├── AnswerOption(...)
# │   │   └── shuffle(options)
# │   └── exam_questions.append(exam_question)
# ├── run_exam_session(exam_questions, limit_seconds)
# │   ├── display_exam_question(...)
# │   │   └── format_seconds(remaining_seconds)
# │   └── display_question_progress(...)
# ├── calculate_exam_counts(exam_questions)
# ├── load_results()
# ├── next_exam_id(previous_results)
# ├── subject_list_to_text(selected_subjects)
# ├── ExamResult(...)
# ├── append_result(result)
# └── show_exam_review(exam_questions) nếu thí sinh muốn xem chi tiết
#
# Ghi nhớ:
# - eligible_questions là danh sách câu hỏi đủ điều kiện, chưa phải đề thi.
# - exam_questions là đề thi riêng của lần thi hiện tại.
# - calculate_exam_counts() chỉ trả về đúng/sai; câu bỏ qua hoặc chưa trả lời là sai.
# ============================================================
