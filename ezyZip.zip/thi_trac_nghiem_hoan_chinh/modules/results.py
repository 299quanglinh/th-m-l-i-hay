"""
Module hiển thị và tìm kiếm lịch sử kết quả thi trên console.

Nhiệm vụ chính:
- Đọc danh sách kết quả đã lưu trong DATA/results.txt thông qua file_manager.
- Hiển thị toàn bộ lịch sử thi theo thứ tự lưu trong file.
- Tìm kết quả theo mã thí sinh hoặc tên thí sinh bằng tìm kiếm tuần tự.
- Cung cấp menu kết quả cho chương trình console.

Module được gọi bởi:
- main.py khi thí sinh chọn "Xem kết quả thi".

Module sử dụng:
- modules.file_manager.load_results để đọc lịch sử kết quả.
- modules.linked_list.LinkedList để lưu kết quả tìm kiếm.
- modules.text_utils.contains_text để lọc theo từ khóa.
- modules.text_utils.format_seconds để định dạng thời gian.

Dữ liệu đi vào:
- Lựa chọn menu và từ khóa người dùng nhập trên console.
- LinkedList<ExamResult> đọc từ DATA/results.txt.

Dữ liệu đi ra:
- Thông tin kết quả được in ra màn hình console.
- Module không ghi hoặc xóa dữ liệu kết quả.

Quan hệ với các file còn lại:
- main.py chỉ gọi results_menu(); mọi thao tác đọc và hiển thị lịch sử
  trong console nằm trong module này.

Nên đọc file này như thế nào:
1. Đọc results_menu() trước vì đây là điểm vào từ main.py.
2. Nếu chọn xem toàn bộ, đọc show_results().
3. Nếu chọn tìm kiếm, đọc search_results().
4. Cả hai nhánh đều dùng display_result() để in từng ExamResult.
"""

from modules.file_manager import load_results
from modules.linked_list import LinkedList
from modules.text_utils import contains_text, format_seconds


def display_result(result, index=None):
    """
    In thông tin chi tiết của một lần thi ra console.

    Hàm được gọi bởi:
    - show_results().

    Hàm gọi:
    - format_seconds() để hiển thị thời gian quy định và thời gian đã dùng.

    Tham số:
        result:
            ExamResult, kết quả của một lần thi.
        index:
            int hoặc None, số thứ tự hiển thị trong báo cáo. index khác
            exam_id: index là vị trí khi duyệt, exam_id là mã lần thi đã lưu.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi file. Chỉ in thông tin ra console.

    Vị trí trong luồng hoạt động:
        Sau khi show_results() có LinkedList kết quả, hàm này được gọi cho
        từng ExamResult để trình bày các trường dữ liệu.
    """

    # title thay đổi theo việc có truyền index hay không.
    title = f"LẦN THI {result.exam_id}"

    if index is not None:
        title = f"KẾT QUẢ {index} - LẦN THI {result.exam_id}"

    print("-" * 72)
    print(title)
    print(f"Mã thí sinh : {result.candidate_id}")
    print(f"Họ và tên   : {result.candidate_name}")
    print(f"Thời điểm   : {result.exam_time_text}")
    print(f"Chủ đề  : {result.subjects}")

    print(
        f"Đúng/Sai: "
        f"{result.correct_count}/"
        f"{result.wrong_count}"
    )

    print(f"Tổng số câu : {result.total_questions}")
    print(f"Điểm hệ 10  : {result.score_ten:.2f}")
    print(
        f"Thời gian quy định: "
        f"{format_seconds(result.limit_seconds)}"
    )
    print(
        f"Thời gian đã dùng : "
        f"{format_seconds(result.used_seconds)}"
    )


def show_results(results=None):
    """
    Hiển thị nhiều kết quả thi ra console.

    Hàm được gọi bởi:
    - results_menu() khi chọn xem toàn bộ kết quả.
    - search_results() khi đã lọc được danh sách phù hợp.

    Hàm gọi:
    - load_results() nếu không nhận sẵn danh sách kết quả.
    - display_result() cho từng kết quả.

    Tham số:
        results:
            LinkedList<ExamResult> hoặc None. Nếu None, hàm tự đọc toàn bộ
            lịch sử từ DATA/results.txt.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi dữ liệu. Chỉ đọc và in kết quả.

    Trường hợp đặc biệt:
        Nếu danh sách rỗng, hàm thông báo chưa có kết quả và kết thúc.

    Vị trí trong luồng hoạt động:
        Đây là hàm hiển thị báo cáo chính trong phiên bản console.
    """

    if results is None:
        results = load_results()

    if len(results) == 0:
        print("Chưa có kết quả thi nào.")
        return

    print("\n========== BÁO CÁO KẾT QUẢ ==========")

    # index là số thứ tự hiển thị, tăng theo thứ tự duyệt trong file kết quả.
    index = 1

    for result in results:
        display_result(result, index)
        index += 1

    print("-" * 72)
    print(f"Tổng số lần thi: {len(results)}")


def search_results():
    """
    Tìm và hiển thị kết quả thi theo mã hoặc tên thí sinh.

    Hàm được gọi bởi:
    - results_menu() khi thí sinh chọn chức năng tìm kiếm.

    Hàm gọi:
    - load_results() để đọc toàn bộ lịch sử.
    - contains_text() để kiểm tra từ khóa trong mã/tên.
    - LinkedList.append() để gom kết quả khớp.
    - show_results() để hiển thị danh sách đã lọc.

    Tham số:
        Không có tham số. Từ khóa được nhập trực tiếp từ console.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi file kết quả.

    Thuật toán:
        Duyệt tuần tự toàn bộ LinkedList kết quả. Với mỗi ExamResult, kiểm tra
        candidate_id và candidate_name có chứa keyword hay không.

    Trường hợp đặc biệt:
        Nếu chưa có kết quả hoặc không có kết quả phù hợp, hàm chỉ in thông báo.
    """

    results = load_results()

    if len(results) == 0:
        print("Chưa có kết quả thi nào.")
        return

    keyword = input("Nhập mã hoặc tên thí sinh cần tìm: ").strip()

    # matched_results chỉ chứa các ExamResult khớp từ khóa.
    # Danh sách toàn bộ kết quả vẫn giữ nguyên.
    matched_results = LinkedList()

    for result in results:
        found_by_id = contains_text(
            result.candidate_id,
            keyword,
        )

        found_by_name = contains_text(
            result.candidate_name,
            keyword,
        )

        if found_by_id or found_by_name:
            matched_results.append(result)

    if len(matched_results) == 0:
        print("Không tìm thấy kết quả phù hợp.")
        return

    show_results(matched_results)


def results_menu():
    """
    Hiển thị menu báo cáo kết quả trên console.

    Hàm được gọi bởi:
    - main.main() khi người dùng chọn "Xem kết quả thi".

    Hàm gọi:
    - show_results() để xem toàn bộ lịch sử.
    - search_results() để lọc theo mã hoặc tên thí sinh.

    Tham số:
        Không có tham số. Lựa chọn được nhập từ console.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Không ghi/xóa dữ liệu. Module chỉ đọc lịch sử thi.

    Vị trí trong luồng hoạt động:
        Đây là menu con của chương trình console. Chọn 0 sẽ quay lại main().
    """

    while True:
        print("\n========== BÁO CÁO KẾT QUẢ ==========")
        print("1. Xem toàn bộ kết quả")
        print("2. Tìm theo mã hoặc tên thí sinh")
        print("0. Quay lại menu chính")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_results()

        elif choice == "2":
            search_results()

        elif choice == "0":
            return

        else:
            print("Lựa chọn không hợp lệ.")


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MODULE RESULTS
#
# results_menu()
# ├── nếu chọn "1. Xem toàn bộ kết quả"
# │   └── show_results()
# │       ├── load_results()
# │       └── display_result(result, index)
# │           └── format_seconds(...)
# ├── nếu chọn "2. Tìm theo mã hoặc tên thí sinh"
# │   └── search_results()
# │       ├── load_results()
# │       ├── contains_text(result.candidate_id, keyword)
# │       ├── contains_text(result.candidate_name, keyword)
# │       ├── matched_results.append(result)
# │       └── show_results(matched_results)
# └── nếu chọn "0. Quay lại menu chính"
#     └── return về main()
#
# Dữ liệu đi qua module:
# DATA/results.txt -> load_results() -> LinkedList<ExamResult>
# -> display_result() -> in ra console.
# ============================================================
