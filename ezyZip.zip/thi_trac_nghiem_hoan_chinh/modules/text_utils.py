"""
Module chứa các hàm xử lý chuỗi dùng chung trong dự án.

Nhiệm vụ chính:
- Ghép nhiều trường dữ liệu thành một dòng text để ghi file.
- Tách một dòng text thành nhiều trường dữ liệu.
- Tìm kiếm chuỗi con bằng thuật toán tuần tự tự cài đặt.
- Chuẩn hóa khoảng trắng người dùng nhập.
- Đổi số giây thành chuỗi thời gian dễ đọc.

Module được gọi bởi:
- modules.file_manager khi đọc/ghi DATA/questions.txt và DATA/results.txt.
- modules.results khi tìm kết quả theo mã hoặc tên thí sinh.
- modules.exam khi hiển thị thời gian trên console.
- app_gui.py khi chuẩn hóa dữ liệu nhập và hiển thị thời gian.

Module sử dụng:
- modules.linked_list.LinkedList để trả về tập trường sau khi tách chuỗi.

Dữ liệu đi vào:
- Chuỗi nhập từ người dùng.
- Dòng dữ liệu text đọc từ file.
- LinkedList chứa các trường cần ghi thành một dòng.
- Số giây cần định dạng.

Dữ liệu đi ra:
- Chuỗi đã ghép, chuỗi đã chuẩn hóa, bool kết quả tìm kiếm,
  hoặc LinkedList chứa các trường đã tách.

Quan hệ với các file còn lại:
- file_manager phụ thuộc vào join_record() và parse_record() để thống nhất
  cách lưu dữ liệu dạng text.
- results và app_gui dùng contains_text() cho chức năng tìm lịch sử thi.

Nên đọc file này khi nào:
- Đọc sau các file chính như main.py, exam.py và file_manager.py.
- Khi thấy một hàm như parse_record(), join_record(), contains_text()
  xuất hiện trong file khác thì quay lại đây để xem chi tiết.
"""

from modules.linked_list import LinkedList


def join_record(fields):
    """
    Ghép nhiều trường dữ liệu thành một dòng text có dấu phân tách.

    Hàm được gọi bởi:
    - modules.file_manager.result_to_line().

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        fields:
            LinkedList chứa các trường cần ghi xuống file.

    Trả về:
        str, một dòng text dùng dấu "|" để phân tách trường.

    Dữ liệu hoặc file bị thay đổi:
        Không trực tiếp ghi file. result_to_line() nhận chuỗi trả về,
        sau đó append_result() mới ghi vào DATA/results.txt.

    Trường hợp đặc biệt:
        Nếu một trường có ký tự "|" hoặc ký tự xuống dòng, hàm thay bằng
        khoảng trắng để không làm hỏng cấu trúc một dòng dữ liệu.

    Vị trí trong luồng hoạt động:
        Sau khi chấm điểm và tạo ExamResult, file_manager chuyển đối tượng
        thành một dòng text bằng hàm này trước khi ghi kết quả.
    """

    # result là dòng dữ liệu đang được xây dần.
    result = ""

    # index cho biết đây có phải trường đầu tiên hay không.
    # Từ trường thứ hai trở đi mới cần thêm dấu "|" phía trước.
    index = 0

    for field in fields:
        if index > 0:
            result += "|"

        # Mỗi field có thể là số hoặc chuỗi. str(field) đưa tất cả về text.
        # Dấu phân tách và ký tự xuống dòng bị thay để mỗi bản ghi chỉ chiếm một dòng.
        result += str(field).replace("|", " ").replace("\n", " ").replace("\r", " ")
        index += 1

    return result


def parse_record(line):
    """
    Tách một dòng text thành các trường dữ liệu.

    Hàm được gọi bởi:
    - modules.file_manager.line_to_question().
    - modules.file_manager.line_to_result().

    Hàm gọi:
    - LinkedList() để chứa các trường.
    - LinkedList.append() mỗi khi gặp dấu phân tách hoặc kết thúc dòng.

    Tham số:
        line:
            str, một dòng đọc từ questions.txt hoặc results.txt.

    Trả về:
        LinkedList chứa các trường theo đúng thứ tự trong dòng.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi file. Hàm chỉ xử lý dòng đã đọc vào bộ nhớ.

    Trường hợp đặc biệt:
        Dòng được rstrip("\\n") để bỏ ký tự xuống dòng cuối dòng.
        Nếu dòng thiếu hoặc thừa trường, file_manager sẽ kiểm tra số lượng
        trường ở bước sau.

    Vị trí trong luồng hoạt động:
        Đây là bước đầu tiên để chuyển dữ liệu text thành Question hoặc ExamResult.
    """

    fields = LinkedList()

    # current_field lưu tạm các ký tự thuộc trường đang đọc.
    current_field = ""

    for character in line.rstrip("\n"):
        if character == "|":
            fields.append(current_field)
            current_field = ""
        else:
            current_field += character

    # Sau vòng lặp, trường cuối cùng không có dấu "|" phía sau nên phải thêm thủ công.
    fields.append(current_field)
    return fields


def contains_text(source, keyword):
    """
    Kiểm tra keyword có xuất hiện trong source hay không.

    Hàm được gọi bởi:
    - modules.results.search_results().
    - app_gui.QuizApplication.search_result_records().

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        source:
            str, chuỗi gốc cần tìm trong đó, ví dụ mã hoặc tên thí sinh.
        keyword:
            str, từ khóa người dùng nhập.

    Trả về:
        bool, True nếu keyword nằm trong source, False nếu không.

    Dữ liệu bị thay đổi:
        Không thay đổi dữ liệu đầu vào.

    Thuật toán:
        Hàm tự duyệt từng vị trí bắt đầu trong source_lower, rồi so sánh
        từng ký tự với keyword_lower. Không dùng hàm tìm kiếm có sẵn.

    Trường hợp đặc biệt:
        Keyword rỗng được xem là khớp với mọi source.
    """

    # Chuyển về chữ thường để tìm kiếm không phân biệt hoa/thường.
    source_lower = source.lower()
    keyword_lower = keyword.lower()

    if keyword_lower == "":
        return True

    if len(keyword_lower) > len(source_lower):
        return False

    # start là vị trí bắt đầu thử so khớp trong source.
    start = 0

    # last_start là vị trí bắt đầu cuối cùng còn đủ độ dài để chứa keyword.
    last_start = len(source_lower) - len(keyword_lower)

    while start <= last_start:
        # matched giữ kết quả so khớp tại vị trí start hiện tại.
        matched = True

        # offset là độ lệch của ký tự đang so sánh trong keyword.
        offset = 0

        while offset < len(keyword_lower):
            if source_lower[start + offset] != keyword_lower[offset]:
                matched = False
                break
            offset += 1

        if matched:
            return True

        start += 1

    return False


def normalize_spaces(text):
    """
    Chuẩn hóa khoảng trắng trong chuỗi nhập từ người dùng.

    Hàm được gọi bởi:
    - app_gui.QuizApplication.begin_exam_from_setup().
    - app_gui.QuizApplication.search_result_records().

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        text:
            str, chuỗi người dùng nhập trong ô Tkinter.

    Trả về:
        str, chuỗi đã bỏ khoảng trắng đầu/cuối và gộp nhiều khoảng trắng liên tiếp
        thành một khoảng trắng.

    Dữ liệu bị thay đổi:
        Không sửa chuỗi gốc; Python tạo chuỗi mới.

    Vị trí trong luồng hoạt động:
        Dùng trước khi lưu mã thí sinh, tên thí sinh hoặc từ khóa tìm kiếm
        để tránh lỗi do khoảng trắng thừa.
    """

    result = ""

    # previous_was_space cho biết ký tự vừa thêm vào result có phải khoảng trắng không.
    # Nhờ đó nhiều khoảng trắng liên tiếp chỉ được giữ lại thành một dấu cách.
    previous_was_space = False

    for character in text.strip():
        if character.isspace():
            if not previous_was_space:
                result += " "
                previous_was_space = True
        else:
            result += character
            previous_was_space = False

    return result


def format_seconds(total_seconds):
    """
    Chuyển số giây thành chuỗi dạng 'x phút y giây'.

    Hàm được gọi bởi:
    - modules.exam.display_exam_question().
    - modules.exam.start_exam().
    - modules.results.display_result().
    - app_gui.py khi hiển thị kết quả và lịch sử.

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        total_seconds:
            int hoặc float, tổng số giây cần hiển thị.

    Trả về:
        str, chuỗi thời gian đã định dạng.

    Dữ liệu bị thay đổi:
        Không thay đổi dữ liệu bên ngoài.

    Trường hợp đặc biệt:
        Nếu số giây âm, hàm ép về 0 để tránh hiển thị thời gian âm.

    Vị trí trong luồng hoạt động:
        Dùng ở cả console và GUI để trình bày thời gian còn lại,
        thời gian quy định hoặc thời gian đã dùng.
    """

    # safe_seconds là số giây đã ép kiểu int để chia phút/giây ổn định.
    safe_seconds = int(total_seconds)

    if safe_seconds < 0:
        safe_seconds = 0

    minutes = safe_seconds // 60
    seconds = safe_seconds % 60
    return f"{minutes} phút {seconds} giây"


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MODULE TEXT_UTILS
#
# modules.file_manager.result_to_line(result)
# └── join_record(fields)
#
# modules.file_manager.line_to_question(line)
# └── parse_record(line)
#
# modules.file_manager.line_to_result(line)
# └── parse_record(line)
#
# modules.results.search_results()
# └── contains_text(source, keyword)
#
# modules.exam.display_exam_question()
# └── format_seconds(remaining_seconds)
#
# Ghi nhớ:
# - text_utils không điều phối luồng thi.
# - File này chỉ cung cấp các hàm nhỏ để các module chính dùng lại.
# ============================================================
