import os

from modules.linked_list import LinkedList
from modules.models import ExamResult, Question
from modules.text_utils import join_record, parse_record


PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


DATA_DIR = os.path.join(PROJECT_DIR, "DATA")


QUESTIONS_FILE = os.path.join(DATA_DIR, "questions.txt")


RESULTS_FILE = os.path.join(DATA_DIR, "results.txt")


def ensure_data_files():


    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

    if not os.path.exists(QUESTIONS_FILE):
        with open(QUESTIONS_FILE, "w", encoding="utf-8"):
            pass

    if not os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "w", encoding="utf-8"):
            pass


def line_to_question(line):


    fields = parse_record(line)

    if len(fields) != 10:
        return None

    try:
        question_id = int(fields[0])
    except ValueError:
        return None


    correct_answer = fields[9].upper()

    if correct_answer != "A" and correct_answer != "B" \
            and correct_answer != "C" and correct_answer != "D":
        return None

    return Question(
        question_id,
        fields[1],
        fields[2],
        fields[3],
        fields[4],
        fields[5],
        fields[6],
        fields[7],
        fields[8],
        correct_answer,
    )


def load_questions():


    ensure_data_files()


    questions = LinkedList()


    with open(QUESTIONS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            question = line_to_question(line)

            if question is not None:
                questions.append(question)

    return questions


def open_questions_file():


    ensure_data_files()

    try:
        os.startfile(QUESTIONS_FILE)
        print(f"Đã mở file câu hỏi: {QUESTIONS_FILE}")
    except (AttributeError, OSError):
        print("Không thể mở file tự động trên hệ điều hành này.")
        print(f"Hãy mở thủ công file: {QUESTIONS_FILE}")


def result_to_line(result):


    fields = LinkedList()
    fields.append(result.exam_id)
    fields.append(result.candidate_id)
    fields.append(result.candidate_name)
    fields.append(result.exam_time_text)
    fields.append(result.subjects)
    fields.append(result.total_questions)
    fields.append(result.correct_count)
    fields.append(result.wrong_count)
    fields.append(f"{result.score_ten:.2f}")
    fields.append(result.limit_seconds)
    fields.append(result.used_seconds)
    return join_record(fields)


def line_to_result(line):


    fields = parse_record(line)

    if len(fields) != 11:
        return None

    try:
        return ExamResult(
            int(fields[0]),
            fields[1],
            fields[2],
            fields[3],
            fields[4],
            int(fields[5]),
            int(fields[6]),
            int(fields[7]),
            float(fields[8]),
            int(fields[9]),
            int(fields[10]),
        )
    except ValueError:
        return None


def append_result(result):


    ensure_data_files()


    with open(RESULTS_FILE, "a", encoding="utf-8") as file:
        file.write(result_to_line(result) + "\n")


def load_results():


    ensure_data_files()


    results = LinkedList()

    with open(RESULTS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            result = line_to_result(line)

            if result is not None:
                results.append(result)

    return results


def next_exam_id(results):


    maximum_id = 0

    for result in results:
        if result.exam_id > maximum_id:
            maximum_id = result.exam_id

    return maximum_id + 1
