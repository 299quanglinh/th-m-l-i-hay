"""
Module quản lý việc đọc và ghi dữ liệu text của chương trình.

Nhiệm vụ chính:
- Xác định đường dẫn thư mục DATA của dự án.
- Đảm bảo các file dữ liệu cần thiết tồn tại.
- Đọc DATA/questions.txt và chuyển từng dòng thành đối tượng Question.
- Ghi nối kết quả thi mới vào DATA/results.txt.
- Đọc DATA/results.txt và chuyển từng dòng thành đối tượng ExamResult.
- Tính mã lần thi tiếp theo dựa trên lịch sử kết quả đã lưu.

Module được gọi bởi:
- main.py khi khởi động để đảm bảo file dữ liệu tồn tại.
- modules.exam khi đọc câu hỏi, đọc lịch sử kết quả và lưu kết quả mới.
- modules.results khi đọc lịch sử thi để hiển thị/tìm kiếm.
- app_gui.py khi khởi động, sinh đề, lưu kết quả và hiển thị lịch sử.

Module sử dụng:
- os để xác định đường dẫn thư mục dự án.
- modules.linked_list.LinkedList để lưu danh sách câu hỏi/kết quả.
- modules.models.Question và modules.models.ExamResult để biểu diễn dữ liệu.
- modules.text_utils.parse_record và join_record để tách/ghép dòng text.

Dữ liệu đi vào:
- Dòng text trong DATA/questions.txt và DATA/results.txt.
- Đối tượng ExamResult cần ghi thêm vào file kết quả.
- LinkedList kết quả đã đọc khi cần tìm mã lần thi tiếp theo.

Dữ liệu đi ra:
- LinkedList<Question> từ load_questions().
- LinkedList<ExamResult> từ load_results().
- Chuỗi một dòng kết quả từ result_to_line().
- Số nguyên mã lần thi tiếp theo từ next_exam_id().

Quan hệ với các file còn lại:
- Đây là cầu nối giữa dữ liệu lưu trên đĩa và các đối tượng trong bộ nhớ.
- modules.exam và app_gui không tự đọc/ghi file trực tiếp, mà đi qua module này.
"""

import os

from modules.linked_list import LinkedList
from modules.models import ExamResult, Question
from modules.text_utils import join_record, parse_record

# PROJECT_DIR là thư mục gốc của dự án. __file__ đang trỏ đến file
# modules/file_manager.py, nên dirname(dirname(...)) đi lên một cấp khỏi modules.
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# DATA_DIR là nơi chứa các file dữ liệu text của chương trình.
DATA_DIR = os.path.join(PROJECT_DIR, "DATA")

# QUESTIONS_FILE chứa ngân hàng câu hỏi chuẩn bị trước. Thí sinh chỉ đọc gián tiếp
# qua load_questions(), không có chức năng sửa file này từ giao diện.
QUESTIONS_FILE = os.path.join(DATA_DIR, "questions.txt")

# RESULTS_FILE chứa lịch sử các lần thi, mỗi lần thi là một dòng.
RESULTS_FILE = os.path.join(DATA_DIR, "results.txt")


def ensure_data_files():
    """
    Kiểm tra và tạo thư mục/file dữ liệu cần thiết trước khi chương trình chạy.

    Hàm được gọi bởi:
    - main.main() ngay khi mở chương trình console.
    - load_questions(), append_result() và load_results() trước khi đọc/ghi file.

    Hàm gọi:
    - os.path.exists() để kiểm tra đường dẫn.
    - os.makedirs() để tạo thư mục DATA nếu chưa có.
    - open(..., "w") để tạo file rỗng nếu file chưa tồn tại.

    Tham số:
        Không có.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Có thể tạo DATA/, DATA/questions.txt hoặc DATA/results.txt nếu chúng
        chưa tồn tại. Nếu các file đã có sẵn, hàm không ghi đè nội dung cũ.

    Vị trí trong luồng hoạt động:
        Đây là bước chuẩn bị an toàn. Nhờ hàm này, các bước đọc/ghi sau đó
        không bị lỗi vì thiếu thư mục hoặc thiếu file.
    """

    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

    if not os.path.exists(QUESTIONS_FILE):
        with open(QUESTIONS_FILE, "w", encoding="utf-8"):
            pass

    if not os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "w", encoding="utf-8"):
            pass


def line_to_question(line):
    """
    Chuyển một dòng trong DATA/questions.txt thành đối tượng Question.

    Hàm được gọi bởi:
    - load_questions() cho từng dòng không rỗng trong file câu hỏi.

    Hàm gọi:
    - parse_record() để tách dòng theo dấu "|".
    - Question() để tạo đối tượng câu hỏi hợp lệ.

    Tham số:
        line:
            str, một dòng text đọc từ DATA/questions.txt.

    Trả về:
        Question nếu dòng hợp lệ; None nếu dòng sai cấu trúc hoặc sai dữ liệu.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi file. Hàm chỉ đọc chuỗi và tạo đối tượng trong bộ nhớ.

    Cấu trúc dòng câu hỏi:
        0: ID câu hỏi, phải chuyển được sang int.
        1: Chủ đề.
        2: Mức độ, ví dụ "DE" hoặc "KHO".
        3: Nội dung câu hỏi.
        4: Phương án A.
        5: Phương án B.
        6: Phương án C.
        7: Phương án D.
        8: Ký hiệu đáp án đúng, chỉ được là A/B/C/D.

    """

    # fields là LinkedList chứa từng trường sau khi tách bằng dấu "|".
    fields = parse_record(line)

    if len(fields) != 9:
        return None

    try:
        question_id = int(fields[0])
    except ValueError:
        return None

    # correct_answer là ký hiệu đáp án đúng, không phải nội dung đáp án.
    correct_answer = fields[8].upper()

    if correct_answer != "A" and correct_answer != "B" \
            and correct_answer != "C" and correct_answer != "D":
        return None

    return Question(
        question_id,
        fields[1],
        fields[2],
        fields[3],
        fields[4],
        fields[5],
        fields[6],
        fields[7],
        correct_answer,
    )


def load_questions():
    """
    Đọc toàn bộ ngân hàng câu hỏi từ DATA/questions.txt.

    Hàm được gọi bởi:
    - modules.exam.start_exam() trong chương trình console.
    - app_gui.QuizApplication.show_exam_setup_screen().
    - app_gui.QuizApplication.update_eligible_question_count().
    - app_gui.QuizApplication.begin_exam_from_setup().

    Hàm gọi:
    - ensure_data_files() để đảm bảo file tồn tại.
    - LinkedList() để chứa các Question.
    - line_to_question() cho từng dòng dữ liệu.
    - LinkedList.append() để thêm câu hỏi hợp lệ.

    Tham số:
        Không có tham số.

    Trả về:
        LinkedList chứa các đối tượng Question hợp lệ đọc từ file.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi nội dung DATA/questions.txt. Chỉ có thể tạo file rỗng
        nếu file chưa tồn tại thông qua ensure_data_files().

    Trường hợp đặc biệt:
        Dòng rỗng hoặc dòng sai cấu trúc bị bỏ qua.

    Vị trí trong luồng hoạt động:
        Đây là điểm bắt đầu của luồng sinh đề: file câu hỏi -> LinkedList<Question>.
    """

    ensure_data_files()

    # questions là danh sách câu hỏi gốc đọc từ file.
    # Danh sách này khác với exam_questions trong module exam: exam_questions
    # là đề thi đã chọn và xáo trộn cho một lần thi cụ thể.
    questions = LinkedList()

    # Chế độ "r" chỉ đọc file. with open tự đóng file sau khi đọc xong.
    with open(QUESTIONS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            question = line_to_question(line)

            if question is not None:
                questions.append(question)

    return questions


def result_to_line(result):
    """
    Chuyển một đối tượng ExamResult thành một dòng text để ghi file.

    Hàm được gọi bởi:
    - append_result().

    Hàm gọi:
    - LinkedList() để gom các trường theo thứ tự.
    - LinkedList.append() để thêm từng trường.
    - join_record() để ghép các trường bằng dấu "|".

    Tham số:
        result:
            ExamResult, kết quả của một lần thi đã hoàn thành.

    Trả về:
        str, một dòng text đại diện cho kết quả thi.

    Dữ liệu hoặc file bị thay đổi:
        Không trực tiếp ghi file. append_result() sẽ dùng chuỗi trả về để ghi nối.

    Cấu trúc dòng kết quả:
        0: Mã lần thi.
        1: Mã thí sinh.
        2: Họ tên thí sinh.
        3: Thời điểm thi/nộp bài.
        4: Chủ đề trong đề thi.
        5: Tổng số câu.
        6: Số câu đúng.
        7: Số câu sai.
        8: Điểm hệ 10, ghi với 2 chữ số thập phân.
        9: Thời gian quy định, tính bằng giây.
        10: Thời gian đã dùng, tính bằng giây.

    Vị trí trong luồng hoạt động:
        Sau khi chấm điểm, ExamResult được chuyển thành text ở đây rồi ghi xuống
        DATA/results.txt.
    """

    # fields giữ đúng thứ tự trường để line_to_result() có thể đọc ngược lại.
    fields = LinkedList()
    fields.append(result.exam_id)
    fields.append(result.candidate_id)
    fields.append(result.candidate_name)
    fields.append(result.exam_time_text)
    fields.append(result.subjects)
    fields.append(result.total_questions)
    fields.append(result.correct_count)
    fields.append(result.wrong_count)
    fields.append(f"{result.score_ten:.2f}")
    fields.append(result.limit_seconds)
    fields.append(result.used_seconds)
    return join_record(fields)


def line_to_result(line):
    """
    Chuyển một dòng trong DATA/results.txt thành đối tượng ExamResult.

    Hàm được gọi bởi:
    - load_results() cho từng dòng không rỗng trong file kết quả.

    Hàm gọi:
    - parse_record() để tách trường.
    - ExamResult() để tạo đối tượng kết quả hợp lệ.

    Tham số:
        line:
            str, một dòng text trong DATA/results.txt.

    Trả về:
        ExamResult nếu dòng hợp lệ; None nếu dòng sai cấu trúc hoặc lỗi ép kiểu.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi file kết quả.

    Trường hợp đặc biệt:
        Hàm chỉ chấp nhận định dạng kết quả hiện tại gồm 11 trường. Dòng sai số
        trường sẽ bị bỏ qua để tránh đọc nhầm dữ liệu.

    Vị trí trong luồng hoạt động:
        Đây là bước đọc lịch sử: dòng text -> ExamResult -> báo cáo kết quả.
    """

    fields = parse_record(line)

    if len(fields) != 11:
        return None

    try:
        return ExamResult(
            int(fields[0]),
            fields[1],
            fields[2],
            fields[3],
            fields[4],
            int(fields[5]),
            int(fields[6]),
            int(fields[7]),
            float(fields[8]),
            int(fields[9]),
            int(fields[10]),
        )
    except ValueError:
        return None


def append_result(result):
    """
    Ghi nối một kết quả thi mới vào DATA/results.txt.

    Hàm được gọi bởi:
    - modules.exam.start_exam() sau khi chấm bài console.
    - app_gui.QuizApplication.submit_exam() sau khi chấm bài GUI.

    Hàm gọi:
    - ensure_data_files() để đảm bảo file kết quả tồn tại.
    - result_to_line() để chuyển ExamResult thành text.

    Tham số:
        result:
            ExamResult, kết quả cần lưu.

    Trả về:
        None.

    Dữ liệu hoặc file bị thay đổi:
        Ghi thêm một dòng vào DATA/results.txt.

    Chế độ ghi file:
        Chế độ "a" là ghi nối tiếp, không xóa lịch sử cũ. Mỗi lần thi mới
        được thêm vào cuối file.

    Vị trí trong luồng hoạt động:
        Đây là bước cuối của quá trình thi sau khi đã tính điểm.
    """

    ensure_data_files()

    # with open tự đóng file sau khi ghi xong.
    with open(RESULTS_FILE, "a", encoding="utf-8") as file:
        file.write(result_to_line(result) + "\n")


def load_results():
    """
    Đọc toàn bộ lịch sử kết quả từ DATA/results.txt.

    Hàm được gọi bởi:
    - modules.exam.start_exam() để lấy dữ liệu tính mã lần thi tiếp theo.
    - modules.results.show_results() và search_results().
    - app_gui.QuizApplication.show_home_screen().
    - app_gui.QuizApplication.submit_exam().
    - app_gui.QuizApplication.refresh_result_table().
    - app_gui.QuizApplication.search_result_records().

    Hàm gọi:
    - ensure_data_files().
    - LinkedList().
    - line_to_result().
    - LinkedList.append().

    Tham số:
        Không có tham số.

    Trả về:
        LinkedList chứa các đối tượng ExamResult hợp lệ.

    Dữ liệu hoặc file bị thay đổi:
        Không thay đổi nội dung DATA/results.txt. Chỉ có thể tạo file rỗng
        nếu file chưa tồn tại.

    Vị trí trong luồng hoạt động:
        Dùng trong menu xem kết quả và khi tạo mã lần thi mới.
    """

    ensure_data_files()

    # results là danh sách toàn bộ kết quả đã lưu, khác với result là một lần thi.
    results = LinkedList()

    with open(RESULTS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            result = line_to_result(line)

            if result is not None:
                results.append(result)

    return results


def next_exam_id(results):
    """
    Tính mã lần thi tiếp theo dựa trên danh sách kết quả đã có.

    Hàm được gọi bởi:
    - modules.exam.start_exam().
    - app_gui.QuizApplication.submit_exam().

    Hàm gọi:
    - Không gọi hàm tự định nghĩa nào khác.

    Tham số:
        results:
            LinkedList chứa các ExamResult đã đọc từ DATA/results.txt.

    Trả về:
        int, mã lần thi mới bằng mã lớn nhất hiện có cộng 1.

    Dữ liệu bị thay đổi:
        Không thay đổi danh sách results.

    Thuật toán:
        Duyệt tuần tự toàn bộ kết quả để tìm exam_id lớn nhất.
        Không dùng hàm sắp xếp có sẵn.

    Trường hợp đặc biệt:
        Nếu chưa có kết quả nào, maximum_id giữ giá trị 0 và hàm trả về 1.
    """

    # maximum_id lưu mã lần thi lớn nhất tìm được khi duyệt lịch sử.
    maximum_id = 0

    for result in results:
        if result.exam_id > maximum_id:
            maximum_id = result.exam_id

    return maximum_id + 1


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MODULE FILE_MANAGER
#
# ensure_data_files()
#
# load_questions()
# ├── ensure_data_files()
# ├── line_to_question(line)
# │   ├── parse_record(line)
# │   └── Question(...)
# └── questions.append(question)
#
# append_result(result)
# ├── ensure_data_files()
# └── result_to_line(result)
#     ├── fields.append(...)
#     └── join_record(fields)
#
# load_results()
# ├── ensure_data_files()
# ├── line_to_result(line)
# │   ├── parse_record(line)
# │   └── ExamResult(...)
# └── results.append(result)
#
# next_exam_id(results)
# └── duyệt tuần tự LinkedList<ExamResult> để tìm exam_id lớn nhất
#
# Định dạng DATA/questions.txt:
# id|subject|difficulty|content|option_a|option_b|option_c|option_d|correct_answer
#
# Định dạng DATA/results.txt:
# exam_id|candidate_id|candidate_name|exam_time|subjects|total|correct|wrong|score|limit_seconds|used_seconds
# ============================================================
