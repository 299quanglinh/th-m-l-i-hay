"""
Module xáo trộn dữ liệu dùng chung trong chương trình.

Nhiệm vụ chính:
- Cung cấp hàm shuffle() để đảo thứ tự phần tử trong LinkedList.
- Dùng thuật toán Fisher-Yates tự cài đặt trên LinkedList của dự án.

Module được gọi bởi:
- modules.exam.generate_exam() để xáo trộn danh sách câu hỏi ứng viên trước khi chọn đề.
- modules.exam.shuffle_question_options() để xáo trộn bốn phương án A/B/C/D.

Module sử dụng:
- random.randint() để sinh chỉ số ngẫu nhiên.
- LinkedList.swap() do dự án tự cài đặt để đổi chỗ hai phần tử.

Dữ liệu đi vào:
- Một LinkedList chứa câu hỏi hoặc phương án trả lời.

Dữ liệu đi ra:
- Không trả về danh sách mới. Hàm sửa trực tiếp thứ tự phần tử trong LinkedList nhận vào.

Quan hệ với các file còn lại:
- Đây là phần thuật toán ngẫu nhiên. Module này không biết phần tử là câu hỏi hay đáp án;
  nó chỉ biết LinkedList có độ dài, có thể truy cập chỉ số và có thể swap().
"""

import random


def shuffle(linked_list):
    """
    Xáo trộn thứ tự các phần tử trong một LinkedList.

    Hàm được gọi bởi:
    - generate_exam() trong modules.exam để xáo trộn danh sách câu hỏi đủ điều kiện.
    - shuffle_question_options() trong modules.exam để xáo trộn các đáp án của một câu.

    Hàm gọi:
    - len(linked_list) để lấy số phần tử.
    - random.randint(0, index) để chọn vị trí ngẫu nhiên.
    - linked_list.swap(index, random_index) để đổi chỗ hai phần tử.

    Tham số:
        linked_list:
            LinkedList, danh sách cần xáo trộn. Danh sách này có thể chứa Question
            hoặc AnswerOption tùy nơi gọi hàm.

    Trả về:
        None. Thứ tự phần tử trong linked_list bị thay đổi trực tiếp.

    Dữ liệu bị thay đổi:
        Dữ liệu trong các node không bị tạo mới hoặc xóa đi. Hàm chỉ đổi vị trí
        các phần tử thông qua swap().

    Thuật toán Fisher-Yates:
        - Bắt đầu từ vị trí cuối cùng của danh sách.
        - Tại mỗi vị trí index, chọn random_index trong đoạn từ 0 đến index.
        - Đổi chỗ phần tử ở index với phần tử ở random_index.
        - Sau mỗi vòng lặp, phần tử ở index được xem là đã có vị trí cuối cùng.

    Vì sao không tạo trùng:
        Hàm chỉ đổi chỗ các phần tử đã có. Không thêm phần tử mới, không sao chép
        phần tử, nên danh sách sau khi xáo trộn vẫn có đúng số phần tử ban đầu.

    Độ phức tạp:
        O(n) vòng lặp. Mỗi vòng gọi swap(), còn swap() trên LinkedList cần tìm node
        theo chỉ số nên chi phí thực tế phụ thuộc vào cách LinkedList duyệt node.
    """

    # index bắt đầu từ vị trí cuối cùng. Nếu danh sách có 0 hoặc 1 phần tử,
    # index sẽ không lớn hơn 0 nên vòng lặp không chạy, vì không cần xáo trộn.
    index = len(linked_list) - 1

    while index > 0:
        # random_index nằm trong đoạn [0, index]. Những vị trí lớn hơn index
        # đã được cố định ở các vòng trước nên không động lại nữa.
        random_index = random.randint(0, index)

        # swap() đổi hai phần tử trong LinkedList tự cài đặt của dự án.
        linked_list.swap(index, random_index)

        # Chuyển sang cố định vị trí liền trước.
        index -= 1


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MODULE
#
# shuffle(linked_list)
# ├── len(linked_list)
# ├── random.randint(0, index)
# └── linked_list.swap(index, random_index)
#
# Module gọi shuffle():
# - modules.exam.generate_exam()
# - modules.exam.shuffle_question_options()
# ============================================================
