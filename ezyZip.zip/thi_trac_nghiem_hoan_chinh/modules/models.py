"""
Module khai báo các kiểu dữ liệu chính của chương trình thi trắc nghiệm.

Nhiệm vụ chính:
- Gom dữ liệu của một câu hỏi vào lớp Question.
- Gom dữ liệu của một phương án trả lời tạm thời vào lớp AnswerOption.
- Gom dữ liệu của một lần thi đã hoàn thành vào lớp ExamResult.

Module được gọi bởi:
- modules.file_manager để tạo Question khi đọc questions.txt và tạo/đọc ExamResult.
- modules.exam để dùng Question, AnswerOption và ExamResult trong quá trình sinh đề,
  chấm điểm và lưu kết quả.
- app_gui.py để tạo ExamResult khi thí sinh nộp bài trên giao diện Tkinter.

Module sử dụng:
- Không import module nào khác. File này chỉ định nghĩa lớp dữ liệu đơn giản.

Dữ liệu đi vào:
- Các giá trị rời rạc như mã câu hỏi, nội dung câu hỏi, đáp án, điểm số,
  thời gian làm bài.

Dữ liệu đi ra:
- Các đối tượng Question, AnswerOption và ExamResult được truyền sang
  những module khác để xử lý tiếp.

Quan hệ với các file còn lại:
- modules.file_manager chuyển dữ liệu text trong DATA thành các đối tượng ở đây.
- modules.exam nhận các đối tượng này để sinh đề, nhận bài và chấm điểm.
- app_gui.py hiển thị hoặc cập nhật các thuộc tính của những đối tượng này.
"""


class Question:
    """
    Đại diện cho một câu hỏi trắc nghiệm.

    Vì sao cần lớp này:
    - Một câu hỏi có nhiều thông tin đi kèm nhau: mã câu, chủ đề,
      mức độ, nội dung, bốn phương án, đáp án đúng và câu trả lời của thí sinh.
    - Gom các thông tin này vào cùng một đối tượng giúp truyền câu hỏi giữa
      file_manager, exam và app_gui mà không bị rời rạc.

    Thuộc tính:
    - question_id: int, mã duy nhất của câu hỏi trong DATA/questions.txt.
    - subject: str, chủ đề hoặc học phần của câu hỏi.
    - difficulty: str, mã mức độ; dự án đang dùng "DE", "KHO" hoặc lọc bằng "ALL".
    - content: str, nội dung câu hỏi.
    - option_a, option_b, option_c, option_d: str, nội dung bốn phương án.
    - correct_answer: str, ký hiệu "A", "B", "C" hoặc "D" của đáp án đúng.
      Sau khi xáo trộn đáp án, ký hiệu này được cập nhật theo vị trí mới.
    - user_answer: str, đáp án thí sinh chọn trong lúc làm bài; chuỗi rỗng
      nghĩa là chưa trả lời.
    - is_answered: bool, đánh dấu câu đã có đáp án của thí sinh.
    - is_skipped: bool, đánh dấu câu bị bỏ qua trong lúc làm bài. Thuộc tính này
      chỉ phục vụ hiển thị/trạng thái; kết quả cuối cùng không lưu số câu bỏ qua
      riêng, vì câu chưa trả lời được tính vào wrong_count.

    Đối tượng được tạo ở:
    - modules.file_manager.line_to_question() khi đọc từng dòng questions.txt.
    - clone() khi tạo bản sao câu hỏi cho đề thi.

    Đối tượng được truyền sang:
    - modules.exam.collect_eligible_questions() để lọc.
    - modules.exam.generate_exam() để sinh đề và xáo trộn.
    - modules.exam.calculate_exam_counts() để chấm điểm.
    - app_gui.py để hiển thị câu hỏi trên giao diện.

    Quan hệ với lớp khác:
    - Question dùng AnswerOption trong modules.exam.shuffle_question_options()
      để theo dõi phương án nào là đúng khi xáo trộn đáp án.
    """

    def __init__(
        self,
        question_id,
        subject,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    ):
        """
        Khởi tạo một câu hỏi từ dữ liệu đã đọc hoặc từ bản sao của câu hỏi khác.

        Hàm được gọi bởi:
        - modules.file_manager.line_to_question().
        - Question.clone().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            question_id:
                int, mã câu hỏi lấy từ trường đầu tiên của dòng dữ liệu.
            subject:
                str, chủ đề của câu hỏi.
            difficulty:
                str, mức độ của câu hỏi.
            content:
                str, nội dung câu hỏi.
            option_a, option_b, option_c, option_d:
                str, nội dung bốn phương án trả lời.
            correct_answer:
                str, ký hiệu đáp án đúng.

        Trả về:
            None. Hàm khởi tạo chỉ gán thuộc tính cho đối tượng hiện tại.

        Dữ liệu bị thay đổi:
            Các thuộc tính của chính đối tượng Question đang được tạo.

        Vị trí trong luồng hoạt động:
            Đây là bước biến dữ liệu thô từ file hoặc từ câu hỏi gốc thành
            đối tượng có thể dùng trong sinh đề và chấm điểm.
        """

        # Các thuộc tính bên dưới mô tả dữ liệu gốc của câu hỏi.
        self.question_id = question_id
        self.subject = subject
        self.difficulty = difficulty
        self.content = content
        self.option_a = option_a
        self.option_b = option_b
        self.option_c = option_c
        self.option_d = option_d

        # correct_answer là ký hiệu đáp án đúng hiện tại, không phải nội dung đáp án.
        # Khi đáp án bị xáo trộn trong đề thi, ký hiệu này được cập nhật lại.
        self.correct_answer = correct_answer

        # Ba thuộc tính này chỉ phục vụ một lần làm bài cụ thể.
        # Câu hỏi mới đọc từ file chưa có câu trả lời của thí sinh.
        # is_skipped không phải trường lưu kết quả; nó chỉ giúp màn hình biết
        # câu nào đang được đánh dấu bỏ qua trước khi chấm điểm.
        self.user_answer = ""
        self.is_answered = False
        self.is_skipped = False

    def clone(self):
        """
        Tạo bản sao độc lập của câu hỏi để đưa vào đề thi.

        Hàm được gọi bởi:
        - modules.exam.generate_exam().

        Hàm gọi:
        - Question() để tạo đối tượng mới có cùng dữ liệu gốc.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            Question, bản sao của câu hỏi hiện tại.

        Dữ liệu bị thay đổi:
            Không làm thay đổi câu hỏi gốc. Đây là điểm quan trọng vì đề thi
            sẽ xáo trộn đáp án trên bản sao, không sửa dữ liệu trong ngân hàng.

        Trường hợp đặc biệt:
            Các trạng thái user_answer, is_answered và is_skipped của bản sao
            luôn trở về trạng thái chưa làm bài do __init__ thiết lập.

        Vị trí trong luồng hoạt động:
            Sau khi câu hỏi được chọn ngẫu nhiên, generate_exam() gọi clone()
            rồi mới xáo trộn phương án trả lời.
        """

        return Question(
            self.question_id,
            self.subject,
            self.difficulty,
            self.content,
            self.option_a,
            self.option_b,
            self.option_c,
            self.option_d,
            self.correct_answer,
        )


class AnswerOption:
    """
    Đại diện cho một phương án trả lời trong lúc xáo trộn đáp án.

    Vì sao cần lớp này:
    - Khi đổi vị trí A/B/C/D, chương trình phải nhớ nội dung nào là đáp án đúng.
    - AnswerOption ghép nội dung phương án với cờ is_correct để không mất dấu
      đáp án đúng sau khi xáo trộn.

    Thuộc tính:
    - text: str, nội dung phương án.
    - is_correct: bool, True nếu phương án này là phương án đúng.

    Đối tượng được tạo ở:
    - modules.exam.shuffle_question_options().

    Đối tượng được truyền sang:
    - modules.random_utils.shuffle() thông qua LinkedList chứa bốn AnswerOption.

    Quan hệ với lớp khác:
    - Mỗi AnswerOption được sinh từ một thuộc tính option_a/b/c/d của Question.
    """

    def __init__(self, text, is_correct):
        """
        Khởi tạo một phương án tạm dùng cho quá trình xáo trộn đáp án.

        Hàm được gọi bởi:
        - modules.exam.shuffle_question_options().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            text:
                str, nội dung phương án trả lời.
            is_correct:
                bool, cho biết phương án này có phải đáp án đúng không.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Chỉ gán thuộc tính cho đối tượng AnswerOption mới.

        Vị trí trong luồng hoạt động:
            Đây là bước chuẩn bị trước khi gọi Fisher-Yates để xáo trộn
            bốn phương án của một câu hỏi trong đề thi.
        """

        # text là nội dung phương án; is_correct là dấu vết để cập nhật
        # lại ký hiệu đáp án đúng sau khi xáo trộn.
        self.text = text
        self.is_correct = is_correct


class ExamResult:
    """
    Đại diện cho kết quả của một lần thi.

    Vì sao cần lớp này:
    - Một lần thi có nhiều thông tin: thí sinh, thời điểm, cấu hình đề,
      số câu đúng/sai, điểm và thời gian đã dùng.
    - Gom dữ liệu vào ExamResult giúp dễ lưu xuống DATA/results.txt và hiển thị lại.

    Thuộc tính:
    - exam_id: int, mã lần thi, tăng theo dữ liệu kết quả đã có.
    - candidate_id: str, mã thí sinh.
    - candidate_name: str, họ tên thí sinh.
    - exam_time_text: str, thời điểm nộp bài đã định dạng.
    - subjects: str, các chủ đề được chọn, đã nối thành chuỗi.
    - total_questions: int, tổng số câu trong đề.
    - correct_count: int, số câu đúng.
    - wrong_count: int, số câu sai.
    - score_ten: float, điểm theo thang 10.
    - limit_seconds: int, thời gian làm bài được cấu hình, tính bằng giây.
    - used_seconds: int, thời gian thí sinh đã dùng, tính bằng giây.

    Đối tượng được tạo ở:
    - modules.exam.start_exam() cho chương trình console.
    - app_gui.py trong submit_exam() cho giao diện Tkinter.
    - modules.file_manager.line_to_result() khi đọc lại lịch sử kết quả.

    Đối tượng được truyền sang:
    - modules.file_manager.append_result() để ghi xuống DATA/results.txt.
    - modules.results.display_result() và app_gui.py để hiển thị báo cáo.
    """

    def __init__(
        self,
        exam_id,
        candidate_id,
        candidate_name,
        exam_time_text,
        subjects,
        total_questions,
        correct_count,
        wrong_count,
        score_ten,
        limit_seconds,
        used_seconds,
    ):
        """
        Khởi tạo đối tượng kết quả sau khi một bài thi được chấm.

        Hàm được gọi bởi:
        - modules.exam.start_exam().
        - app_gui.QuizApplication.submit_exam().
        - modules.file_manager.line_to_result().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            exam_id:
                int, mã lần thi.
            candidate_id:
                str, mã thí sinh.
            candidate_name:
                str, họ tên thí sinh.
            exam_time_text:
                str, thời điểm làm/nộp bài.
            subjects:
                str, các chủ đề trong đề thi.
            total_questions:
                int, tổng số câu.
            correct_count, wrong_count:
                int, số câu đúng và số câu sai.
            score_ten:
                float, điểm hệ 10.
            limit_seconds:
                int, tổng thời gian được cấp cho bài thi, tính bằng giây.
            used_seconds:
                int, thời gian đã dùng thực tế, tính bằng giây.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Gán thuộc tính cho đối tượng ExamResult mới.

        Vị trí trong luồng hoạt động:
            Sau khi calculate_exam_counts() đếm đúng/sai, chương trình
            tạo ExamResult rồi truyền sang append_result() để lưu.
        """

        self.exam_id = exam_id
        self.candidate_id = candidate_id
        self.candidate_name = candidate_name
        self.exam_time_text = exam_time_text
        self.subjects = subjects
        self.total_questions = total_questions
        self.correct_count = correct_count
        self.wrong_count = wrong_count
        self.score_ten = score_ten
        self.limit_seconds = limit_seconds
        self.used_seconds = used_seconds


# ============================================================
# SƠ ĐỒ QUAN HỆ DỮ LIỆU CỦA MODULE MODELS
#
# DATA/questions.txt
# └── modules.file_manager.line_to_question()
#     └── Question(...)
#         ├── được lọc trong collect_eligible_questions()
#         ├── được clone() trong generate_exam()
#         ├── được cập nhật user_answer khi thí sinh làm bài
#         └── được đọc correct_answer trong calculate_exam_counts()
#
# shuffle_question_options(question)
# ├── AnswerOption(question.option_a, ...)
# ├── AnswerOption(question.option_b, ...)
# ├── AnswerOption(question.option_c, ...)
# └── AnswerOption(question.option_d, ...)
#
# calculate_exam_counts()
# └── ExamResult(...)
#     └── modules.file_manager.append_result()
#
# Ghi nhớ:
# - Question là dữ liệu câu hỏi.
# - AnswerOption là dữ liệu tạm khi xáo trộn đáp án.
# - ExamResult là dữ liệu của một lần thi đã hoàn thành.
# ============================================================
