"""
File giao diện Tkinter cho chương trình thi trắc nghiệm.

Nhiệm vụ chính:
- Tạo cửa sổ chính dành cho thí sinh.
- Cho thí sinh bắt đầu thi, cấu hình đề thi, làm bài có đồng hồ đếm ngược.
- Tự động kết thúc bài khi hết giờ hoặc chấm bài khi thí sinh tự bấm nộp.
- Chấm điểm bằng cùng logic với module console.
- Lưu kết quả vào DATA/results.txt và hiển thị lịch sử thi.

File này thuộc phần:
- Giao diện đồ họa Tkinter. Phiên bản console nằm trong main.py và modules.exam.

File này import:
- modules.exam để lọc câu hỏi, sinh đề, chấm điểm và chuyển danh sách chủ đề thành text.
- modules.file_manager để đảm bảo file dữ liệu, đọc câu hỏi/kết quả và lưu kết quả.
- modules.linked_list.LinkedList để lưu dữ liệu theo cấu trúc tự cài đặt.
- modules.models.ExamResult để tạo kết quả sau khi nộp bài.
- modules.text_utils để tìm kiếm, chuẩn hóa nhập liệu và định dạng thời gian.

File này được gọi hoặc sử dụng bởi:
- Người dùng chạy trực tiếp bằng lệnh python app_gui.py.
- Có thể được import trong kiểm thử để khởi tạo QuizApplication.

Các lớp và hàm chính:
- QuizApplication: lớp cửa sổ chính, chứa toàn bộ màn hình và sự kiện Tkinter.

Dữ liệu đi vào:
- DATA/questions.txt được đọc gián tiếp qua load_questions().
- Dữ liệu thí sinh nhập trên ô giao diện.
- Lựa chọn đáp án A/B/C/D, nút điều hướng và nút nộp bài.

Dữ liệu đi ra:
- ExamResult được ghi nối vào DATA/results.txt thông qua append_result().
- Các bảng và nhãn Tkinter hiển thị đề thi, kết quả và lịch sử.

Quan hệ với các file còn lại:
- app_gui.py không tự cài đặt thuật toán sinh đề hay chấm điểm; nó gọi lại
  modules.exam để giữ cùng logic với console.
- app_gui.py không cung cấp màn hình quản lý ngân hàng câu hỏi. Câu hỏi chỉ
  được đọc nội bộ để sinh đề.
"""

import time
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

from modules.exam import (
    DIFFICULTY_ALL,
    calculate_exam_counts,
    collect_eligible_questions,
    generate_exam,
    get_unique_subjects,
    subject_list_to_text,
)
from modules.file_manager import (
    append_result,
    ensure_data_files,
    load_questions,
    load_results,
    next_exam_id,
)
from modules.linked_list import LinkedList
from modules.models import ExamResult
from modules.text_utils import contains_text, format_seconds, normalize_spaces

class QuizApplication(tk.Tk):
    """
    Cửa sổ chính của ứng dụng thi trắc nghiệm bằng Tkinter.

    Lớp đại diện cho:
    - Toàn bộ ứng dụng GUI, kế thừa tk.Tk nên chính đối tượng này là cửa sổ gốc.

    Vì sao cần lớp này:
    - Các màn hình như menu chính, cấu hình thi, làm bài, kết quả và lịch sử
      cần dùng chung dữ liệu: đề thi hiện tại, câu đang xem, đồng hồ,
      thông tin thí sinh và kết quả cuối.
    - Đưa các biến đó vào cùng một lớp giúp các phương thức màn hình truyền
      dữ liệu cho nhau mà không dùng biến toàn cục.

    Thuộc tính quan trọng:
    - current_screen: widget màn hình hiện tại để quản lý thay màn hình.
    - timer_job: mã lịch after() của Tkinter, dùng để hủy đồng hồ khi cần.
    - exam_active: bool, cho biết đang trong phiên làm bài.
    - exam_submitted: bool, chống nộp bài hai lần.
    - subject_choices: LinkedList chứa cặp (chủ đề, BooleanVar) ở màn hình cấu hình.
    - question_buttons: LinkedList chứa cặp (vị trí câu, Button) ở màn hình làm bài.
    - exam_questions: LinkedList<Question>, đề thi đã sinh và xáo trộn.
    - current_question_index: int, vị trí câu đang hiển thị trong đề.
    - selected_subjects: LinkedList<str>, chủ đề thí sinh đã chọn.
    - candidate_id, candidate_name: str, thông tin thí sinh.
    - limit_seconds: int, tổng thời gian làm bài tính bằng giây.
    - exam_started_at, exam_deadline: float, mốc thời gian dùng với time.monotonic().
    - last_result: ExamResult hoặc None, kết quả vừa nộp.
    - result_table, result_detail: widget hiển thị lịch sử kết quả.

    Đối tượng được tạo ở:
    - Khối if __name__ == "__main__" cuối file.

    Đối tượng truyền dữ liệu sang:
    - modules.exam.generate_exam() nhận câu hỏi phù hợp và trả về exam_questions.
    - modules.exam.calculate_exam_counts() nhận exam_questions để chấm điểm.
    - modules.file_manager.append_result() nhận ExamResult để lưu.
    """

    def __init__(self):
        """
        Khởi tạo cửa sổ chính, giá trị ban đầu và mở menu chính.

        Hàm được gọi bởi:
        - QuizApplication() ở cuối file.

        Hàm gọi:
        - ensure_data_files() để chuẩn bị DATA.
        - configure_styles() để thiết lập giao diện.
        - bind() của Tkinter để bắt phím khi làm bài.
        - show_home_screen() để hiển thị màn hình đầu tiên.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu hoặc file bị thay đổi:
            ensure_data_files() có thể tạo file dữ liệu nếu chưa có.

        Vị trí trong luồng hoạt động:
            Đây là bước khởi động của giao diện Tkinter.
        """

        super().__init__()

        ensure_data_files()

        self.title("Chương trình thi trắc nghiệm")
        self.geometry("1180x760")
        self.minsize(980, 650)
        self.protocol("WM_DELETE_WINDOW", self.handle_close)

        self.configure(bg="#f4f6f8")
        self.style = ttk.Style(self)
        self.configure_styles()

        # Nhóm biến quản lý màn hình và đồng hồ.
        self.current_screen = None
        self.timer_job = None
        self.exam_active = False
        self.exam_submitted = False

        # Nhóm biến lưu dữ liệu đề thi và lựa chọn của thí sinh.
        self.subject_choices = LinkedList()
        self.question_buttons = LinkedList()
        self.exam_questions = LinkedList()
        self.current_question_index = 0
        self.selected_subjects = LinkedList()
        self.candidate_id = ""
        self.candidate_name = ""
        self.limit_seconds = 0
        self.exam_started_at = 0.0
        self.exam_deadline = 0.0
        self.last_result = None

        # Nhóm biến widget dùng cho màn hình lịch sử kết quả.
        self.result_table = None
        self.result_detail = None

        self.bind("<Key>", self.handle_exam_key)
        self.show_home_screen()

    def configure_styles(self):
        """
        Thiết lập kiểu chữ, khoảng cách và giao diện chung cho các widget ttk.

        Hàm được gọi bởi:
        - __init__().

        Hàm gọi:
        - self.style.theme_use() và self.style.configure() của Tkinter.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Cấu hình style của cửa sổ Tkinter hiện tại.

        Vị trí trong luồng hoạt động:
            Chạy một lần khi khởi động GUI để các màn hình dùng chung kiểu hiển thị.
        """

        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.style.configure("Title.TLabel", font=("Arial", 24, "bold"))
        self.style.configure("Heading.TLabel", font=("Arial", 17, "bold"))
        self.style.configure("Subheading.TLabel", font=("Arial", 12, "bold"))
        self.style.configure("Body.TLabel", font=("Arial", 11))
        self.style.configure("Large.TButton", font=("Arial", 12), padding=12)
        self.style.configure("Action.TButton", font=("Arial", 10, "bold"), padding=8)
        self.style.configure("Exam.TRadiobutton", font=("Arial", 12), padding=8)
        self.style.configure("Treeview", rowheight=28, font=("Arial", 10))
        self.style.configure("Treeview.Heading", font=("Arial", 10, "bold"))

    def handle_close(self):
        """
        Xử lý khi người dùng đóng cửa sổ hoặc bấm nút thoát.

        Hàm được gọi bởi:
        - Protocol WM_DELETE_WINDOW.
        - Nút "Thoát chương trình" ở màn hình chính.

        Hàm gọi:
        - messagebox.askyesno() nếu bài thi đang diễn ra.
        - cancel_timer() để hủy lịch cập nhật đồng hồ.
        - destroy() để đóng cửa sổ Tkinter.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Có thể hủy timer_job và đóng ứng dụng.

        Trường hợp đặc biệt:
            Nếu đang làm bài và chưa nộp, chương trình hỏi xác nhận để tránh
            mất bài ngoài ý muốn.
        """

        if self.exam_active and not self.exam_submitted:
            confirmed = messagebox.askyesno(
                "Thoát chương trình",
                "Bài thi đang diễn ra. Thoát lúc này sẽ không lưu kết quả.\n"
                "Bạn vẫn muốn thoát?",
                parent=self,
            )

            if not confirmed:
                return

        self.cancel_timer()
        self.destroy()

    def cancel_timer(self):
        """
        Hủy lịch gọi update_timer() nếu đồng hồ đang được Tkinter lên lịch.

        Hàm được gọi bởi:
        - handle_close().
        - clear_screen().
        - submit_exam().
        - Một số kiểm thử hoặc luồng dừng bài.

        Hàm gọi:
        - self.after_cancel() của Tkinter.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            timer_job được đặt về None sau khi hủy.

        Lưu ý:
            Tkinter after() trả về một mã lịch. Nếu không hủy, update_timer()
            có thể tiếp tục chạy sau khi chuyển màn hình.
        """

        if self.timer_job is not None:
            try:
                self.after_cancel(self.timer_job)
            except tk.TclError:
                pass

            self.timer_job = None

    def clear_screen(self):
        """
        Xóa toàn bộ widget của màn hình hiện tại trước khi dựng màn hình mới.

        Hàm được gọi bởi:
        - create_page().
        - show_exam_screen().

        Hàm gọi:
        - cancel_timer() để dừng đồng hồ nếu đang chạy.
        - winfo_children() và destroy() của Tkinter để xóa widget con.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Xóa widget trong cửa sổ và đặt current_screen về None.

        Vị trí trong luồng hoạt động:
            Mỗi khi chuyển từ menu sang cấu hình, từ cấu hình sang làm bài,
            hoặc từ làm bài sang kết quả, hàm này làm sạch màn hình cũ.
        """

        self.cancel_timer()

        for widget in self.winfo_children():
            widget.destroy()

        self.current_screen = None

    def create_page(self, title, subtitle=""):
        """
        Tạo khung trang chung có tiêu đề và phụ đề.

        Hàm được gọi bởi:
        - show_home_screen().
        - show_exam_setup_screen().
        - show_exam_result_screen().
        - show_exam_review_screen().
        - show_results_screen().

        Hàm gọi:
        - clear_screen() để xóa màn hình cũ.
        - ttk.Frame và ttk.Label để tạo khung/trang mới.

        Tham số:
            title:
                str, tiêu đề lớn của màn hình.
            subtitle:
                str, mô tả ngắn dưới tiêu đề; mặc định là chuỗi rỗng.

        Trả về:
            ttk.Frame, khung trang để phương thức gọi tiếp tục thêm widget.

        Dữ liệu bị thay đổi:
            current_screen được cập nhật thành page mới.
        """

        self.clear_screen()

        page = ttk.Frame(self, padding=22)
        page.pack(fill="both", expand=True)

        ttk.Label(page, text=title, style="Title.TLabel").pack(pady=(4, 4))

        if subtitle != "":
            ttk.Label(page, text=subtitle, style="Body.TLabel").pack(pady=(0, 18))
        else:
            ttk.Frame(page, height=12).pack()

        self.current_screen = page
        return page

    def show_home_screen(self):
        """
        Hiển thị màn hình chính dành cho thí sinh.

        Hàm được gọi bởi:
        - __init__() khi khởi động.
        - Các nút quay lại menu chính từ màn hình cấu hình, kết quả và lịch sử.

        Hàm gọi:
        - create_page().
        - load_results() để hiển thị số lần thi đã lưu.
        - show_exam_setup_screen() khi bấm "Bắt đầu thi".
        - show_results_screen() khi bấm "Xem kết quả thi".
        - handle_close() khi bấm thoát.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            exam_active được đặt False vì đang ở ngoài phiên làm bài.

        Lưu ý:
            Màn hình này không có nút quản lý ngân hàng câu hỏi; thí sinh chỉ
            được bắt đầu thi, xem kết quả hoặc thoát.
        """

        self.exam_active = False
        page = self.create_page(
            "CHƯƠNG TRÌNH THI TRẮC NGHIỆM",
            "Dành cho thí sinh: bắt đầu thi, xem kết quả và thoát chương trình.",
        )

        summary = ttk.Frame(page)
        summary.pack(pady=(8, 26))

        ttk.Label(
            summary,
            text=f"Lịch sử kết quả đã lưu: {len(load_results())} lần thi",
            style="Subheading.TLabel",
        ).pack()

        menu_frame = ttk.Frame(page)
        menu_frame.pack(pady=10)

        ttk.Button(menu_frame, text="Bắt đầu thi", width=34, style="Large.TButton", command=self.show_exam_setup_screen).pack(pady=8)

        ttk.Button(menu_frame, text="Xem kết quả thi", width=34, style="Large.TButton", command=self.show_results_screen).pack(pady=8)

        ttk.Button(menu_frame, text="Thoát chương trình", width=34, style="Large.TButton", command=self.handle_close).pack(pady=8)

    def show_exam_setup_screen(self):
        """
        Hiển thị màn hình nhập thông tin thí sinh và cấu hình đề thi.

        Hàm được gọi bởi:
        - show_home_screen() khi bấm "Bắt đầu thi".

        Hàm gọi:
        - load_questions() để đọc ngân hàng câu hỏi.
        - get_unique_subjects() để lấy các chủ đề có thể chọn.
        - update_eligible_question_count() để báo số câu phù hợp.
        - begin_exam_from_setup() khi bấm bắt đầu làm bài.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Tạo các widget nhập liệu như candidate_id_entry, difficulty_box,
            question_count_entry, time_entry và subject_choices.

        Trường hợp đặc biệt:
            Nếu không có dữ liệu câu hỏi, hàm chỉ báo lỗi và không mở màn hình cấu hình.
        """

        # questions là ngân hàng câu hỏi gốc dùng để lấy chủ đề và đếm số câu phù hợp.
        questions = load_questions()

        if len(questions) == 0:
            messagebox.showwarning(
                "Chưa có dữ liệu câu hỏi",
                "Hiện chưa có dữ liệu câu hỏi để sinh đề. Vui lòng liên hệ người phụ trách.",
                parent=self,
            )
            return

        page = self.create_page(
            "CẤU HÌNH BÀI THI",
            "Nhập thông tin thí sinh, chọn chủ đề, độ khó, số câu và thời gian.",
        )

        form = ttk.Frame(page)
        form.pack(fill="both", expand=True, padx=50)
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Mã thí sinh:", style="Subheading.TLabel").grid(
            row=0,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.candidate_id_entry = ttk.Entry(form, font=("Arial", 11))
        self.candidate_id_entry.grid(row=0, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Họ và tên:", style="Subheading.TLabel").grid(
            row=1,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.candidate_name_entry = ttk.Entry(form, font=("Arial", 11))
        self.candidate_name_entry.grid(row=1, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Chủ đề:", style="Subheading.TLabel").grid(
            row=2,
            column=0,
            sticky="nw",
            padx=(0, 15),
            pady=8,
        )

        subject_box = ttk.LabelFrame(form, text="Có thể chọn nhiều chủ đề", padding=10)
        subject_box.grid(row=2, column=1, sticky="ew", pady=8)

        # subject_choices lưu các cặp (tên chủ đề, biến tick chọn).
        # Đây là dữ liệu giao diện, khác với selected_subjects là kết quả đã chọn.
        self.subject_choices = LinkedList()
        available_subjects = get_unique_subjects(questions)
        subject_index = 0

        for subject in available_subjects:
            variable = tk.BooleanVar(value=True)
            self.subject_choices.append((subject, variable))

            ttk.Checkbutton(
                subject_box,
                text=subject,
                variable=variable,
                command=self.update_eligible_question_count,
            ).grid(
                row=subject_index // 3,
                column=subject_index % 3,
                sticky="w",
                padx=12,
                pady=5,
            )
            subject_index += 1

        ttk.Label(form, text="Độ khó:", style="Subheading.TLabel").grid(
            row=3,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.difficulty_box = ttk.Combobox(
            form,
            values=("Cả Dễ và Khó", "Chỉ câu Dễ", "Chỉ câu Khó"),
            state="readonly",
            font=("Arial", 11),
        )
        self.difficulty_box.current(0)
        self.difficulty_box.grid(row=3, column=1, sticky="ew", pady=8)
        self.difficulty_box.bind(
            "<<ComboboxSelected>>",
            lambda _event: self.update_eligible_question_count(),
        )

        ttk.Label(form, text="Số câu:", style="Subheading.TLabel").grid(
            row=4,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.question_count_entry = ttk.Entry(form, font=("Arial", 11))
        self.question_count_entry.insert(0, "10")
        self.question_count_entry.grid(row=4, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Thời gian (phút):", style="Subheading.TLabel").grid(
            row=5,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.time_entry = ttk.Entry(form, font=("Arial", 11))
        self.time_entry.insert(0, "15")
        self.time_entry.grid(row=5, column=1, sticky="ew", pady=8)

        self.eligible_count_label = ttk.Label(
            form,
            text="",
            style="Subheading.TLabel",
        )
        self.eligible_count_label.grid(
            row=6,
            column=0,
            columnspan=2,
            pady=(18, 8),
        )

        button_frame = ttk.Frame(form)
        button_frame.grid(row=7, column=0, columnspan=2, pady=20)

        ttk.Button(button_frame, text="Bắt đầu làm bài", style="Large.TButton", command=self.begin_exam_from_setup).pack(side="left", padx=10)

        ttk.Button(button_frame, text="Quay lại", style="Large.TButton", command=self.show_home_screen).pack(side="left", padx=10)

        self.update_eligible_question_count()
        self.candidate_id_entry.focus_set()

    def get_selected_subjects_from_setup(self):
        """
        Lấy danh sách chủ đề đang được tick trong màn hình cấu hình.

        Hàm được gọi bởi:
        - update_eligible_question_count().
        - begin_exam_from_setup().

        Hàm gọi:
        - LinkedList() để tạo danh sách chủ đề kết quả.
        - LinkedList.append() để thêm chủ đề được chọn.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ self.subject_choices.

        Trả về:
            LinkedList<str>, các chủ đề thí sinh đã chọn.

        Dữ liệu bị thay đổi:
            Không thay đổi widget; chỉ đọc giá trị BooleanVar.
        """

        selected_subjects = LinkedList()

        for choice in self.subject_choices:
            subject, variable = choice

            if variable.get():
                selected_subjects.append(subject)

        return selected_subjects

    def get_selected_difficulty_code(self):
        """
        Chuyển lựa chọn mức độ trên Combobox thành mã mức độ dùng trong exam.py.

        Hàm được gọi bởi:
        - update_eligible_question_count().
        - begin_exam_from_setup().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ self.difficulty_box.

        Trả về:
            str, "DE", "KHO" hoặc DIFFICULTY_ALL.

        Dữ liệu bị thay đổi:
            Không thay đổi giao diện.
        """

        selected = self.difficulty_box.get()

        if selected == "Chỉ câu Dễ":
            return "DE"

        if selected == "Chỉ câu Khó":
            return "KHO"

        return DIFFICULTY_ALL

    def update_eligible_question_count(self):
        """
        Cập nhật nhãn báo số câu hỏi phù hợp với cấu hình hiện tại.

        Hàm được gọi bởi:
        - show_exam_setup_screen() sau khi dựng form.
        - Checkbox chủ đề khi người dùng tick/bỏ tick.
        - Combobox mức độ khi người dùng đổi lựa chọn.

        Hàm gọi:
        - get_selected_subjects_from_setup().
        - load_questions().
        - get_selected_difficulty_code().
        - collect_eligible_questions().

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Nội dung eligible_count_label trên giao diện.

        Vị trí trong luồng hoạt động:
            Giúp thí sinh biết hiện có bao nhiêu câu phù hợp trước khi bấm bắt đầu.
        """

        if not hasattr(self, "eligible_count_label"):
            return

        selected_subjects = self.get_selected_subjects_from_setup()

        if len(selected_subjects) == 0:
            self.eligible_count_label.configure(text="Chưa chọn chủ đề nào.")
            return

        # eligible là danh sách câu hỏi phù hợp hiện tại, chỉ dùng để đếm.
        # Đề thi thật chưa được sinh ở bước này.
        eligible = collect_eligible_questions(
            load_questions(),
            selected_subjects,
            self.get_selected_difficulty_code(),
        )
        self.eligible_count_label.configure(
            text=f"Số câu phù hợp hiện có: {len(eligible)}"
        )

    def begin_exam_from_setup(self):
        """
        Kiểm tra dữ liệu cấu hình, sinh đề và chuyển sang màn hình làm bài.

        Hàm được gọi bởi:
        - Nút "Bắt đầu làm bài" trong show_exam_setup_screen().

        Hàm gọi:
        - normalize_spaces() để làm sạch mã/tên thí sinh.
        - get_selected_subjects_from_setup().
        - get_selected_difficulty_code().
        - load_questions().
        - collect_eligible_questions().
        - generate_exam() để tạo đề thi.
        - show_exam_screen() để hiển thị câu đầu tiên và chạy đồng hồ.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ các widget nhập liệu.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Cập nhật candidate_id, candidate_name, selected_subjects,
            limit_seconds, exam_questions, current_question_index,
            exam_submitted, exam_active, exam_started_at và exam_deadline.

        Trường hợp đặc biệt:
            Nếu thiếu thông tin, số câu/thời gian không hợp lệ hoặc không đủ
            câu hỏi phù hợp, hàm hiển thị lỗi và không sinh đề.
        """

        candidate_id = normalize_spaces(self.candidate_id_entry.get())
        candidate_name = normalize_spaces(self.candidate_name_entry.get())

        if candidate_id == "" or candidate_name == "":
            messagebox.showerror(
                "Thiếu thông tin",
                "Mã thí sinh và họ tên không được để trống.",
                parent=self,
            )
            return

        selected_subjects = self.get_selected_subjects_from_setup()

        if len(selected_subjects) == 0:
            messagebox.showerror(
                "Chưa chọn chủ đề",
                "Hãy chọn ít nhất một chủ đề.",
                parent=self,
            )
            return

        try:
            number_of_questions = int(self.question_count_entry.get().strip())
            minutes = int(self.time_entry.get().strip())
        except ValueError:
            messagebox.showerror(
                "Dữ liệu không hợp lệ",
                "Số câu và thời gian phải là số nguyên.",
                parent=self,
            )
            return

        if number_of_questions < 1:
            messagebox.showerror(
                "Số câu không hợp lệ",
                "Số câu hỏi phải lớn hơn hoặc bằng 1.",
                parent=self,
            )
            return

        if minutes < 1 or minutes > 180:
            messagebox.showerror(
                "Thời gian không hợp lệ",
                "Thời gian phải nằm trong khoảng từ 1 đến 180 phút.",
                parent=self,
            )
            return

        difficulty = self.get_selected_difficulty_code()
        eligible = collect_eligible_questions(
            load_questions(),
            selected_subjects,
            difficulty,
        )

        if len(eligible) == 0:
            messagebox.showerror(
                "Không có câu hỏi",
                "Không có câu hỏi phù hợp với cấu hình đã chọn.",
                parent=self,
            )
            return

        if number_of_questions > len(eligible):
            messagebox.showerror(
                "Số câu vượt quá dữ liệu",
                f"Chỉ có {len(eligible)} câu phù hợp. Hãy nhập số nhỏ hơn.",
                parent=self,
            )
            return

        confirmed = messagebox.askyesno(
            "Bắt đầu bài thi",
            "Đề sẽ được sinh ngẫu nhiên và đồng hồ bắt đầu ngay.\n"
            "Bạn đã sẵn sàng?",
            parent=self,
        )

        if not confirmed:
            return

        self.candidate_id = candidate_id
        self.candidate_name = candidate_name
        self.selected_subjects = selected_subjects

        # limit_seconds là tổng thời gian làm bài theo giây.
        # Người dùng nhập phút, nên cần nhân 60 trước khi tính deadline.
        self.limit_seconds = minutes * 60

        # exam_questions là đề thi đã sinh, khác với eligible là tập câu hỏi phù hợp.
        # generate_exam() clone câu hỏi và xáo trộn đáp án nên không sửa dữ liệu gốc.
        self.exam_questions = generate_exam(
            eligible,
            number_of_questions,
        )
        self.current_question_index = 0
        self.exam_submitted = False
        self.exam_active = True

        # exam_started_at là thời điểm bắt đầu; exam_deadline là mốc hết giờ.
        self.exam_started_at = time.monotonic()
        self.exam_deadline = self.exam_started_at + self.limit_seconds
        self.show_exam_screen()

    def show_exam_screen(self):
        """
        Dựng màn hình làm bài thi và bắt đầu cập nhật đồng hồ.

        Hàm được gọi bởi:
        - begin_exam_from_setup() sau khi generate_exam() tạo đề thành công.

        Hàm gọi:
        - clear_screen() để xóa màn hình cấu hình.
        - go_to_question() khi bấm số câu.
        - record_selected_answer() khi chọn radio đáp án.
        - previous_question(), next_question(), skip_current_question().
        - submit_exam() khi bấm nộp bài.
        - load_current_question() để hiển thị câu hiện tại.
        - update_timer() để chạy đồng hồ.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ self.exam_questions.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Tạo nhiều widget Tkinter và lưu một số widget vào thuộc tính
            như timer_label, question_buttons, answer_variable, option_buttons.

        Vị trí trong luồng hoạt động:
            Đây là màn hình trung tâm của GUI, nơi thí sinh trả lời câu hỏi.
        """

        self.clear_screen()
        self.exam_active = True

        page = ttk.Frame(self, padding=14)
        page.pack(fill="both", expand=True)
        self.current_screen = page

        header = ttk.Frame(page)
        header.pack(fill="x", pady=(0, 10))

        candidate_text = f"{self.candidate_id} - {self.candidate_name}"
        ttk.Label(
            header,
            text=candidate_text,
            style="Subheading.TLabel",
        ).pack(side="left")

        self.timer_label = ttk.Label(
            header,
            text="",
            font=("Arial", 18, "bold"),
        )
        self.timer_label.pack(side="right")

        ttk.Separator(page, orient="horizontal").pack(fill="x", pady=(0, 10))

        body = ttk.Panedwindow(page, orient="horizontal")
        body.pack(fill="both", expand=True)

        navigation_frame = ttk.LabelFrame(
            body,
            text="Danh sách câu",
            padding=10,
        )
        question_frame = ttk.Frame(body, padding=(20, 8))
        body.add(navigation_frame, weight=1)
        body.add(question_frame, weight=4)

        canvas = tk.Canvas(navigation_frame, highlightthickness=0, width=210)
        scrollbar = ttk.Scrollbar(
            navigation_frame,
            orient="vertical",
            command=canvas.yview,
        )
        button_holder = ttk.Frame(canvas)
        holder_window = canvas.create_window((0, 0), window=button_holder, anchor="nw")

        button_holder.bind(
            "<Configure>",
            lambda _event: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.bind(
            "<Configure>",
            lambda event: canvas.itemconfigure(holder_window, width=event.width),
        )
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.question_buttons = LinkedList()
        index = 0

        while index < len(self.exam_questions):
            # index là vị trí câu trong đề sau khi xáo trộn.
            # question_id là mã trong ngân hàng; hai khái niệm này không giống nhau.
            button = tk.Button(
                button_holder,
                text=str(index + 1),
                width=4,
                height=2,
                font=("Arial", 10, "bold"),
                command=lambda selected_index=index: self.go_to_question(selected_index),
            )
            button.grid(
                row=index // 4,
                column=index % 4,
                padx=4,
                pady=4,
                sticky="nsew",
            )
            self.question_buttons.append((index, button))
            index += 1

        row_index = 0
        while row_index < 4:
            button_holder.columnconfigure(row_index, weight=1)
            row_index += 1

        self.progress_label = ttk.Label(
            question_frame,
            text="",
            style="Subheading.TLabel",
        )
        self.progress_label.pack(anchor="w", pady=(0, 8))

        self.question_subject_label = ttk.Label(
            question_frame,
            text="",
            style="Body.TLabel",
        )
        self.question_subject_label.pack(anchor="w", pady=(0, 12))

        self.question_content_label = ttk.Label(
            question_frame,
            text="",
            font=("Arial", 15, "bold"),
            wraplength=760,
            justify="left",
        )
        self.question_content_label.pack(anchor="w", fill="x", pady=(0, 18))

        self.answer_variable = tk.StringVar(value="")
        self.option_buttons = LinkedList()

        # option_keys là ký hiệu hiển thị của bốn đáp án.
        # Nội dung đáp án nằm trong Question.option_a/b/c/d.
        option_keys = ("A", "B", "C", "D")

        for key in option_keys:
            option_button = ttk.Radiobutton(
                question_frame,
                text="",
                value=key,
                variable=self.answer_variable,
                command=self.record_selected_answer,
                style="Exam.TRadiobutton",
            )
            option_button.pack(anchor="w", fill="x", pady=4)
            self.option_buttons.append(option_button)

        self.answer_info_label = ttk.Label(
            question_frame,
            text="",
            style="Body.TLabel",
        )
        self.answer_info_label.pack(anchor="w", pady=(12, 8))

        control_frame = ttk.Frame(question_frame)
        control_frame.pack(side="bottom", fill="x", pady=(20, 5))

        ttk.Button(control_frame, text="← Câu trước", style="Action.TButton", command=self.previous_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Bỏ qua", style="Action.TButton", command=self.skip_current_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Câu tiếp →", style="Action.TButton", command=self.next_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Nộp bài", style="Action.TButton", command=lambda: self.submit_exam(False)).pack(side="right", padx=5)

        ttk.Label(
            question_frame,
            text="Phím tắt: A/B/C/D chọn đáp án, ←/→ chuyển câu, S bỏ qua, Q nộp bài.",
            style="Body.TLabel",
        ).pack(side="bottom", anchor="w", pady=(8, 0))

        self.load_current_question()
        self.update_timer()

    def load_current_question(self):
        """
        Đưa dữ liệu của câu hiện tại lên màn hình làm bài.

        Hàm được gọi bởi:
        - show_exam_screen() khi vừa mở màn hình.
        - go_to_question(), previous_question(), next_question(), skip_current_question().

        Hàm gọi:
        - update_question_button_styles() để tô màu tiến độ các nút câu.

        Tham số:
            Không có tham số ngoài self. Câu hiện tại lấy từ exam_questions
            theo current_question_index.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Cập nhật text của progress_label, question_subject_label,
            question_content_label, option_buttons, answer_variable
            và answer_info_label.

        Lưu ý:
            Đáp án đúng không được hiển thị trong lúc làm bài. Chỉ nội dung
            bốn phương án đã xáo trộn được đưa lên radio button.
        """

        question = self.exam_questions[self.current_question_index]
        difficulty = "Dễ" if question.difficulty == "DE" else "Khó"

        self.progress_label.configure(
            text=(
                f"Câu {self.current_question_index + 1}/{len(self.exam_questions)}"
            )
        )
        self.question_subject_label.configure(
            text=f"Chủ đề: {question.subject} | Độ khó: {difficulty}"
        )
        self.question_content_label.configure(text=question.content)

        option_texts = LinkedList()
        option_texts.append(question.option_a)
        option_texts.append(question.option_b)
        option_texts.append(question.option_c)
        option_texts.append(question.option_d)

        index = 0

        for button in self.option_buttons:
            # key là ký hiệu A/B/C/D hiển thị trên giao diện.
            # option_texts[index] là nội dung đáp án tương ứng sau khi xáo trộn.
            key = chr(ord("A") + index)
            button.configure(text=f"{key}. {option_texts[index]}")
            index += 1

        self.answer_variable.set(question.user_answer)

        if question.is_answered:
            self.answer_info_label.configure(
                text=f"Đáp án đã chọn: {question.user_answer}"
            )
        elif question.is_skipped:
            self.answer_info_label.configure(text="Câu này: đã đánh dấu bỏ qua")
        else:
            self.answer_info_label.configure(text="Câu này: chưa trả lời")

        self.update_question_button_styles()

    def record_selected_answer(self):
        """
        Lưu đáp án thí sinh vừa chọn cho câu hiện tại.

        Hàm được gọi bởi:
        - Các Radiobutton trong show_exam_screen().
        - handle_exam_key() khi người dùng nhấn phím A/B/C/D.

        Hàm gọi:
        - update_question_button_styles().

        Tham số:
            Không có tham số ngoài self. Đáp án lấy từ answer_variable.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Cập nhật user_answer, is_answered, is_skipped của Question hiện tại.

        Lưu ý:
            user_answer lưu ký hiệu A/B/C/D sau khi đáp án đã xáo trộn.
            Khi chấm điểm, calculate_exam_counts() so sánh ký hiệu này với
            question.correct_answer đã được cập nhật sau xáo trộn.
        """

        if not self.exam_active:
            return

        answer = self.answer_variable.get()

        if answer == "":
            return

        question = self.exam_questions[self.current_question_index]
        question.user_answer = answer
        question.is_answered = True
        question.is_skipped = False
        self.answer_info_label.configure(text=f"Đáp án đã chọn: {answer}")
        self.update_question_button_styles()

    def update_question_button_styles(self):
        """
        Tô màu các nút số câu theo tiến độ làm bài.

        Hàm được gọi bởi:
        - load_current_question().
        - record_selected_answer().
        - skip_current_question().

        Hàm gọi:
        - button.configure() của Tkinter.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Màu nền và màu chữ của các nút câu hỏi.

        Ý nghĩa màu:
            - Xanh dương: câu đang xem.
            - Xanh lá: đã trả lời.
            - Vàng: bỏ qua.
            - Xám: chưa trả lời.
        """

        for item in self.question_buttons:
            index, button = item
            question = self.exam_questions[index]

            if index == self.current_question_index:
                background = "#2563eb"
                foreground = "white"
            elif question.is_answered:
                background = "#16a34a"
                foreground = "white"
            elif question.is_skipped:
                background = "#f59e0b"
                foreground = "black"
            else:
                background = "#e5e7eb"
                foreground = "black"

            button.configure(
                bg=background,
                fg=foreground,
                activebackground=background,
                activeforeground=foreground,
            )

    def go_to_question(self, index):
        """
        Chuyển đến câu hỏi theo vị trí trong đề.

        Hàm được gọi bởi:
        - Nút số câu trong show_exam_screen().

        Hàm gọi:
        - load_current_question().

        Tham số:
            index:
                int, vị trí câu trong self.exam_questions, bắt đầu từ 0.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            current_question_index được cập nhật nếu index hợp lệ.
        """

        if index < 0 or index >= len(self.exam_questions):
            return

        self.current_question_index = index
        self.load_current_question()

    def previous_question(self):
        """
        Chuyển sang câu trước câu hiện tại.

        Hàm được gọi bởi:
        - Nút "Câu trước".
        - handle_exam_key() khi nhấn phím mũi tên trái.

        Hàm gọi:
        - load_current_question().
        - messagebox.showinfo() nếu đang ở câu đầu tiên.

        Trả về:
            None.
        """

        if self.current_question_index > 0:
            self.current_question_index -= 1
            self.load_current_question()
        else:
            messagebox.showinfo("Thông báo", "Bạn đang ở câu đầu tiên.", parent=self)

    def next_question(self):
        """
        Chuyển sang câu kế tiếp.

        Hàm được gọi bởi:
        - Nút "Câu tiếp".
        - handle_exam_key() khi nhấn phím mũi tên phải.

        Hàm gọi:
        - load_current_question().
        - messagebox.showinfo() nếu đang ở câu cuối.

        Trả về:
            None.
        """

        if self.current_question_index < len(self.exam_questions) - 1:
            self.current_question_index += 1
            self.load_current_question()
        else:
            messagebox.showinfo("Thông báo", "Bạn đang ở câu cuối cùng.", parent=self)

    def skip_current_question(self):
        """
        Đánh dấu câu hiện tại là bỏ qua và chuyển sang câu tiếp nếu có.

        Hàm được gọi bởi:
        - Nút "Bỏ qua".
        - handle_exam_key() khi nhấn phím S.

        Hàm gọi:
        - update_question_button_styles().
        - load_current_question().

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            user_answer được xóa, is_answered đặt False, is_skipped đặt True
            cho câu hiện tại.
        """

        question = self.exam_questions[self.current_question_index]
        question.user_answer = ""
        question.is_answered = False
        question.is_skipped = True
        self.answer_variable.set("")
        self.update_question_button_styles()

        if self.current_question_index < len(self.exam_questions) - 1:
            self.current_question_index += 1

        self.load_current_question()

    def update_timer(self):
        """
        Cập nhật đồng hồ đếm ngược trên giao diện và tự kết thúc bài khi hết giờ.

        Hàm được gọi bởi:
        - show_exam_screen() ngay sau khi màn hình làm bài được dựng.
        - Chính update_timer() thông qua self.after(250, self.update_timer).

        Hàm gọi:
        - time.monotonic() để tính thời gian còn lại.
        - submit_exam(True) khi remaining <= 0.
        - self.after() của Tkinter để lên lịch gọi lại.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Cập nhật timer_label và timer_job.

        Cơ chế Tkinter:
            self.after(250, self.update_timer) yêu cầu Tkinter gọi lại hàm này
            sau khoảng 250 mili-giây. Hàm tự lên lịch lại cho đến khi bài thi
            dừng hoặc đã nộp.

        Cách tránh nộp hai lần:
            Nếu exam_active False hoặc exam_submitted True, hàm kết thúc ngay.
            submit_exam() cũng kiểm tra hai cờ này trước khi xử lý.
        """

        if not self.exam_active or self.exam_submitted:
            return

        # remaining là thời gian còn lại. exam_deadline là mốc hết giờ tuyệt đối.
        remaining = int(self.exam_deadline - time.monotonic())

        if remaining < 0:
            remaining = 0

        minutes = remaining // 60
        seconds = remaining % 60
        self.timer_label.configure(text=f"Còn lại: {minutes:02d}:{seconds:02d}")

        if remaining <= 0:
            # True báo cho submit_exam() biết bài được kết thúc do hết giờ.
            self.submit_exam(True)
            return

        self.timer_job = self.after(250, self.update_timer)

    def submit_exam(self, auto_submit=False):
        """
        Nộp bài, chấm điểm, lưu kết quả và chuyển sang màn hình kết quả.

        Hàm được gọi bởi:
        - Nút "Nộp bài" trong show_exam_screen().
        - handle_exam_key() khi nhấn phím Q.
        - update_timer() khi hết giờ.

        Hàm gọi:
        - messagebox.askyesno() nếu thí sinh tự bấm nộp bài.
        - cancel_timer() để dừng đồng hồ.
        - calculate_exam_counts() để đếm đúng/sai; câu bỏ qua được tính là sai.
        - load_results() và next_exam_id() để tạo mã lần thi.
        - subject_list_to_text() để lưu chủ đề.
        - ExamResult() để tạo đối tượng kết quả.
        - append_result() để ghi DATA/results.txt.
        - show_exam_result_screen() để hiển thị kết quả.

        Tham số:
            auto_submit:
                bool, True nếu bài kết thúc do hết giờ; False nếu thí sinh tự bấm nộp.

        Trả về:
            None.

        Dữ liệu hoặc file bị thay đổi:
            - exam_submitted đặt True và exam_active đặt False.
            - last_result lưu ExamResult mới nhất.
            - DATA/results.txt được ghi thêm một dòng.

        Cách tính điểm:
            Điểm hệ 10 = số câu đúng * 10 / tổng số câu.

        Cách tránh nộp hai lần:
            Nếu exam_active False hoặc exam_submitted True, hàm return ngay.
        """

        if not self.exam_active or self.exam_submitted:
            return

        if not auto_submit:
            confirmed = messagebox.askyesno(
                "Xác nhận nộp bài",
                "Bạn chắc chắn muốn nộp bài?",
                parent=self,
            )

            if not confirmed:
                return

        self.exam_submitted = True
        self.exam_active = False
        self.cancel_timer()

        # used_seconds là thời gian đã dùng thực tế từ lúc bắt đầu đến khi nộp.
        used_seconds = int(time.monotonic() - self.exam_started_at)

        if used_seconds > self.limit_seconds:
            used_seconds = self.limit_seconds

        # counts giữ hai số theo thứ tự: đúng, sai.
        # Câu bỏ qua hoặc chưa trả lời đều đã được calculate_exam_counts()
        # cộng vào số câu sai.
        counts = calculate_exam_counts(self.exam_questions)
        correct_count = counts[0]
        wrong_count = counts[1]
        score_ten = correct_count * 10.0 / len(self.exam_questions)
        result = ExamResult(
            next_exam_id(load_results()),
            self.candidate_id,
            self.candidate_name,
            datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            subject_list_to_text(self.selected_subjects),
            len(self.exam_questions),
            correct_count,
            wrong_count,
            score_ten,
            self.limit_seconds,
            used_seconds,
        )
        append_result(result)
        self.last_result = result

        if auto_submit:
            messagebox.showinfo(
                "Hết giờ",
                "Thời gian đã hết. Bài làm được kết thúc và chấm điểm.",
                parent=self,
            )

        self.show_exam_result_screen()

    def handle_exam_key(self, event):
        """
        Xử lý phím tắt trong lúc làm bài.

        Hàm được gọi bởi:
        - Sự kiện self.bind("<Key>", self.handle_exam_key) trong __init__().

        Hàm gọi:
        - record_selected_answer() khi nhấn A/B/C/D.
        - previous_question() khi nhấn mũi tên trái.
        - next_question() khi nhấn mũi tên phải.
        - skip_current_question() khi nhấn S.
        - submit_exam(False) khi nhấn Q.

        Tham số:
            event:
                Đối tượng sự kiện Tkinter, chứa event.keysym là tên phím.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Có thể thay đổi câu trả lời, vị trí câu hiện tại hoặc nộp bài.
        """

        if not self.exam_active or self.exam_submitted:
            return

        key = event.keysym.upper()

        if key == "A" or key == "B" or key == "C" or key == "D":
            self.answer_variable.set(key)
            self.record_selected_answer()
        elif key == "LEFT":
            self.previous_question()
        elif key == "RIGHT":
            self.next_question()
        elif key == "S":
            self.skip_current_question()
        elif key == "Q":
            self.submit_exam(False)

    def show_exam_result_screen(self):
        """
        Hiển thị kết quả của lần thi vừa nộp.

        Hàm được gọi bởi:
        - submit_exam() sau khi lưu kết quả.

        Hàm gọi:
        - create_page().
        - show_exam_review_screen() nếu bấm xem đáp án chi tiết.
        - show_results_screen() nếu bấm xem lịch sử.
        - show_home_screen() nếu quay về menu chính.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ self.last_result.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Dựng lại màn hình Tkinter để hiển thị kết quả.
        """

        result = self.last_result
        page = self.create_page(
            "KẾT QUẢ BÀI THI",
            "Kết quả đã được lưu vào DATA/results.txt.",
        )

        card = ttk.LabelFrame(page, text=f"Lần thi {result.exam_id}", padding=24)
        card.pack(fill="x", padx=120, pady=20)
        card.columnconfigure(1, weight=1)

        rows = LinkedList()
        rows.append(("Thí sinh", f"{result.candidate_id} - {result.candidate_name}"))
        rows.append(("Chủ đề", result.subjects))
        rows.append(("Tổng số câu", str(result.total_questions)))
        rows.append(("Số câu đúng", str(result.correct_count)))
        rows.append(("Số câu sai", str(result.wrong_count)))
        rows.append(("Điểm hệ 10", f"{result.score_ten:.2f}"))
        rows.append(("Thời gian dùng", format_seconds(result.used_seconds)))

        row_number = 0

        for label_text, value_text in rows:
            ttk.Label(card, text=f"{label_text}:", style="Subheading.TLabel").grid(
                row=row_number,
                column=0,
                sticky="w",
                padx=(0, 25),
                pady=5,
            )
            ttk.Label(card, text=value_text, style="Body.TLabel").grid(
                row=row_number,
                column=1,
                sticky="w",
                pady=5,
            )
            row_number += 1

        button_frame = ttk.Frame(page)
        button_frame.pack(pady=16)

        ttk.Button(button_frame, text="Xem đáp án chi tiết", style="Large.TButton", command=self.show_exam_review_screen).pack(side="left", padx=8)

        ttk.Button(button_frame, text="Xem lịch sử kết quả", style="Large.TButton", command=self.show_results_screen).pack(side="left", padx=8)

        ttk.Button(button_frame, text="Về menu chính", style="Large.TButton", command=self.show_home_screen).pack(side="left", padx=8)

    def show_exam_review_screen(self):
        """
        Hiển thị bảng đối chiếu đáp án của bài vừa nộp.

        Hàm được gọi bởi:
        - Nút "Xem đáp án chi tiết" trong show_exam_result_screen().

        Hàm gọi:
        - create_page().
        - show_exam_result_screen() khi bấm quay lại kết quả.
        - Hàm lồng show_review_detail() khi chọn một dòng trong bảng.

        Tham số:
            Không có tham số ngoài self. Dữ liệu lấy từ self.exam_questions.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Dựng bảng review_table và ô detail_text trên giao diện.

        Lưu ý:
            Màn hình này chỉ xuất hiện sau khi bài đã nộp. Trong lúc làm bài,
            đáp án đúng không được hiển thị.
        """

        page = self.create_page(
            "ĐỐI CHIẾU ĐÁP ÁN",
            "Chọn một dòng để xem nội dung và bốn phương án chi tiết.",
        )

        toolbar = ttk.Frame(page)
        toolbar.pack(fill="x", pady=(0, 10))
        ttk.Button(toolbar, text="Quay lại kết quả", command=self.show_exam_result_screen).pack(side="right")

        content = ttk.Panedwindow(page, orient="vertical")
        content.pack(fill="both", expand=True)

        table_frame = ttk.Frame(content)
        detail_frame = ttk.LabelFrame(content, text="Chi tiết", padding=10)
        content.add(table_frame, weight=3)
        content.add(detail_frame, weight=2)

        review_table = ttk.Treeview(
            table_frame,
            columns=("number", "subject", "user", "correct", "result"),
            show="headings",
            selectmode="browse",
        )
        review_table.heading("number", text="Câu")
        review_table.heading("subject", text="Chủ đề")
        review_table.heading("user", text="Bạn chọn")
        review_table.heading("correct", text="Đáp án đúng")
        review_table.heading("result", text="Kết quả")
        review_table.column("number", width=60, anchor="center", stretch=False)
        review_table.column("subject", width=170)
        review_table.column("user", width=110, anchor="center")
        review_table.column("correct", width=110, anchor="center")
        review_table.column("result", width=110, anchor="center")

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=review_table.yview)
        review_table.configure(yscrollcommand=scroll.set)
        review_table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        detail_text = tk.Text(
            detail_frame,
            height=10,
            wrap="word",
            font=("Arial", 11),
            state="disabled",
        )
        detail_text.pack(fill="both", expand=True)

        index = 0

        for question in self.exam_questions:
            # user_answer là ký hiệu thí sinh chọn; correct_answer là ký hiệu đúng
            # sau khi đáp án đã được xáo trộn.
            if question.user_answer == "":
                user_answer = "Bỏ qua"
                review_result = "SAI"
            elif question.user_answer == question.correct_answer:
                user_answer = question.user_answer
                review_result = "ĐÚNG"
            else:
                user_answer = question.user_answer
                review_result = "SAI"

            review_table.insert(
                "",
                "end",
                iid=str(index),
                values=(
                    index + 1,
                    question.subject,
                    user_answer,
                    question.correct_answer,
                    review_result,
                ),
            )
            index += 1

        def show_review_detail(_event=None):
            """
            Hiển thị chi tiết câu được chọn trong bảng đối chiếu.

            Hàm lồng này được gọi bởi:
            - Sự kiện <<TreeviewSelect>> của review_table.
            - Chính show_exam_review_screen() sau khi chọn mặc định dòng đầu.

            Hàm gọi:
            - detail_text.configure(), delete(), insert() của Tkinter.

            Tham số:
                _event:
                    Sự kiện Tkinter, không cần dùng nên đặt tên có dấu gạch dưới.

            Trả về:
                None.

            Dữ liệu bị thay đổi:
                Nội dung ô detail_text trên màn hình đối chiếu.
            """

            selected = review_table.selection()

            if len(selected) == 0:
                return

            try:
                selected_index = int(selected[0])
            except ValueError:
                return

            question = self.exam_questions[selected_index]
            user_answer = question.user_answer if question.user_answer != "" else "Bỏ qua"
            detail = (
                f"Câu {selected_index + 1}: {question.content}\n\n"
                f"A. {question.option_a}\n"
                f"B. {question.option_b}\n"
                f"C. {question.option_c}\n"
                f"D. {question.option_d}\n\n"
                f"Bạn chọn: {user_answer}\n"
                f"Đáp án đúng: {question.correct_answer}"
            )
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", detail)
            detail_text.configure(state="disabled")

        review_table.bind("<<TreeviewSelect>>", show_review_detail)

        if len(self.exam_questions) > 0:
            review_table.selection_set("0")
            review_table.focus("0")
            show_review_detail()

    def show_results_screen(self):
        """
        Hiển thị màn hình lịch sử kết quả thi trong GUI.

        Hàm được gọi bởi:
        - show_home_screen().
        - show_exam_result_screen().

        Hàm gọi:
        - create_page().
        - search_result_records() khi bấm tìm kiếm hoặc nhấn Enter.
        - refresh_result_table() để tải dữ liệu kết quả.
        - show_result_detail() khi chọn một dòng trong bảng.
        - show_home_screen() khi quay lại menu chính.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Tạo result_search_entry, result_table, result_detail và
            current_result_records.

        Lưu ý:
            Màn hình này chỉ đọc và hiển thị lịch sử. Thí sinh không có nút
            xóa hoặc sửa kết quả.
        """

        self.exam_active = False
        page = self.create_page(
            "BÁO CÁO KẾT QUẢ",
            "Có thể tìm theo mã hoặc tên thí sinh và xem chi tiết từng lần thi.",
        )

        toolbar = ttk.Frame(page)
        toolbar.pack(fill="x", pady=(0, 10))

        ttk.Label(toolbar, text="Từ khóa:").pack(side="left")
        self.result_search_entry = ttk.Entry(toolbar, width=30)
        self.result_search_entry.pack(side="left", padx=8)
        self.result_search_entry.bind(
            "<Return>",
            lambda _event: self.search_result_records(),
        )

        ttk.Button(toolbar, text="Tìm kiếm", command=self.search_result_records).pack(side="left", padx=4)

        ttk.Button(toolbar, text="Xem tất cả", command=self.refresh_result_table).pack(side="left", padx=4)

        ttk.Button(toolbar, text="Quay lại menu chính", command=self.show_home_screen).pack(side="right")

        content = ttk.Panedwindow(page, orient="vertical")
        content.pack(fill="both", expand=True)

        table_frame = ttk.Frame(content)
        detail_frame = ttk.LabelFrame(content, text="Chi tiết lần thi", padding=10)
        content.add(table_frame, weight=3)
        content.add(detail_frame, weight=2)

        columns = (
            "exam_id",
            "candidate_id",
            "name",
            "time",
            "subjects",
            "score",
            "correct",
            "wrong",
            "used",
        )
        self.result_table = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
        )

        headings = (
            ("exam_id", "Lần"),
            ("candidate_id", "Mã TS"),
            ("name", "Họ tên"),
            ("time", "Thời điểm"),
            ("subjects", "Chủ đề"),
            ("score", "Điểm"),
            ("correct", "Đúng"),
            ("wrong", "Sai"),
            ("used", "Thời gian"),
        )

        for key, title in headings:
            self.result_table.heading(key, text=title)

        self.result_table.column("exam_id", width=55, anchor="center", stretch=False)
        self.result_table.column("candidate_id", width=95, anchor="center")
        self.result_table.column("name", width=170)
        self.result_table.column("time", width=150)
        self.result_table.column("subjects", width=190)
        self.result_table.column("score", width=70, anchor="center")
        self.result_table.column("correct", width=60, anchor="center")
        self.result_table.column("wrong", width=60, anchor="center")
        self.result_table.column("used", width=105, anchor="center")

        vertical_scroll = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.result_table.yview,
        )
        horizontal_scroll = ttk.Scrollbar(
            table_frame,
            orient="horizontal",
            command=self.result_table.xview,
        )
        self.result_table.configure(
            yscrollcommand=vertical_scroll.set,
            xscrollcommand=horizontal_scroll.set,
        )
        self.result_table.grid(row=0, column=0, sticky="nsew")
        vertical_scroll.grid(row=0, column=1, sticky="ns")
        horizontal_scroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        self.result_table.bind("<<TreeviewSelect>>", self.show_result_detail)

        self.result_detail = tk.Text(
            detail_frame,
            height=9,
            wrap="word",
            font=("Arial", 11),
            state="disabled",
        )
        self.result_detail.pack(fill="both", expand=True)

        self.current_result_records = LinkedList()
        self.refresh_result_table()

    def set_result_detail_text(self, content):
        """
        Ghi nội dung vào ô chi tiết kết quả ở trạng thái chỉ đọc.

        Hàm được gọi bởi:
        - refresh_result_table().
        - show_result_detail().

        Hàm gọi:
        - Các phương thức configure(), delete(), insert() của Text widget.

        Tham số:
            content:
                str, nội dung cần hiển thị.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Nội dung của self.result_detail trên giao diện.
        """

        if self.result_detail is None or not self.result_detail.winfo_exists():
            return

        self.result_detail.configure(state="normal")
        self.result_detail.delete("1.0", "end")
        self.result_detail.insert("1.0", content)
        self.result_detail.configure(state="disabled")

    def refresh_result_table(self, records=None):
        """
        Nạp dữ liệu vào bảng lịch sử kết quả.

        Hàm được gọi bởi:
        - show_results_screen() khi mở màn hình.
        - search_result_records() để hiển thị kết quả đã lọc.
        - Nút "Xem tất cả".

        Hàm gọi:
        - load_results() nếu records là None.
        - set_result_detail_text() để cập nhật dòng tổng kết.

        Tham số:
            records:
                LinkedList<ExamResult> hoặc None. Nếu None, đọc toàn bộ lịch sử.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Xóa và thêm lại các dòng trong self.result_table.
            Cập nhật self.current_result_records để show_result_detail() tìm đúng dữ liệu.
        """

        if self.result_table is None or not self.result_table.winfo_exists():
            return

        if records is None:
            records = load_results()

        # current_result_records là danh sách đang hiển thị, có thể là toàn bộ
        # lịch sử hoặc chỉ các kết quả khớp từ khóa.
        self.current_result_records = records

        for item in self.result_table.get_children():
            self.result_table.delete(item)

        for result in records:
            self.result_table.insert(
                "",
                "end",
                iid=str(result.exam_id),
                values=(
                    result.exam_id,
                    result.candidate_id,
                    result.candidate_name,
                    result.exam_time_text,
                    result.subjects,
                    f"{result.score_ten:.2f}",
                    result.correct_count,
                    result.wrong_count,
                    format_seconds(result.used_seconds),
                ),
            )

        self.set_result_detail_text(f"Tổng số kết quả đang hiển thị: {len(records)}")

    def search_result_records(self):
        """
        Lọc lịch sử thi theo mã hoặc tên thí sinh trong GUI.

        Hàm được gọi bởi:
        - Nút "Tìm kiếm".
        - Phím Enter trong result_search_entry.

        Hàm gọi:
        - normalize_spaces() để xử lý từ khóa.
        - load_results() để đọc toàn bộ lịch sử.
        - contains_text() để so khớp mã/tên.
        - refresh_result_table() để hiển thị danh sách đã lọc.

        Tham số:
            Không có tham số ngoài self.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Bảng kết quả và current_result_records được cập nhật.

        Thuật toán:
            Duyệt tuần tự từng ExamResult, không dùng hàm tìm kiếm có sẵn.
        """

        keyword = normalize_spaces(self.result_search_entry.get())

        if keyword == "":
            self.refresh_result_table()
            return

        matched = LinkedList()

        for result in load_results():
            if contains_text(result.candidate_id, keyword) or contains_text(
                result.candidate_name,
                keyword,
            ):
                matched.append(result)

        self.refresh_result_table(matched)

        if len(matched) == 0:
            messagebox.showinfo(
                "Không tìm thấy",
                "Không có kết quả phù hợp với từ khóa.",
                parent=self,
            )

    def find_result_by_exam_id(self, exam_id):
        """
        Tìm ExamResult trong danh sách đang hiển thị theo mã lần thi.

        Hàm được gọi bởi:
        - show_result_detail().

        Hàm gọi:
        - Không gọi hàm tự định nghĩa nào khác.

        Tham số:
            exam_id:
                int, mã lần thi cần tìm.

        Trả về:
            ExamResult nếu tìm thấy; None nếu không có trong current_result_records.

        Dữ liệu bị thay đổi:
            Không thay đổi danh sách.

        Lưu ý:
            Hàm tìm trong current_result_records, tức là dữ liệu đang hiển thị,
            không nhất thiết là toàn bộ lịch sử nếu người dùng đang lọc.
        """

        for result in self.current_result_records:
            if result.exam_id == exam_id:
                return result

        return None

    def show_result_detail(self, _event=None):
        """
        Hiển thị chi tiết lần thi đang được chọn trong bảng lịch sử.

        Hàm được gọi bởi:
        - Sự kiện <<TreeviewSelect>> của self.result_table.

        Hàm gọi:
        - find_result_by_exam_id().
        - format_seconds().
        - set_result_detail_text().

        Tham số:
            _event:
                Sự kiện Tkinter, không cần dùng trực tiếp.

        Trả về:
            None.

        Dữ liệu bị thay đổi:
            Nội dung self.result_detail được cập nhật theo dòng đang chọn.
        """

        selected = self.result_table.selection()

        if len(selected) == 0:
            return

        try:
            exam_id = int(selected[0])
        except ValueError:
            return

        result = self.find_result_by_exam_id(exam_id)

        if result is None:
            return

        detail = (
            f"Mã lần thi: {result.exam_id}\n"
            f"Mã thí sinh: {result.candidate_id}\n"
            f"Họ và tên: {result.candidate_name}\n"
            f"Thời điểm: {result.exam_time_text}\n"
            f"Chủ đề: {result.subjects}\n\n"
            f"Tổng số câu: {result.total_questions}\n"
            f"Đúng/Sai: "
            f"{result.correct_count}/{result.wrong_count}\n"
            f"Điểm hệ 10: {result.score_ten:.2f}\n"
            f"Thời gian quy định: {format_seconds(result.limit_seconds)}\n"
            f"Thời gian đã dùng: {format_seconds(result.used_seconds)}"
        )
        self.set_result_detail_text(detail)

if __name__ == "__main__":
    app = QuizApplication()
    app.mainloop()


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA FILE
#
# QuizApplication()
# ├── __init__()
# │   ├── ensure_data_files()
# │   ├── configure_styles()
# │   └── show_home_screen()
# │       ├── load_results()
# │       ├── show_exam_setup_screen()
# │       ├── show_results_screen()
# │       └── handle_close()
#
# show_exam_setup_screen()
# ├── load_questions()
# ├── get_unique_subjects(questions)
# ├── update_eligible_question_count()
# │   ├── get_selected_subjects_from_setup()
# │   ├── get_selected_difficulty_code()
# │   ├── load_questions()
# │   └── collect_eligible_questions(...)
# └── begin_exam_from_setup()
#     ├── normalize_spaces(...)
#     ├── get_selected_subjects_from_setup()
#     ├── get_selected_difficulty_code()
#     ├── load_questions()
#     ├── collect_eligible_questions(...)
#     ├── generate_exam(...)
#     └── show_exam_screen()
#
# show_exam_screen()
# ├── load_current_question()
# │   └── update_question_button_styles()
# ├── update_timer()
# │   ├── update_timer() qua self.after(...)
# │   └── submit_exam(True) khi hết giờ
# ├── record_selected_answer()
# ├── previous_question()
# ├── next_question()
# ├── skip_current_question()
# ├── handle_exam_key(event)
# └── submit_exam(False)
#     ├── cancel_timer()
#     ├── calculate_exam_counts(exam_questions)
#     ├── load_results()
#     ├── next_exam_id(...)
#     ├── subject_list_to_text(selected_subjects)
#     ├── ExamResult(...)
#     ├── append_result(result)
#     └── show_exam_result_screen()
#
# show_exam_result_screen()
# ├── show_exam_review_screen()
# ├── show_results_screen()
# └── show_home_screen()
#
# show_results_screen()
# ├── refresh_result_table()
# │   ├── load_results()
# │   └── set_result_detail_text(...)
# ├── search_result_records()
# │   ├── normalize_spaces(...)
# │   ├── load_results()
# │   ├── contains_text(...)
# │   └── refresh_result_table(matched)
# └── show_result_detail()
#     ├── find_result_by_exam_id(exam_id)
#     ├── format_seconds(...)
#     └── set_result_detail_text(...)
# ============================================================
