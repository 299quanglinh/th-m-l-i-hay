"""
File khởi động chương trình thi trắc nghiệm ở giao diện console.

Nên đọc file này như thế nào:
1. Đọc phần import để biết main.py chỉ đóng vai trò điều phối.
2. Đọc main() từ trên xuống dưới để hiểu menu chính.
3. Khi gặp start_exam(), chuyển sang modules/exam.py.
4. Khi gặp results_menu(), chuyển sang modules/results.py.

Nhiệm vụ chính:
- Chuẩn bị file dữ liệu trước khi chương trình chạy.
- Hiển thị menu chính dành cho thí sinh.
- Nhận lựa chọn từ bàn phím.
- Gọi luồng làm bài thi hoặc luồng xem kết quả.
- Kết thúc chương trình khi thí sinh chọn thoát.

File này thuộc phần:
- Chương trình console. Giao diện Tkinter nằm trong app_gui.py.

File này import:
- modules.exam.start_exam để tổ chức toàn bộ quá trình thi trên console.
- modules.file_manager.ensure_data_files để đảm bảo thư mục DATA và file dữ liệu tồn tại.
- modules.results.results_menu để hiển thị lịch sử kết quả thi.

File này được gọi hoặc sử dụng bởi:
- Người dùng chạy trực tiếp bằng lệnh python main.py.
- File chay_chuong_trinh.bat nếu batch file được dùng để mở chương trình.

Các hàm chính:
- main(): vòng lặp menu chính của chương trình console.

Dữ liệu đi vào:
- Lựa chọn chức năng do thí sinh nhập từ bàn phím.
- Dữ liệu câu hỏi và kết quả được các module con đọc từ DATA khi được gọi.

Dữ liệu đi ra:
- Thông tin menu, câu hỏi, kết quả và thông báo được in ra console.
- Khi làm bài xong, modules.exam.start_exam() tạo ExamResult và lưu vào DATA/results.txt.

Quan hệ với các file còn lại:
- main.py không trực tiếp đọc questions.txt hoặc results.txt.
- main.py chỉ điều phối: chọn thi thì gọi modules.exam, chọn xem kết quả thì gọi modules.results.
"""

from modules.exam import start_exam
from modules.file_manager import ensure_data_files
from modules.results import results_menu


def main():
    """ 
    Chạy vòng lặp menu chính của chương trình console.

    Hàm được gọi bởi:
    - Khối if __name__ == "__main__" ở cuối file.

    Hàm gọi:
    - ensure_data_files() khi khởi động.
    - start_exam() nếu thí sinh chọn bắt đầu thi.
    - results_menu() nếu thí sinh chọn xem kết quả.

    Tham số:
        Không có tham số. Dữ liệu vào là lựa chọn nhập từ bàn phím.

    Trả về:
        None. Hàm kết thúc khi người dùng chọn 0.

    Dữ liệu hoặc file bị thay đổi:
        - ensure_data_files() có thể tạo DATA/questions.txt hoặc DATA/results.txt
          nếu file chưa tồn tại.
        - start_exam() có thể ghi thêm kết quả mới vào DATA/results.txt.
        - main() không tự sửa dữ liệu.

    Trường hợp đặc biệt:
        Nếu nhập lựa chọn không hợp lệ, vòng lặp tiếp tục hiển thị menu.

    Vị trí trong luồng hoạt động chung:
        Đây là điểm vào của chương trình console. Từ đây dữ liệu được chuyển
        sang modules.exam hoặc modules.results tùy lựa chọn của thí sinh.
    """

    # ============================================================
    # GIAI ĐOẠN 1: KHỞI ĐỘNG CHƯƠNG TRÌNH
    # ============================================================
    # Đảm bảo thư mục DATA và các file dữ liệu tồn tại trước khi menu chạy.
    # Nếu file đã có dữ liệu, ensure_data_files() không ghi đè.
    ensure_data_files()

    # Vòng lặp này giúp menu quay lại sau khi thí sinh làm bài xong
    # hoặc xem lịch sử xong. Chỉ lựa chọn "0" mới kết thúc chương trình.
    while True:

        print("\n========== CHƯƠNG TRÌNH THI TRẮC NGHIỆM ==========\n")
        print("1. Bắt đầu thi")
        print("2. Xem kết quả thi")
        print("0. Thoát chương trình")

        # choice lưu lựa chọn dạng chuỗi để so sánh trực tiếp với "1", "2", "0".
        choice = input("Chọn chức năng: ").strip()

        if choice == "1":

            # start_exam() thực hiện toàn bộ luồng thi:
            # - nhập thông tin thí sinh;
            # - đọc ngân hàng câu hỏi bằng load_questions();
            # - chọn chủ đề, mức độ, số câu và thời gian;
            # - lọc câu hỏi bằng collect_eligible_questions();
            # - chọn và xáo trộn câu hỏi bằng generate_exam();
            # - xáo trộn đáp án trong shuffle_question_options();
            # - bắt đầu tính giờ trong run_exam_session();
            # - nhận câu trả lời đến khi nộp bài hoặc hết giờ;
            # - chấm điểm bằng calculate_exam_counts();
            # - tạo ExamResult và lưu bằng append_result().
            start_exam()
        elif choice == "2":
            results_menu()
        elif choice == "0":
            print("Chương trình đã kết thúc.")
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        # KeyboardInterrupt xảy ra khi người dùng nhấn Ctrl+C trên console.
        print("\nChương trình đã bị người dùng dừng.")


# ============================================================
# SƠ ĐỒ GỌI HÀM CỦA MAIN.PY
#
# main()
# ├── ensure_data_files()
# ├── nếu chọn "1. Bắt đầu thi"
# │   └── start_exam()
# │       └── xem chi tiết trong modules/exam.py
# ├── nếu chọn "2. Xem kết quả thi"
# │   └── results_menu()
# │       └── xem chi tiết trong modules/results.py
# └── nếu chọn "0. Thoát chương trình"
#     └── return để kết thúc vòng lặp menu
#
# main.py không trực tiếp đọc questions.txt và không trực tiếp ghi results.txt.
# Việc đọc/ghi file được giao cho modules/file_manager.py.
# ============================================================

