"""Sinh đề, tổ chức thi có giới hạn thời gian và chấm điểm tự động.

Mô-đun sử dụng thư viện ``inputimeout`` đúng theo yêu cầu của người dùng.
Mỗi lần chờ nhập, thời gian timeout chính là số giây còn lại của toàn bài.
Khi hết giờ, ``TimeoutOccurred`` được phát sinh và chương trình tự nộp bài.
"""

import time
from datetime import datetime

from inputimeout import TimeoutOccurred, inputimeout

from modules.file_manager import (
    append_result,
    load_questions,
    load_results,
    next_exam_id,
)
from modules.linked_list import LinkedList
from modules.models import AnswerOption, ExamResult
from modules.random_utils import RandomGenerator, fisher_yates_shuffle
from modules.text_utils import format_seconds, split_words
from modules.validation import input_integer, input_non_empty


DIFFICULTY_ALL = "ALL"


def contains_subject(subjects, subject):
    """Kiểm tra tên môn đã có trong danh sách, không phân biệt hoa/thường."""
    for existing_subject in subjects:
        if existing_subject.lower() == subject.lower():
            return True

    return False


def get_unique_subjects(questions):
    """Lấy danh sách môn/chủ đề không trùng bằng tìm kiếm tuần tự."""
    subjects = LinkedList()

    for question in questions:
        if not contains_subject(subjects, question.subject):
            subjects.append(question.subject)

    return subjects


def choose_subjects(available_subjects):
    """Cho phép chọn một hoặc nhiều môn bằng các số cách nhau bởi dấu cách."""
    while True:
        print("\n========== CHỌN MÔN/CHỦ ĐỀ ==========")
        index = 1

        for subject in available_subjects:
            print(f"{index}. {subject}")
            index += 1

        raw_choices = input(
            "Nhập các số muốn chọn, cách nhau bởi dấu cách (ví dụ 1 3): "
        )
        choice_parts = split_words(raw_choices)
        selected_subjects = LinkedList()
        valid = True

        if len(choice_parts) == 0:
            valid = False

        for part in choice_parts:
            try:
                selected_index = int(part) - 1
            except ValueError:
                valid = False
                break

            if selected_index < 0 or selected_index >= len(available_subjects):
                valid = False
                break

            selected_subject = available_subjects[selected_index]

            if not contains_subject(selected_subjects, selected_subject):
                selected_subjects.append(selected_subject)

        if valid and len(selected_subjects) > 0:
            return selected_subjects

        print("Danh sách lựa chọn không hợp lệ. Vui lòng nhập lại.")


def choose_difficulty():
    """Chọn phạm vi độ khó: Dễ, Khó hoặc cả hai."""
    while True:
        print("\n========== CHỌN ĐỘ KHÓ ==========")
        print("1. Chỉ câu Dễ")
        print("2. Chỉ câu Khó")
        print("3. Cả Dễ và Khó")
        choice = input("Chọn độ khó: ").strip()

        if choice == "1":
            return "DE"
        if choice == "2":
            return "KHO"
        if choice == "3":
            return DIFFICULTY_ALL

        print("Lựa chọn không hợp lệ.")


def collect_eligible_questions(questions, selected_subjects, difficulty):
    """Lọc câu hỏi theo môn và độ khó bằng một lần duyệt tuần tự."""
    eligible = LinkedList()

    for question in questions:
        subject_match = contains_subject(selected_subjects,question.subject)
        difficulty_match = (
            difficulty == DIFFICULTY_ALL or question.difficulty == difficulty
        )

        if subject_match and difficulty_match:
            eligible.append(question)

    return eligible


def subject_list_to_text(subjects):
    """Ghép các môn đã chọn thành chuỗi dùng trong báo cáo."""
    result = ""
    index = 0

    for subject in subjects:
        if index > 0:
            result += ", "
        result += subject
        index += 1

    return result


def shuffle_question_options(question, generator):
    """Xáo trộn bốn phương án và cập nhật đáp án đúng an toàn.

    Mỗi phương án được gói trong ``AnswerOption`` cùng cờ ``is_correct``.
    Vì cờ này đi cùng nội dung khi hoán đổi, thuật toán vẫn đúng ngay cả
    khi hai phương án có nội dung giống hệt nhau.
    """
    options = LinkedList()
    options.append(AnswerOption(question.option_a, question.correct_answer == "A"))
    options.append(AnswerOption(question.option_b, question.correct_answer == "B"))
    options.append(AnswerOption(question.option_c, question.correct_answer == "C"))
    options.append(AnswerOption(question.option_d, question.correct_answer == "D"))

    fisher_yates_shuffle(options, generator)

    question.option_a = options[0].text
    question.option_b = options[1].text
    question.option_c = options[2].text
    question.option_d = options[3].text

    if options[0].is_correct:
        question.correct_answer = "A"
    elif options[1].is_correct:
        question.correct_answer = "B"
    elif options[2].is_correct:
        question.correct_answer = "C"
    else:
        question.correct_answer = "D"


def generate_exam(eligible_questions, number_of_questions, generator):
    """Sinh đề không trùng câu bằng Fisher–Yates.

    Bước 1: sao chép nông danh sách ứng viên.
    Bước 2: xáo trộn toàn bộ danh sách ứng viên.
    Bước 3: lấy ``number_of_questions`` phần tử đầu, clone và xáo đáp án.
    """
    shuffled_candidates = eligible_questions.copy_shallow()
    fisher_yates_shuffle(shuffled_candidates, generator)
    exam_questions = LinkedList()
    index = 0

    while index < number_of_questions:
        exam_question = shuffled_candidates[index].clone()
        shuffle_question_options(exam_question, generator)
        exam_questions.append(exam_question)
        index += 1

    # Xáo trộn thêm lần cuối để thể hiện rõ bước sinh thứ tự đề.
    fisher_yates_shuffle(exam_questions, generator)
    return exam_questions


def display_question_status(exam_questions, current_index):
    """Hiển thị trạng thái tất cả câu: đã làm, bỏ qua hoặc chưa làm."""
    status_line = ""
    index = 0

    for question in exam_questions:
        if question.is_answered:
            symbol = "✓"
        elif question.is_skipped:
            symbol = "×"
        else:
            symbol = "•"

        number = index + 1

        if index == current_index:
            status_line += f"[{number}{symbol}] "
        else:
            status_line += f" {number}{symbol}  "

        index += 1

    print("Trạng thái:", status_line.strip())


def display_exam_question(question, current_index, total, remaining_seconds):
    """Hiển thị câu hỏi hiện tại và thời gian còn lại."""
    print("\n" + "=" * 72)
    print(
        f"CÂU {current_index + 1}/{total} | "
        f"Môn: {question.subject} | "
        f"Còn lại: {format_seconds(remaining_seconds)}"
    )
    print("-" * 72)
    print(question.content)
    print(f"A. {question.option_a}")
    print(f"B. {question.option_b}")
    print(f"C. {question.option_c}")
    print(f"D. {question.option_d}")

    if question.is_answered:
        print(f"Đáp án đã chọn: {question.user_answer}")
    elif question.is_skipped:
        print("Trạng thái: đã đánh dấu bỏ qua")


def timed_confirm_submit(remaining_seconds):
    """Xác nhận nộp bài nhưng vẫn chịu giới hạn thời gian toàn bài."""
    try:
        answer = inputimeout(
            prompt="Xác nhận nộp bài? (Y/N): ",
            timeout=max(0.1, remaining_seconds),
        )
    except TimeoutOccurred:
        return "TIMEOUT"

    return answer.strip().upper()


def run_exam_session(exam_questions, limit_seconds):
    """Điều khiển quá trình làm bài và tự thu khi hết giờ.

    Các lệnh:
    - A/B/C/D: chọn đáp án và chuyển tới câu tiếp theo.
    - N: câu tiếp theo.
    - P: câu trước.
    - S: bỏ qua câu hiện tại.
    - Q: nộp bài sớm.
    """
    start_time = time.monotonic()
    deadline = start_time + limit_seconds
    current_index = 0
    submit_status = "Nộp bài chủ động"

    while True:
        remaining = deadline - time.monotonic()

        if remaining <= 0:
            submit_status = "Hết giờ - tự động thu bài"
            print("\nHết giờ! Hệ thống đã tự động thu bài.")
            break

        current_question = exam_questions[current_index]
        display_exam_question(
            current_question,
            current_index,
            len(exam_questions),
            remaining,
        )
        display_question_status(exam_questions, current_index)
        print("Lệnh: A/B/C/D = trả lời | N = tiếp | P = trước | S = bỏ qua | Q = nộp")

        try:
            command = inputimeout(
                prompt="Nhập lựa chọn: ",
                timeout=max(0.1, remaining),
            ).strip().upper()
        except TimeoutOccurred:
            submit_status = "Hết giờ - tự động thu bài"
            print("\nHết giờ! Hệ thống đã tự động thu bài.")
            break

        # Kiểm tra lại ngay sau khi nhập để không nhận đáp án quá hạn.
        if time.monotonic() >= deadline:
            submit_status = "Hết giờ - tự động thu bài"
            print("\nHết giờ! Hệ thống đã tự động thu bài.")
            break

        if command == "A" or command == "B" or command == "C" or command == "D":
            current_question.user_answer = command
            current_question.is_answered = True
            current_question.is_skipped = False

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "N":
            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("Bạn đang ở câu cuối cùng.")
        elif command == "P":
            if current_index > 0:
                current_index -= 1
            else:
                print("Bạn đang ở câu đầu tiên.")
        elif command == "S":
            current_question.user_answer = ""
            current_question.is_answered = False
            current_question.is_skipped = True

            if current_index < len(exam_questions) - 1:
                current_index += 1
        elif command == "Q":
            remaining = deadline - time.monotonic()
            confirmation = timed_confirm_submit(remaining)

            if confirmation == "TIMEOUT":
                submit_status = "Hết giờ - tự động thu bài"
                print("\nHết giờ! Hệ thống đã tự động thu bài.")
                break

            if confirmation == "Y":
                submit_status = "Nộp bài chủ động"
                break
        else:
            print("Lệnh không hợp lệ. Vui lòng nhập lại.")

    used_seconds = int(time.monotonic() - start_time)

    if used_seconds > limit_seconds:
        used_seconds = limit_seconds

    return submit_status, used_seconds


def calculate_exam_counts(exam_questions):
    """Đếm số câu đúng, sai và bỏ qua bằng một lần duyệt."""
    correct_count = 0
    wrong_count = 0
    skipped_count = 0

    for question in exam_questions:
        if question.user_answer == "":
            skipped_count += 1
        elif question.user_answer == question.correct_answer:
            correct_count += 1
        else:
            wrong_count += 1

    counts = LinkedList()
    counts.append(correct_count)
    counts.append(wrong_count)
    counts.append(skipped_count)
    return counts


def show_exam_review(exam_questions):
    """Hiển thị đối chiếu đáp án sau khi bài thi đã kết thúc."""
    print("\n========== ĐỐI CHIẾU ĐÁP ÁN ==========")
    index = 1

    for question in exam_questions:
        user_answer = question.user_answer

        if user_answer == "":
            user_answer = "Bỏ qua"

        status = "ĐÚNG" if question.user_answer == question.correct_answer else "SAI"
        print("-" * 72)
        print(f"Câu {index}: {question.content}")
        print(f"Bạn chọn: {user_answer}")
        print(f"Đáp án đúng: {question.correct_answer}")
        print(f"Kết quả: {status}")
        index += 1


def start_exam():
    """Thực hiện trọn quy trình: cấu hình, sinh đề, thi, chấm và lưu."""
    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi đang trống. Hãy thêm câu hỏi trước.")
        return

    print("\n========== THÔNG TIN THÍ SINH ==========")
    candidate_id = input_non_empty("Nhập mã thí sinh: ")
    candidate_name = input_non_empty("Nhập họ và tên: ")

    available_subjects = get_unique_subjects(questions)
    selected_subjects = choose_subjects(available_subjects)
    difficulty = choose_difficulty()
    eligible_questions = collect_eligible_questions(
        questions, selected_subjects, difficulty
    )

    if len(eligible_questions) == 0:
        print("Không có câu hỏi phù hợp.")
        return

    print(f"Số câu phù hợp hiện có: {len(eligible_questions)}")
    number_of_questions = input_integer(
        "Nhập số lượng câu hỏi của đề: ",
        1,
        len(eligible_questions),
    )
    minutes = input_integer("Nhập thời gian làm bài (phút): ", 1, 180)
    limit_seconds = minutes * 60

    generator = RandomGenerator()
    exam_questions = generate_exam(
        eligible_questions,
        number_of_questions,
        generator,
    )

    input("Nhấn Enter để bắt đầu làm bài...")

    submit_status, used_seconds = run_exam_session(
        exam_questions,
        limit_seconds,
    )

    counts = calculate_exam_counts(exam_questions)
    correct_count = counts[0]
    wrong_count = counts[1]
    skipped_count = counts[2]
    score_ten = correct_count * 10.0 / len(exam_questions)

    previous_results = load_results()
    result = ExamResult(
        next_exam_id(previous_results),
        candidate_id,
        candidate_name,
        datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        subject_list_to_text(selected_subjects),
        len(exam_questions),
        correct_count,
        wrong_count,
        skipped_count,
        score_ten,
        limit_seconds,
        used_seconds,
        submit_status,
    )
    append_result(result)

    print("\n========== KẾT QUẢ BÀI THI ==========")
    print(f"Số câu đúng  : {correct_count}")
    print(f"Số câu sai   : {wrong_count}")
    print(f"Số câu bỏ qua: {skipped_count}")
    print(f"Điểm hệ 10   : {score_ten:.2f}")
    print(f"Thời gian dùng: {format_seconds(used_seconds)}")
    print(f"Trạng thái: {submit_status}")

    review_choice = input("Bạn có muốn xem đáp án chi tiết? (Y/N): ").strip().upper()

    if review_choice == "Y":
        show_exam_review(exam_questions)
