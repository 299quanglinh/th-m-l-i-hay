"""Cấu trúc danh sách liên kết đơn tự cài đặt.

Mục tiêu của mô-đun này là thay thế các thao tác thường làm bằng ``list``
của Python. Chương trình không dùng ``append``, ``sort`` hoặc tìm kiếm có sẵn
trên ``list`` mà tự quản lý từng nút dữ liệu.
"""


class Node:
    """Biểu diễn một nút trong danh sách liên kết đơn.

    Mỗi nút lưu một giá trị ``data`` và tham chiếu ``next`` tới nút kế tiếp.
    Nút cuối cùng có ``next = None``.
    """

    def __init__(self, data):
        """Khởi tạo nút với dữ liệu ban đầu và chưa có nút kế tiếp."""
        self.data = data
        self.next = None


class LinkedList:
    """Danh sách liên kết đơn có con trỏ đầu, cuối và biến đếm kích thước.

    Các thao tác chính:
    - ``append``: thêm cuối trong O(1) nhờ con trỏ ``tail``.
    - ``get``/``set``: truy cập theo chỉ số trong O(n).
    - ``remove_at``: xóa tại vị trí cho trước trong O(n).
    - ``swap``: đổi dữ liệu của hai nút, phục vụ xáo trộn và sắp xếp.
    - ``contains``: tìm kiếm tuần tự một giá trị.
    """

    def __init__(self):
        """Khởi tạo danh sách rỗng với kích thước bằng 0."""
        self.head = None
        self.tail = None
        self._size = 0

    def append(self, data):
        """Thêm ``data`` vào cuối danh sách.

        Khi danh sách rỗng, nút mới đồng thời là đầu và cuối. Khi danh sách
        đã có phần tử, nối nút mới sau ``tail`` rồi cập nhật ``tail``.
        """
        new_node = Node(data)

        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

        self._size += 1

    def prepend(self, data):
        """Thêm ``data`` vào đầu danh sách.

        Hàm này không bắt buộc cho đề tài nhưng hữu ích khi cần chèn nhanh
        một phần tử ở đầu mà không phải duyệt danh sách.
        """
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

        if self.tail is None:
            self.tail = new_node

        self._size += 1

    def insert(self, index, data):
        """Chèn ``data`` vào vị trí ``index``.

        ``index = 0`` tương đương thêm đầu; ``index = size`` tương đương
        thêm cuối. Mọi chỉ số ngoài đoạn hợp lệ đều gây ``IndexError``.
        """
        if index < 0 or index > self._size:
            raise IndexError("Chỉ số chèn nằm ngoài phạm vi danh sách.")

        if index == 0:
            self.prepend(data)
            return

        if index == self._size:
            self.append(data)
            return

        previous = self._get_node(index - 1)
        new_node = Node(data)
        new_node.next = previous.next
        previous.next = new_node
        self._size += 1

    def get(self, index):
        """Trả về dữ liệu tại vị trí ``index``.

        Do đây là danh sách liên kết, hàm phải duyệt từ đầu tới vị trí cần
        lấy nên độ phức tạp là O(n).
        """
        return self._get_node(index).data

    def set(self, index, data):
        """Thay dữ liệu tại vị trí ``index`` bằng ``data``."""
        self._get_node(index).data = data

    def remove_at(self, index):
        """Xóa và trả về dữ liệu tại vị trí ``index``.

        Hàm cập nhật chính xác ``head`` và ``tail`` để danh sách vẫn hợp lệ
        sau khi xóa phần tử đầu, cuối hoặc phần tử duy nhất.
        """
        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số xóa nằm ngoài phạm vi danh sách.")

        if index == 0:
            removed_node = self.head
            self.head = self.head.next
            self._size -= 1

            if self._size == 0:
                self.tail = None

            return removed_node.data

        previous = self._get_node(index - 1)
        removed_node = previous.next
        previous.next = removed_node.next

        if removed_node is self.tail:
            self.tail = previous

        self._size -= 1
        return removed_node.data

    def clear(self):
        """Xóa toàn bộ phần tử bằng cách bỏ các tham chiếu đầu và cuối."""
        self.head = None
        self.tail = None
        self._size = 0

    def contains(self, item):
        """Tìm tuần tự xem ``item`` có xuất hiện trong danh sách hay không."""
        current = self.head

        while current is not None:
            if current.data == item:
                return True
            current = current.next

        return False

    def index_of(self, item):
        """Trả về vị trí đầu tiên của ``item`` hoặc -1 nếu không tìm thấy."""
        current = self.head
        index = 0

        while current is not None:
            if current.data == item:
                return index
            current = current.next
            index += 1

        return -1

    def swap(self, first_index, second_index):
        """Hoán đổi dữ liệu của hai vị trí.

        Chỉ đổi trường ``data`` thay vì đổi liên kết giữa các nút. Cách này
        đơn giản, ít lỗi và đủ dùng cho Fisher–Yates/selection sort.
        """
        if first_index == second_index:
            return

        first_node = self._get_node(first_index)
        second_node = self._get_node(second_index)
        temporary = first_node.data
        first_node.data = second_node.data
        second_node.data = temporary

    def copy_shallow(self):
        """Tạo một danh sách mới chứa cùng các tham chiếu dữ liệu.

        Đây là sao chép nông: các nút mới hoàn toàn độc lập, nhưng dữ liệu
        bên trong nút vẫn là cùng đối tượng. Khi cần độc lập tuyệt đối, lớp
        dữ liệu phải tự cung cấp hàm ``clone``.
        """
        copied = LinkedList()
        current = self.head

        while current is not None:
            copied.append(current.data)
            current = current.next

        return copied

    def _get_node(self, index):
        """Trả về nút tại ``index``; đây là hàm hỗ trợ dùng nội bộ."""
        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số truy cập nằm ngoài phạm vi danh sách.")

        current = self.head
        current_index = 0

        while current_index < index:
            current = current.next
            current_index += 1

        return current

    def __len__(self):
        """Cho phép dùng ``len(linked_list)`` trong O(1)."""
        return self._size

    def __iter__(self):
        """Cho phép duyệt tuần tự bằng vòng lặp ``for``."""
        current = self.head

        while current is not None:
            yield current.data
            current = current.next

    def __getitem__(self, index):
        """Cho phép viết ``linked_list[index]`` thay cho ``get(index)``."""
        return self.get(index)

    def __setitem__(self, index, data):
        """Cho phép viết ``linked_list[index] = data`` thay cho ``set``."""
        self.set(index, data)

    def __contains__(self, item):
        """Cho phép dùng toán tử ``in`` nhưng vẫn chạy tìm kiếm tự cài đặt."""
        return self.contains(item)
