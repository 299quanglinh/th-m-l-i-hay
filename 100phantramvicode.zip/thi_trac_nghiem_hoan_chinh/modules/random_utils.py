"""Bộ sinh số giả ngẫu nhiên và thuật toán Fisher–Yates tự cài đặt.

Chương trình không dùng ``random.shuffle``. Bộ sinh LCG tạo số giả ngẫu
nhiên, sau đó Fisher–Yates tạo hoán vị đồng đều nếu nguồn số ngẫu nhiên đủ
tốt cho mục đích mô phỏng đề thi đơn giản.
"""

import time


class RandomGenerator:
    """Bộ sinh số giả ngẫu nhiên tuyến tính đồng dư (LCG)."""

    def __init__(self, seed=None):
        """Khởi tạo bộ sinh với seed truyền vào hoặc thời gian hiện tại."""
        # Dùng thời gian nano làm seed mặc định để mỗi lần chạy khác nhau.
        if seed is None:
            seed = time.time_ns()

        self.modulus = 2147483648
        self.multiplier = 1103515245
        self.increment = 12345
        self.state = int(seed) % self.modulus

    def next_integer(self, minimum, maximum):
        """Sinh số nguyên trong đoạn đóng [minimum, maximum]."""
        if minimum > maximum:
            raise ValueError("Cận dưới không được lớn hơn cận trên.")

        self.state = (
            self.multiplier * self.state + self.increment
        ) % self.modulus

        interval_size = maximum - minimum + 1
        return minimum + self.state % interval_size


def fisher_yates_shuffle(linked_list, generator):
    """Xáo trộn ``linked_list`` bằng Fisher–Yates.

    Tại bước ``i``, chọn ngẫu nhiên ``j`` trong [0, i] rồi hoán đổi hai phần
    tử. Thuật toán chạy từ cuối về đầu và không cần cấu trúc phụ trợ.
    """
    index = len(linked_list) - 1

    while index > 0:
        random_index = generator.next_integer(0, index)
        linked_list.swap(index, random_index)
        index -= 1
