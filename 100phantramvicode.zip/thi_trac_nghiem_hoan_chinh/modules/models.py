"""Các lớp dữ liệu chính của chương trình.

Thay vì dùng ``dict`` để lưu câu hỏi và kết quả, chương trình định nghĩa
các lớp rõ ràng. Cách này giúp kiểm soát thuộc tính, tránh lỗi sai tên khóa
và phù hợp yêu cầu không dùng cấu trúc hash có sẵn.
"""


class Question:
    """Biểu diễn một câu hỏi trắc nghiệm có bốn phương án."""

    def __init__(
        self,
        question_id,
        subject,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    ):
        """Khởi tạo đầy đủ thông tin của một câu hỏi."""
        self.question_id = question_id
        self.subject = subject
        self.difficulty = difficulty
        self.content = content
        self.option_a = option_a
        self.option_b = option_b
        self.option_c = option_c
        self.option_d = option_d
        self.correct_answer = correct_answer

        # Ba thuộc tính dưới chỉ dùng trong một lần thi.
        self.user_answer = ""
        self.is_answered = False
        self.is_skipped = False

    def get_option(self, key):
        """Trả về nội dung phương án tương ứng với A, B, C hoặc D."""
        upper_key = key.upper()

        if upper_key == "A":
            return self.option_a
        if upper_key == "B":
            return self.option_b
        if upper_key == "C":
            return self.option_c
        if upper_key == "D":
            return self.option_d

        raise ValueError("Khóa phương án phải là A, B, C hoặc D.")


    def clone(self):
        """Tạo bản sao độc lập để dùng trong đề thi.

        Ngân hàng câu hỏi không bị thay đổi khi đề thi xáo trộn phương án
        hoặc ghi đáp án của thí sinh.
        """
        return Question(
            self.question_id,
            self.subject,
            self.difficulty,
            self.content,
            self.option_a,
            self.option_b,
            self.option_c,
            self.option_d,
            self.correct_answer,
        )

    def reset_exam_state(self):
        """Xóa trạng thái trả lời trước khi đưa câu hỏi vào đề mới."""
        self.user_answer = ""
        self.is_answered = False
        self.is_skipped = False


class AnswerOption:
    """Phần tử trung gian dùng khi xáo trộn bốn phương án.

    Trường ``is_correct`` đi theo nội dung phương án trong suốt quá trình
    hoán đổi nên không bị lỗi khi hai phương án có nội dung giống nhau.
    """

    def __init__(self, text, is_correct):
        """Khởi tạo nội dung phương án và cờ cho biết có đúng hay không."""
        self.text = text
        self.is_correct = is_correct


class ExamResult:
    """Lưu toàn bộ thông tin cần thiết của một lần thi."""

    def __init__(
        self,
        exam_id,
        candidate_id,
        candidate_name,
        exam_time_text,
        subjects,
        total_questions,
        correct_count,
        wrong_count,
        skipped_count,
        score_ten,
        limit_seconds,
        used_seconds,
        submit_status,
    ):
        """Khởi tạo một bản ghi kết quả thi hoàn chỉnh."""
        self.exam_id = exam_id
        self.candidate_id = candidate_id
        self.candidate_name = candidate_name
        self.exam_time_text = exam_time_text
        self.subjects = subjects
        self.total_questions = total_questions
        self.correct_count = correct_count
        self.wrong_count = wrong_count
        self.skipped_count = skipped_count
        self.score_ten = score_ten
        self.limit_seconds = limit_seconds
        self.used_seconds = used_seconds
        self.submit_status = submit_status
