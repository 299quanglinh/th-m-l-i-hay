
"""Báo cáo và xử lý lịch sử nhiều lần thi.

Mô-đun hỗ trợ:
- Xem toàn bộ kết quả thi.
- Tìm kiếm tuần tự theo mã hoặc tên thí sinh.
- Xóa toàn bộ lịch sử kết quả.
"""

from modules.file_manager import clear_results_file, load_results
from modules.linked_list import LinkedList
from modules.text_utils import contains_text, format_seconds
from modules.validation import confirm, input_non_empty


def display_result(result, index=None):
    """Hiển thị chi tiết một bản ghi kết quả thi."""
    title = f"LẦN THI {result.exam_id}"

    if index is not None:
        title = f"KẾT QUẢ {index} - LẦN THI {result.exam_id}"

    print("-" * 72)
    print(title)
    print(f"Mã thí sinh : {result.candidate_id}")
    print(f"Họ và tên   : {result.candidate_name}")
    print(f"Thời điểm   : {result.exam_time_text}")
    print(f"Môn/chủ đề  : {result.subjects}")

    print(
        f"Đúng/Sai/Bỏ qua: "
        f"{result.correct_count}/"
        f"{result.wrong_count}/"
        f"{result.skipped_count}"
    )

    print(f"Tổng số câu : {result.total_questions}")
    print(f"Điểm hệ 10  : {result.score_ten:.2f}")
    print(
        f"Thời gian quy định: "
        f"{format_seconds(result.limit_seconds)}"
    )
    print(
        f"Thời gian đã dùng : "
        f"{format_seconds(result.used_seconds)}"
    )
    print(f"Trạng thái nộp bài: {result.submit_status}")


def show_results(results=None):
    """Hiển thị toàn bộ kết quả thi.

    Tham số ``results`` cho phép hàm tái sử dụng để hiển thị
    danh sách kết quả sau khi tìm kiếm.
    """
    if results is None:
        results = load_results()

    if len(results) == 0:
        print("Chưa có kết quả thi nào.")
        return

    print("\n========== BÁO CÁO KẾT QUẢ ==========")

    index = 1

    for result in results:
        display_result(result, index)
        index += 1

    print("-" * 72)
    print(f"Tổng số lần thi: {len(results)}")


def search_results():
    """Tìm tuần tự kết quả theo mã hoặc tên thí sinh."""
    results = load_results()

    if len(results) == 0:
        print("Chưa có kết quả thi nào.")
        return

    keyword = input_non_empty(
        "Nhập mã hoặc tên thí sinh cần tìm: "
    )

    matched_results = LinkedList()

    for result in results:
        found_by_id = contains_text(
            result.candidate_id,
            keyword,
        )

        found_by_name = contains_text(
            result.candidate_name,
            keyword,
        )

        if found_by_id or found_by_name:
            matched_results.append(result)

    if len(matched_results) == 0:
        print("Không tìm thấy kết quả phù hợp.")
        return

    show_results(matched_results)


def clear_results():
    """Xóa toàn bộ lịch sử sau khi người dùng xác nhận."""
    confirmed = confirm(
        "Bạn chắc chắn muốn xóa toàn bộ lịch sử?"
    )

    if not confirmed:
        print("Đã hủy thao tác xóa.")
        return

    clear_results_file()
    print("Đã xóa toàn bộ lịch sử kết quả.")


def results_menu():
    """Hiển thị menu báo cáo cho đến khi người dùng quay lại."""
    while True:
        print("\n========== BÁO CÁO KẾT QUẢ ==========")
        print("1. Xem toàn bộ kết quả")
        print("2. Tìm theo mã hoặc tên thí sinh")
        print("3. Xóa toàn bộ lịch sử")
        print("0. Quay lại menu chính")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_results()

        elif choice == "2":
            search_results()

        elif choice == "3":
            clear_results()

        elif choice == "0":
            return

        else:
            print("Lựa chọn không hợp lệ.")
