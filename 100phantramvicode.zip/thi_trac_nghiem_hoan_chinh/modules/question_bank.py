"""Các chức năng quản lý ngân hàng câu hỏi.

Người quản trị có thể xem, thêm và xóa câu hỏi.
Mọi thao tác đều làm việc trên ``LinkedList`` và lưu lại xuống file text.
"""

from modules.file_manager import (
    load_questions,
    next_question_id,
    save_questions,
)
from modules.linked_list import LinkedList
from modules.models import Question
from modules.validation import confirm, input_choice, input_integer, input_non_empty


def difficulty_name(code):
    """Đổi mã độ khó thành tên tiếng Việt dùng khi hiển thị."""
    if code == "DE":
        return "Dễ"
    return "Khó"


def display_question(question, index=None):
    """Hiển thị đầy đủ một câu hỏi và bốn phương án."""
    prefix = ""

    if index is not None:
        prefix = f"[{index}] "

    print("-" * 72)
    print(
        f"{prefix}ID: {question.question_id} | "
        f"Môn/chủ đề: {question.subject} | "
        f"Độ khó: {difficulty_name(question.difficulty)}"
    )
    print(f"Câu hỏi: {question.content}")
    print(f"A. {question.option_a}")
    print(f"B. {question.option_b}")
    print(f"C. {question.option_c}")
    print(f"D. {question.option_d}")
    print(f"Đáp án đúng: {question.correct_answer}")


def show_all_questions():
    """Đọc file và hiển thị toàn bộ ngân hàng câu hỏi."""
    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi đang trống.")
        return

    print("\n========== DANH SÁCH CÂU HỎI ==========")
    index = 1

    for question in questions:
        display_question(question, index)
        index += 1

    print("-" * 72)
    print(f"Tổng số câu hỏi: {len(questions)}")


def input_difficulty():
    """Nhập độ khó và trả về mã DE hoặc KHO."""
    valid_choices = LinkedList()
    valid_choices.append("1")
    valid_choices.append("2")

    print("1. Dễ")
    print("2. Khó")

    choice = input_choice("Chọn độ khó: ", valid_choices)

    if choice == "1":
        return "DE"

    return "KHO"

def input_correct_answer():
    """Nhập đáp án đúng A, B, C hoặc D."""
    valid_choices = LinkedList()
    valid_choices.append("A")
    valid_choices.append("B")
    valid_choices.append("C")
    valid_choices.append("D")

    return input_choice(
        "Nhập đáp án đúng (A/B/C/D): ",
        valid_choices,
    )


def add_question():
    """Nhập một câu hỏi mới, thêm vào cuối danh sách và lưu file."""
    questions = load_questions()
    question_id = next_question_id(questions)

    print("\n========== THÊM CÂU HỎI ==========")
    subject = input_non_empty("Nhập môn/chủ đề: ")
    difficulty = input_difficulty()
    content = input_non_empty("Nhập nội dung câu hỏi: ")
    option_a = input_non_empty("Nhập phương án A: ")
    option_b = input_non_empty("Nhập phương án B: ")
    option_c = input_non_empty("Nhập phương án C: ")
    option_d = input_non_empty("Nhập phương án D: ")
    correct_answer = input_correct_answer()

    new_question = Question(
        question_id,
        subject,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    )

    questions.append(new_question)
    save_questions(questions)
    print(f"Đã thêm câu hỏi có ID {question_id}.")

def find_question_index_by_id(questions, question_id):
    """Tìm tuần tự vị trí câu hỏi theo ID; trả -1 nếu không có."""
    index = 0

    for question in questions:
        if question.question_id == question_id:
            return index
        index += 1

    return -1

def delete_question():
    """Xóa một câu hỏi theo ID sau khi người dùng xác nhận."""
    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi đang trống.")
        return

    question_id = input_integer("Nhập ID câu hỏi cần xóa: ", 1)
    index = find_question_index_by_id(questions, question_id)

    if index == -1:
        print("Không tìm thấy câu hỏi có ID này.")
        return

    display_question(questions[index])

    if not confirm("Bạn chắc chắn muốn xóa câu hỏi này?"):
        print("Đã hủy thao tác xóa.")
        return

    questions.remove_at(index)
    save_questions(questions)
    print("Đã xóa câu hỏi.")

def question_bank_menu():
    """Menu lặp của phân hệ quản lý ngân hàng câu hỏi."""
    while True:
        print("\n========== QUẢN LÝ NGÂN HÀNG CÂU HỎI ==========")
        print("1. Xem toàn bộ câu hỏi")
        print("2. Thêm câu hỏi")
        print("3. Xóa câu hỏi")
        print("0. Quay lại menu chính")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_all_questions()
        elif choice == "2":
            add_question()
        elif choice == "3":
            delete_question()
        elif choice == "0":
            return
        else:
            print("Lựa chọn không hợp lệ.")
