"""Các thuật toán xử lý chuỗi tự cài đặt cho file text và tìm kiếm.

Tệp dữ liệu dùng ký tự ``|`` để ngăn cách trường. Vì nội dung câu hỏi có
thể chứa ký tự đặc biệt, mô-đun cung cấp cơ chế mã hóa/giải mã đơn giản:
- ``\\``  -> ``\\\\``
- ``|``   -> ``\\p``
- xuống dòng -> ``\\n``
"""

from modules.linked_list import LinkedList


def escape_field(text):
    """Mã hóa một trường trước khi ghi vào file text."""
    source = str(text)
    result = ""

    for character in source:
        if character == "\\":
            result += "\\\\"
        elif character == "|":
            result += "\\p"
        elif character == "\n":
            result += "\\n"
        elif character == "\r":
            # Bỏ ký tự carriage return để thống nhất dữ liệu giữa Windows/Linux.
            continue
        else:
            result += character

    return result


def join_record(fields):
    """Ghép các trường trong ``LinkedList`` thành một dòng dữ liệu.

    Hàm tự ghép chuỗi thay vì dùng ``str.join`` trên list. Mỗi trường được
    mã hóa trước khi thêm ký tự phân cách ``|``.
    """
    result = ""
    index = 0

    for field in fields:
        if index > 0:
            result += "|"
        result += escape_field(field)
        index += 1

    return result


def parse_record(line):
    """Tách một dòng dữ liệu thành ``LinkedList`` các trường đã giải mã.

    Thuật toán duyệt từng ký tự và theo dõi trạng thái ``escaping``. Ký tự
    ``|`` chỉ được coi là dấu phân cách khi không đứng sau dấu ``\\``.
    """
    fields = LinkedList()
    current_field = ""
    escaping = False

    for character in line.rstrip("\n"):
        if escaping:
            if character == "n":
                current_field += "\n"
            elif character == "p":
                current_field += "|"
            elif character == "\\":
                current_field += "\\"
            else:
                # Nếu gặp mã không biết, giữ lại ký tự để tránh mất dữ liệu.
                current_field += character
            escaping = False
        elif character == "\\":
            escaping = True
        elif character == "|":
            fields.append(current_field)
            current_field = ""
        else:
            current_field += character

    if escaping:
        # Dòng kết thúc bằng dấu gạch chéo đơn: giữ lại như dữ liệu thường.
        current_field += "\\"

    fields.append(current_field)
    return fields


def split_words(text):
    """Tách chuỗi theo khoảng trắng và trả về ``LinkedList``.

    Nhiều khoảng trắng liên tiếp được coi như một dấu phân cách. Hàm này
    được dùng khi người dùng nhập nhiều lựa chọn chủ đề, ví dụ ``1 2 3``.
    """
    parts = LinkedList()
    current = ""

    for character in text:
        if character.isspace():
            if current != "":
                parts.append(current)
                current = ""
        else:
            current += character

    if current != "":
        parts.append(current)

    return parts


def contains_text(source, keyword):
    """Tìm chuỗi con bằng thuật toán tìm kiếm tuần tự đơn giản.

    Hàm không dùng ``in`` hay thư viện tìm kiếm. So sánh không phân biệt
    hoa/thường. Với ``n`` là độ dài nguồn và ``m`` là độ dài từ khóa, độ
    phức tạp xấu nhất là O(n*m).
    """
    source_lower = source.lower()
    keyword_lower = keyword.lower()

    if keyword_lower == "":
        return True

    if len(keyword_lower) > len(source_lower):
        return False

    start = 0
    last_start = len(source_lower) - len(keyword_lower)

    while start <= last_start:
        matched = True
        offset = 0

        while offset < len(keyword_lower):
            if source_lower[start + offset] != keyword_lower[offset]:
                matched = False
                break
            offset += 1

        if matched:
            return True

        start += 1

    return False


def normalize_spaces(text):
    """Loại khoảng trắng thừa ở đầu/cuối và gộp nhiều khoảng trắng.

    Hàm giúp dữ liệu tên thí sinh, tên môn và nội dung hiển thị đồng nhất.
    """
    result = ""
    previous_was_space = False

    for character in text.strip():
        if character.isspace():
            if not previous_was_space:
                result += " "
                previous_was_space = True
        else:
            result += character
            previous_was_space = False

    return result


def format_seconds(total_seconds):
    """Đổi số giây thành chuỗi ``phút giây`` dễ đọc."""
    safe_seconds = int(total_seconds)

    if safe_seconds < 0:
        safe_seconds = 0

    minutes = safe_seconds // 60
    seconds = safe_seconds % 60
    return f"{minutes} phút {seconds} giây"
