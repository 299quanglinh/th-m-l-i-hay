"""Các hàm nhập liệu có kiểm tra lỗi.

Mọi dữ liệu từ bàn phím đều được xác thực trước khi dùng. Đây là phần áp
dụng lập trình phòng ngừa: không giả định người dùng luôn nhập đúng.
"""

from modules.text_utils import normalize_spaces


def input_non_empty(prompt):
    """Yêu cầu người dùng nhập một chuỗi không rỗng."""
    while True:
        value = normalize_spaces(input(prompt))

        if value != "":
            return value

        print("Dữ liệu không được để trống. Vui lòng nhập lại.")


def input_integer(prompt, minimum=None, maximum=None):
    """Nhập số nguyên và kiểm tra miền giá trị tùy chọn.

    ``minimum`` hoặc ``maximum`` có thể để ``None`` nếu không muốn giới hạn
    một phía. Hàm bắt ``ValueError`` để chương trình không bị dừng đột ngột.
    """
    while True:
        raw_value = input(prompt).strip()

        try:
            value = int(raw_value)
        except ValueError:
            print("Bạn phải nhập một số nguyên.")
            continue

        if minimum is not None and value < minimum:
            print(f"Giá trị phải lớn hơn hoặc bằng {minimum}.")
            continue

        if maximum is not None and value > maximum:
            print(f"Giá trị phải nhỏ hơn hoặc bằng {maximum}.")
            continue

        return value


def input_choice(prompt, valid_choices):
    """Nhập một lựa chọn và chỉ chấp nhận giá trị có trong LinkedList.

    ``valid_choices`` là danh sách liên kết tự cài đặt. Toán tử ``in`` gọi
    tới thuật toán tìm kiếm tuần tự của lớp ``LinkedList``.
    """
    while True:
        value = input(prompt).strip().upper()

        if value in valid_choices:
            return value

        print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")


def confirm(prompt):
    """Hỏi xác nhận Có/Không và trả về ``True`` hoặc ``False``."""
    while True:
        value = input(prompt + " (Y/N): ").strip().upper()

        if value == "Y":
            return True
        if value == "N":
            return False

        print("Vui lòng nhập Y hoặc N.")
