"""Các hàm hiển thị menu của chương trình."""


def show_main_menu():
    """In menu chính ra màn hình."""
    print("\n" + "=" * 72)
    print("             CHƯƠNG TRÌNH HỖ TRỢ THI TRẮC NGHIỆM")
    print("=" * 72)
    print("1. Quản lý ngân hàng câu hỏi")
    print("2. Làm bài thi")
    print("3. Báo cáo kết quả nhiều lần thi")
    print("0. Kết thúc chương trình")
