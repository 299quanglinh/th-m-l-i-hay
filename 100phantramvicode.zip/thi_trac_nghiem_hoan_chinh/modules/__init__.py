"""Các mô-đun của chương trình thi trắc nghiệm."""
