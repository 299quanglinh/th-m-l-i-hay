"""Điểm bắt đầu của chương trình thi trắc nghiệm.

Chạy bằng lệnh:
    python main.py
"""

from modules.exam import start_exam
from modules.file_manager import ensure_data_files
from modules.menu import show_main_menu
from modules.question_bank import question_bank_menu
from modules.results import results_menu


def main():
    """Điều khiển menu chính cho đến khi người dùng chọn kết thúc."""
    ensure_data_files()

    while True:
        show_main_menu()
        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            question_bank_menu()
        elif choice == "2":
            start_exam()
        elif choice == "3":
            results_menu()
        elif choice == "0":
            print("Chương trình đã kết thúc.")
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        # Bắt Ctrl+C để kết thúc gọn thay vì in traceback dài.
        print("\nChương trình đã bị người dùng dừng.")
