"""Bộ kiểm thử đơn giản cho các phần không tương tác của chương trình.

Chạy từ thư mục gốc bằng:
    python tests/run_tests.py
"""

import os
import sys

# Thêm thư mục gốc dự án vào đường dẫn import khi chạy file trong tests/.
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from modules.exam import generate_exam, shuffle_question_options
from modules.file_manager import load_questions
from modules.linked_list import LinkedList
from modules.random_utils import RandomGenerator
from modules.text_utils import join_record, parse_record
from modules.models import Question


def test_linked_list():
    """Kiểm tra thêm, chèn, truy cập, hoán đổi và xóa."""
    values = LinkedList()
    values.append(1)
    values.append(2)
    values.prepend(0)
    values.insert(2, 10)

    assert len(values) == 4
    assert values[0] == 0
    assert values[2] == 10

    values.swap(1, 3)
    assert values[1] == 2
    assert values[3] == 1

    removed = values.remove_at(2)
    assert removed == 10
    assert len(values) == 3


def test_text_record():
    """Kiểm tra mã hóa/giải mã dấu phân cách và xuống dòng."""
    fields = LinkedList()
    fields.append("A|B")
    fields.append("Dòng 1\nDòng 2")
    fields.append("C:\\DATA")

    encoded = join_record(fields)
    decoded = parse_record(encoded)

    assert len(decoded) == 3
    assert decoded[0] == "A|B"
    assert decoded[1] == "Dòng 1\nDòng 2"
    assert decoded[2] == "C:\\DATA"


def test_question_data():
    """Kiểm tra file mẫu có đủ 30 câu và ID hợp lệ."""
    questions = load_questions()
    assert len(questions) == 30
    assert questions[0].question_id == 1
    assert questions[29].question_id == 30


def test_option_shuffle_preserves_correct_text():
    """Đảm bảo xáo phương án không làm mất đáp án đúng."""
    question = Question(
        1,
        "Toán",
        "DE",
        "1 + 1 bằng bao nhiêu?",
        "1",
        "2",
        "3",
        "4",
        "B",
    )
    correct_text_before = question.get_option(question.correct_answer)
    shuffle_question_options(question, RandomGenerator(12345))
    correct_text_after = question.get_option(question.correct_answer)
    assert correct_text_before == correct_text_after


def test_generate_exam_has_no_duplicate_id():
    """Kiểm tra đề sinh ra không chứa hai câu có cùng ID."""
    questions = load_questions()
    exam = generate_exam(questions, 10, RandomGenerator(2026))
    seen_ids = LinkedList()

    for question in exam:
        assert question.question_id not in seen_ids
        seen_ids.append(question.question_id)

    assert len(exam) == 10


def run_all_tests():
    """Chạy tuần tự toàn bộ ca kiểm thử và in kết quả."""
    test_linked_list()
    print("[PASS] LinkedList")

    test_text_record()
    print("[PASS] Mã hóa/giải mã file text")

    test_question_data()
    print("[PASS] Đọc ngân hàng câu hỏi")

    test_option_shuffle_preserves_correct_text()
    print("[PASS] Xáo trộn đáp án")

    test_generate_exam_has_no_duplicate_id()
    print("[PASS] Sinh đề không trùng")

    print("Tất cả kiểm thử đã hoàn thành thành công.")


if __name__ == "__main__":
    run_all_tests()
