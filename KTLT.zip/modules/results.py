
def clear_results():
    with open(
        "DATA/results.txt",
        "w",
        encoding="utf-8"
    ) as f:

        pass

def save_result(score, exam_questions, total_time):
    minutes = int(total_time // 60)
    seconds = int(total_time % 60)
    with open(
        "data/results.txt",
        "a",
        encoding="utf-8"
    ) as f:

        f.write(
            f"Điểm: {score}/{len(exam_questions)} | "
            f"Thời gian: {minutes} phút {seconds} giây\n"
        )

def show_results():

    with open(
        "data/results.txt",
        "r",
        encoding="utf-8"
    ) as f:

        results = f.readlines()

    print("\n===== KẾT QUẢ =====")

    for i, result in enumerate(results, start=1):

        print(f"Lần thi {i}: {result.strip()}")

    if not results:
        print("Bạn chưa làm bài thi nào.")