def show_menu():

    print()
    print("===== QUIZ SYSTEM =====")
    print("1. Làm bài thi")
    print("2. Xem kết quả")
    print("3. Xóa lịch sử kết quả")
    print("4. Thoát")