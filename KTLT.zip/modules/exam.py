import json
import random
import time
from modules.results import save_result


def choose_topics():

    print()
    print("===== CHỌN TOPIC =====")
    print("1. Đạo hàm")
    print("2. Nguyên hàm")
    print("3. Tích phân")

    topic_input = input(
        "Nhập topic muốn làm: "
    )

    topic_choices = topic_input.split()

    selected_topics = []

    for choice in topic_choices:

        if choice == "1":

            selected_topics.append(
                "daoham"
            )

        elif choice == "2":

            selected_topics.append(
                "nguyenham"
            )

        elif choice == "3":

            selected_topics.append(
                "tichphan"
            )

    return selected_topics


def shuffle_options(question):

    options = question["options"]

    correct_answer = question["correct_answer"]

    correct_value = options[correct_answer]

    option_items = list(options.items())

    random.shuffle(option_items)

    new_keys = ["A", "B", "C", "D"]

    new_options = {}

    for i in range(len(option_items)):

        new_options[new_keys[i]] = option_items[i][1]

        if option_items[i][1] == correct_value:

            question["correct_answer"] = new_keys[i]

    question["options"] = new_options

    return question


def load_questions(selected_topics):

    exam_questions = []

    for topic in selected_topics:

        number_of_questions = int(
            input(
                f"Bạn muốn làm bao nhiêu câu {topic}: "
            )
        )

        path = f"data/{topic}.json"

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            questions = json.load(f)

        selected_indexes = []

        while len(selected_indexes) < number_of_questions:

            random_index = random.randint(
                0,
                len(questions) - 1
            )

            if random_index not in selected_indexes:

                selected_indexes.append(
                    random_index
                )

                question = shuffle_options(
                    questions[random_index]
                    )
                exam_questions.append(question)

    return exam_questions


def run_exam(exam_questions, exam_time):

    start_time = time.time()

    score = 0

    for q in exam_questions:

        current_time = time.time()

        elapsed_time = current_time - start_time

        if elapsed_time >= exam_time:

            print()
            print("Hết giờ làm bài!")

            break

        print()
        print(q["question"])

        options = q["options"]

        for key, value in options.items():

            print(
                key + ":",
                value
            )

        user_answer = input(
            "Đáp án của bạn: "
        ).upper()

        if user_answer == q["correct_answer"]:

            print("Đúng!")

            score += 1

        else:

            print("Sai!")

    finish_time = time.time()

    total_time = finish_time - start_time

    print()

    if total_time > exam_time:

        total_time = exam_time

    if total_time >= 60:

        print(
            f"Bạn đã làm bài được "
            f"{int(total_time // 60)} phút "
            f"{int(total_time % 60)} giây"
        )

    else:

        print(
            f"Bạn đã làm bài được "
            f"{int(total_time)} giây"
        )

    print()

    print(
        "Tổng điểm:",
        score,
        "/",
        len(exam_questions)
    )

    save_result(score, exam_questions, total_time)


def choose_time():

    exam_time_cs = int(
        input(
            "Nhập thời gian làm bài (phút): "
        )
    )

    exam_time_seconds = exam_time_cs * 60

    return exam_time_seconds


def start_exam():

    selected_topics = choose_topics()

    exam_questions = load_questions(selected_topics)

    exam_time = choose_time()

    run_exam(exam_questions, exam_time)