@echo off
chcp 65001 > nul
python -m pip install inputimeout==1.0.4
pause
