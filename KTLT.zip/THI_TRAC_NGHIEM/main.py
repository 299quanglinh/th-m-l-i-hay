from modules.exam import start_exam
from modules.file_manager import ensure_data_files
from modules.results import student_results_menu
from modules.teacher import teacher_menu


TEACHER_CODE = "giaovien"


def student_menu():


    while True:
        print("\n========== MENU THÍ SINH ==========")
        print("1. Bắt đầu thi")
        print("2. Xem kết quả thi")
        print("0. Đăng xuất")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":


            start_exam()
        elif choice == "2":
            student_results_menu()
        elif choice == "0":
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")


def login_teacher():


    teacher_code = input("Nhập mã giáo viên: ").strip()

    if teacher_code == TEACHER_CODE:
        return True

    print("Mã giáo viên không đúng. Vui lòng chọn lại vai trò.")
    return False


def main():


    ensure_data_files()

    while True:
        print("\n========== ĐĂNG NHẬP ==========")
        print("1. Giáo viên")
        print("2. Thí sinh")
        print("0. Thoát")

        role_choice = input("Chọn vai trò: ").strip()

        if role_choice == "1":
            if login_teacher():
                teacher_menu()
        elif role_choice == "2":
            student_menu()
        elif role_choice == "0":
            print("Chương trình đã kết thúc.")
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nChương trình đã bị người dùng dừng.")
    except EOFError:
        print("\nKhông còn dữ liệu nhập. Chương trình đã kết thúc.")
