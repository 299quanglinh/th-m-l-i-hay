import os

from modules.linked_list import LinkedList
from modules.models import ExamResult, Question
from modules.text_utils import join_record, parse_record


PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_DIR, "DATA")
QUESTIONS_FILE = os.path.join(DATA_DIR, "questions.txt")
RESULTS_FILE = os.path.join(DATA_DIR, "results.txt")


def is_blank_text(value):
    return value.strip() == ""


def is_valid_difficulty(difficulty):
    return difficulty == "DE" or difficulty == "KHO"


def question_id_exists(questions, question_id):
    for question in questions:
        if question.question_id == question_id:
            return True

    return False


def ensure_data_files():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

    if not os.path.exists(QUESTIONS_FILE):
        with open(QUESTIONS_FILE, "w", encoding="utf-8"):
            pass

    if not os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "w", encoding="utf-8"):
            pass


def line_to_question(line):
    fields = parse_record(line)

    if len(fields) != 10:
        return None

    try:
        question_id = int(fields[0].strip())
    except ValueError:
        return None

    if question_id <= 0:
        return None

    subject = fields[1].strip()
    topic = fields[2].strip()
    difficulty = fields[3].strip().upper()
    content = fields[4].strip()
    option_a = fields[5].strip()
    option_b = fields[6].strip()
    option_c = fields[7].strip()
    option_d = fields[8].strip()
    correct_answer = fields[9].strip().upper()

    if is_blank_text(subject) or is_blank_text(topic) \
            or is_blank_text(difficulty) or is_blank_text(content) \
            or is_blank_text(option_a) or is_blank_text(option_b) \
            or is_blank_text(option_c) or is_blank_text(option_d):
        return None

    if not is_valid_difficulty(difficulty):
        return None

    if correct_answer != "A" and correct_answer != "B" \
            and correct_answer != "C" and correct_answer != "D":
        return None

    return Question(
        question_id,
        subject,
        topic,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    )


def load_questions():
    ensure_data_files()

    questions = LinkedList()
    invalid_count = 0
    duplicate_count = 0

    with open(QUESTIONS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            question = line_to_question(line)

            if question is None:
                invalid_count += 1
            elif question_id_exists(questions, question.question_id):
                duplicate_count += 1
            else:
                questions.append(question)

    if invalid_count > 0:
        print(f"Đã bỏ qua {invalid_count} dòng câu hỏi sai định dạng.")

    if duplicate_count > 0:
        print(f"Đã bỏ qua {duplicate_count} câu hỏi bị trùng mã.")

    return questions


def open_questions_file():
    ensure_data_files()

    try:
        os.startfile(QUESTIONS_FILE)
        print(f"Đã mở file câu hỏi: {QUESTIONS_FILE}")
    except (AttributeError, OSError):
        print("Không thể mở file tự động trên hệ điều hành này.")
        print(f"Hãy mở thủ công file: {QUESTIONS_FILE}")


def result_to_line(result):
    fields = LinkedList()
    fields.append(result.exam_id)
    fields.append(result.candidate_id)
    fields.append(result.candidate_name)
    fields.append(result.exam_time_text)
    fields.append(result.subjects)
    fields.append(result.total_questions)
    fields.append(result.correct_count)
    fields.append(result.wrong_count)
    fields.append(f"{result.score_ten:.2f}")
    fields.append(result.limit_seconds)
    fields.append(result.used_seconds)
    return join_record(fields)


def line_to_result(line):
    fields = parse_record(line)

    if len(fields) != 11:
        return None

    try:
        exam_id = int(fields[0])
        total_questions = int(fields[5])
        correct_count = int(fields[6])
        wrong_count = int(fields[7])
        score_ten = float(fields[8])
        limit_seconds = int(fields[9])
        used_seconds = int(fields[10])
    except ValueError:
        return None

    if exam_id <= 0 or total_questions <= 0:
        return None

    if correct_count < 0 or wrong_count < 0:
        return None

    if correct_count + wrong_count != total_questions:
        return None

    if score_ten < 0 or score_ten > 10:
        return None

    if limit_seconds <= 0 or used_seconds < 0 or used_seconds > limit_seconds:
        return None

    return ExamResult(
        exam_id,
        fields[1].strip(),
        fields[2].strip(),
        fields[3].strip(),
        fields[4].strip(),
        total_questions,
        correct_count,
        wrong_count,
        score_ten,
        limit_seconds,
        used_seconds,
    )


def append_result(result):
    ensure_data_files()

    needs_newline = False

    if os.path.getsize(RESULTS_FILE) > 0:
        with open(RESULTS_FILE, "rb") as file:
            file.seek(-1, os.SEEK_END)
            needs_newline = file.read(1) != b"\n"

    with open(RESULTS_FILE, "a", encoding="utf-8") as file:
        if needs_newline:
            file.write("\n")

        file.write(result_to_line(result) + "\n")


def load_results():
    ensure_data_files()

    results = LinkedList()
    invalid_count = 0

    with open(RESULTS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            if line.strip() == "":
                continue

            result = line_to_result(line)

            if result is None:
                invalid_count += 1
            else:
                results.append(result)

    if invalid_count > 0:
        print(f"Đã bỏ qua {invalid_count} dòng kết quả sai định dạng.")

    return results


def next_exam_id(results):
    maximum_id = 0

    for result in results:
        if result.exam_id > maximum_id:
            maximum_id = result.exam_id

    return maximum_id + 1
