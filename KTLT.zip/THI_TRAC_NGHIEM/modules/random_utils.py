import random


def shuffle(linked_list):


    index = len(linked_list) - 1

    while index > 0:


        random_index = random.randint(0, index)


        linked_list.swap(index, random_index)


        index -= 1
