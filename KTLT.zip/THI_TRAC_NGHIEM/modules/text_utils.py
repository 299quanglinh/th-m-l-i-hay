from modules.linked_list import LinkedList


def join_record(fields):


    result = ""


    index = 0

    for field in fields:
        if index > 0:
            result += "|"


        result += str(field).replace("|", " ").replace("\n", " ").replace("\r", " ")
        index += 1

    return result


def parse_record(line):


    fields = LinkedList()


    current_field = ""

    for character in line.rstrip("\n"):
        if character == "|":
            fields.append(current_field)
            current_field = ""
        else:
            current_field += character


    fields.append(current_field)
    return fields


def contains_text(source, keyword):


    source_lower = source.lower()
    keyword_lower = keyword.lower()

    if keyword_lower == "":
        return True

    if len(keyword_lower) > len(source_lower):
        return False


    start = 0


    last_start = len(source_lower) - len(keyword_lower)

    while start <= last_start:

        matched = True


        offset = 0

        while offset < len(keyword_lower):
            if source_lower[start + offset] != keyword_lower[offset]:
                matched = False
                break
            offset += 1

        if matched:
            return True

        start += 1

    return False


def format_seconds(total_seconds):


    safe_seconds = int(total_seconds)

    if safe_seconds < 0:
        safe_seconds = 0

    minutes = safe_seconds // 60
    seconds = safe_seconds % 60
    return f"{minutes} phút {seconds} giây"
