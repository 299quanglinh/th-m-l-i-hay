from modules.file_manager import load_questions, open_questions_file
from modules.results import results_menu


def show_question_bank():


    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi hiện đang trống hoặc dữ liệu chưa đúng định dạng.")
        return

    print("\n========== NGÂN HÀNG CÂU HỎI ==========")

    index = 1

    for question in questions:
        print("-" * 72)
        print(f"STT          : {index}")
        print(f"Mã câu hỏi   : {question.question_id}")
        print(f"Môn          : {question.subject}")
        print(f"Chủ đề       : {question.topic}")
        print(f"Độ khó       : {question.difficulty}")
        print(f"Nội dung     : {question.content}")
        print(f"A            : {question.option_a}")
        print(f"B            : {question.option_b}")
        print(f"C            : {question.option_c}")
        print(f"D            : {question.option_d}")
        print(f"Đáp án đúng  : {question.correct_answer}")
        index += 1

    print("-" * 72)
    print(f"Tổng số câu hỏi: {len(questions)}")


def teacher_menu():


    while True:
        print("\n========== MENU GIÁO VIÊN ==========")
        print("1. Xem ngân hàng câu hỏi")
        print("2. Mở file questions.txt để thêm/sửa/xóa")
        print("3. Xem kết quả thi")
        print("0. Đăng xuất")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_question_bank()
        elif choice == "2":
            open_questions_file()
        elif choice == "3":
            results_menu()
        elif choice == "0":
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")
