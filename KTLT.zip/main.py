from modules.menu import show_menu
from modules.exam import start_exam
from modules.results import show_results, clear_results

while True:

    show_menu()

    choice = input(
        "Chọn chức năng: "
    )

    if choice == "1":

        start_exam()

    elif choice == "2":

        show_results()

    elif choice == "3":

        clear_results() 
        print("Lịch sử kết quả đã được xóa.")

    elif choice == "4":
        
        print("Thoát chương trình.")
        break