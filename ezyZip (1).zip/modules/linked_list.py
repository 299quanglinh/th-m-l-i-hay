

class Node:
    """
    Một nút (node) trong Linked List đơn.

    Thuộc tính:
        data : dữ liệu lưu trong nút
        next  : con trỏ trỏ tới nút kế tiếp (None nếu là nút cuối)
    """

    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    """
    Linked List đơn tự cài đặt, thay thế hoàn toàn Python list.

    Cấu trúc bộ nhớ:
        head -> [Node1] -> [Node2] -> ... -> [NodeN] -> None
        tail ────────────────────────────────────────^  (trỏ thẳng tới cuối)

    Tại sao dùng tail pointer?
        - append() là O(1) thay vì O(n), vì không cần duyệt tới cuối mỗi lần thêm.
        - Quan trọng khi load nhiều câu hỏi liên tiếp.

    Các thao tác được hỗ trợ:
        append(data)          – thêm cuối, O(1)
        __len__()             – đếm số phần tử, O(1)
        __contains__(item)    – kiểm tra tồn tại, O(n)
        __iter__()            – duyệt tuần tự (hỗ trợ for-loop, enumerate)
        __getitem__(index)    – truy cập theo chỉ số, O(n)
        __setitem__(index, v) – gán theo chỉ số, O(n)
        swap(i, j)            – hoán đổi hai phần tử, O(n)
    """

    def __init__(self):
        self.head  = None   # nút đầu tiên
        self.tail  = None   # nút cuối cùng (tăng tốc append)
        self._size = 0      # số nút hiện có

    # ------------------------------------------------------------------
    # Thêm phần tử
    # ------------------------------------------------------------------
    def append(self, data):
        """
        Thêm một phần tử vào cuối linked list – O(1).

        Cách hoạt động:
            Trường hợp rỗng  → head = tail = new_node
            Trường hợp đã có → tail.next = new_node, rồi tail = new_node
        """
        new_node = Node(data)

        if self.head is None:           # linked list đang rỗng
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node   # nối node cũ cuối → node mới
            self.tail       = new_node  # cập nhật tail

        self._size += 1

    # ------------------------------------------------------------------
    # Độ dài
    # ------------------------------------------------------------------
    def __len__(self):
        """Trả về số phần tử – O(1) nhờ lưu _size."""
        return self._size

    # ------------------------------------------------------------------
    # Kiểm tra tồn tại (dùng cho: random_index not in selected_indexes)
    # ------------------------------------------------------------------
    def __contains__(self, item):
        """
        Duyệt từng nút, so sánh data với item – O(n).
        Trả True ngay khi tìm thấy, False nếu duyệt hết mà không gặp.
        """
        current = self.head
        while current is not None:
            if current.data == item:
                return True
            current = current.next
        return False

    # ------------------------------------------------------------------
    # Duyệt (hỗ trợ: for q in exam_questions, enumerate(...))
    # ------------------------------------------------------------------
    def __iter__(self):
        """
        Generator duyệt tuần tự từ head đến tail.
        Cho phép dùng: for x in linked_list  và  enumerate(linked_list).
        """
        current = self.head
        while current is not None:
            yield current.data
            current = current.next

    # ------------------------------------------------------------------
    # Truy cập nút theo chỉ số (nội bộ)
    # ------------------------------------------------------------------
    def _get_node(self, index):
        """
        Duyệt từ head qua index bước, trả về nút tại vị trí đó – O(n).
        Ném IndexError nếu index ngoài phạm vi.
        """
        if index < 0 or index >= self._size:
            raise IndexError(
                f"LinkedList: chỉ số {index} ngoài phạm vi "
                f"(kích thước = {self._size})"
            )
        current = self.head
        for _ in range(index):
            current = current.next
        return current

    # ------------------------------------------------------------------
    # Lấy / gán theo chỉ số (hỗ trợ: linked_list[i] và linked_list[i] = v)
    # ------------------------------------------------------------------
    def __getitem__(self, index):
        """Trả về data tại vị trí index – O(n)."""
        return self._get_node(index).data

    def __setitem__(self, index, value):
        """Gán value vào vị trí index – O(n)."""
        self._get_node(index).data = value

    # ------------------------------------------------------------------
    # Hoán đổi (dùng cho thuật toán Fisher-Yates shuffle)
    # ------------------------------------------------------------------
    def swap(self, i, j):
        """
        Hoán đổi dữ liệu tại hai vị trí i và j – O(n).

        Kỹ thuật: chỉ swap trường .data, không thay đổi cấu trúc con trỏ.
        Tương đương: arr[i], arr[j] = arr[j], arr[i] với Python list.
        """
        if i == j:
            return
        node_i = self._get_node(i)
        node_j = self._get_node(j)
        node_i.data, node_j.data = node_j.data, node_i.data


# =============================================================================
#  Hàm tiện ích
# =============================================================================

def make_linked_list(*args):
    """
    Tạo LinkedList từ các giá trị truyền vào.

    Ví dụ:
        make_linked_list("A", "B", "C", "D")
        → LinkedList chứa ["A", "B", "C", "D"]
    """
    ll = LinkedList()
    for item in args:
        ll.append(item)
    return ll


def split_string(s):
    """
    Tách chuỗi s theo khoảng trắng, trả về LinkedList các token.
    Tự cài đặt, thay thế hoàn toàn str.split().

    Cách hoạt động:
        - Duyệt từng ký tự trong s.
        - Gặp khoảng trắng/tab/newline → kết thúc từ hiện tại (nếu có), append vào kết quả.
        - Ký tự bình thường → nối vào từ đang xây dựng.
        - Sau vòng lặp: append từ cuối nếu còn sót.

    Ví dụ:
        split_string("1 3")    → LinkedList: ["1", "3"]
        split_string("  2  3") → LinkedList: ["2", "3"]  (bỏ khoảng trắng dư)
    """
    result       = LinkedList()
    current_word = ""

    for char in s:
        if char in ' \t\n\r':
            if current_word:                    # kết thúc một từ
                result.append(current_word)
                current_word = ""
        else:
            current_word += char               # tích lũy ký tự

    if current_word:                           # từ cuối cùng (không có dấu trắng sau)
        result.append(current_word)

    return result
