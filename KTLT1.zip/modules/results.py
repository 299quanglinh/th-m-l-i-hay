def clear_results():

    '''
    Hàm dùng để:
    - xóa toàn bộ lịch sử kết quả
    '''

    with open(
        "DATA/results.txt",
        "w",
        encoding="utf-8"
    ) as f:

        f.write("")

    print()
    print("Đã xóa toàn bộ lịch sử!")


def show_results():

    '''
    Hàm dùng để:
    - đọc lịch sử làm bài
    - hiển thị kết quả
    '''

    try:

        with open(
            "DATA/results.txt",
            "r",
            encoding="utf-8"
        ) as f:

            results = f.readlines()

    except FileNotFoundError:

        print()
        print("Chưa có file kết quả!")

        return

    print()
    print("===== KẾT QUẢ =====")

    '''
    Nếu file rỗng
    '''

    if len(results) == 0:

        print("Bạn chưa làm bài thi nào.")

        return

    '''
    In từng kết quả
    '''

    for i in range(len(results)):

        print(
            f"Lần thi {i + 1}: "
            f"{results[i].strip()}"
        )


def save_result(
    score,
    exam_questions,
    total_time
):

    '''
    Hàm dùng để:
    - lưu kết quả bài thi
    - lưu thời gian làm bài
    '''

    minutes = int(
        total_time // 60
    )

    seconds = int(
        total_time % 60
    )

    with open(
        "DATA/results.txt",
        "a",
        encoding="utf-8"
    ) as f:

        f.write(
            f"Điểm: "
            f"{score}/{len(exam_questions)} | "
            f"Thời gian: "
            f"{minutes} phút "
            f"{seconds} giây\n"
        )