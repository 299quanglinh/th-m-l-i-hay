import json
import random
import time

from modules.results import save_result


def choose_topics():

    '''
    Hàm dùng để:
    - hiển thị danh sách topic
    - nhận input từ user
    - chuyển lựa chọn thành tên file topic

    Ví dụ:
    User nhập:
    1 3

    Hàm sẽ trả về:
    ["daoham", "tichphan"]
    '''

    print()
    print("===== CHỌN TOPIC =====")
    print("1. Đạo hàm")
    print("2. Nguyên hàm")
    print("3. Tích phân")

    topic_map = {
        "1": "daoham",
        "2": "nguyenham",
        "3": "tichphan"
    }

    topic_input = input(
        "Nhập topic muốn làm: "
    )

    topic_choices = topic_input.split()

    selected_topics = []

    for choice in topic_choices:

        if choice in topic_map:

            selected_topics.append(
                topic_map[choice]
            )

    return selected_topics

def shuffle_options(question):

    '''
    Hàm dùng để:
    - đảo vị trí đáp án A B C D
    - cập nhật lại correct_answer

    Ví dụ:
    Đáp án đúng ban đầu là:
    A

    Sau khi đảo:
    đáp án đúng có thể thành:
    C
    '''

    options = question["options"]

    correct_answer = question["correct_answer"]

    correct_value = options[correct_answer]

    option_items = list(
        options.items()
    )

    '''
    Tự viết thuật toán shuffle:
    - random vị trí
    - swap phần tử
    '''

    for i in range(len(option_items)):

        random_index = random.randint(
            0,
            len(option_items) - 1
        )

        option_items[i], option_items[random_index] = (
            option_items[random_index],
            option_items[i]
        )

    new_keys = ["A", "B", "C", "D"]

    new_options = {}

    '''
    Tạo lại dictionary options mới
    '''

    for i in range(len(option_items)):

        new_options[new_keys[i]] = option_items[i][1]

        '''
        Nếu value hiện tại là đáp án đúng
        thì cập nhật correct_answer mới
        '''

        if option_items[i][1] == correct_value:

            question["correct_answer"] = (
                new_keys[i]
            )

    question["options"] = new_options

    return question

def shuffle_questions(exam_questions):

    '''
    Hàm dùng để:
    - đảo toàn bộ thứ tự câu hỏi

    Ví dụ:
    [nh1, nh2, tp1]

    có thể thành:

    [tp1, nh1, nh2]
    '''

    for i in range(len(exam_questions)):

        random_index = random.randint(
            0,
            len(exam_questions) - 1
        )

        exam_questions[i], exam_questions[random_index] = (
            exam_questions[random_index],
            exam_questions[i]
        )

    return exam_questions

def load_questions(selected_topics):

    '''
    Hàm dùng để:
    - đọc file json
    - random câu hỏi
    - shuffle đáp án
    - thêm vào exam_questions
    - shuffle toàn bộ đề
    '''

    exam_questions = []

    for topic in selected_topics:

        number_of_questions = int(
            input(
                f"Bạn muốn làm bao nhiêu câu {topic}: "
            )
        )

        path = f"DATA/{topic}.json"

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            questions = json.load(f)

        '''
        List dùng để chống random trùng
        '''

        selected_indexes = []

        while len(selected_indexes) < number_of_questions:

            random_index = random.randint(
                0,
                len(questions) - 1
            )

            if random_index not in selected_indexes:

                selected_indexes.append(
                    random_index
                )

                question = shuffle_options(
                    questions[random_index]
                )

                question["user_answer"] = None
                question["is_answered"] = False
                question["is_skipped"] = False 

                exam_questions.append(
                    question
                )

        '''
        Shuffle toàn bộ đề
        '''

    shuffle_questions(exam_questions)

    return exam_questions

def choose_time():

    '''
    Hàm dùng để:
    - nhận thời gian từ user
    - đổi phút sang giây

    Ví dụ:
    5 phút
    ->
    300 giây
    '''

    exam_time = int(
        input(
            "Nhập thời gian làm bài (phút): "
        )
    )

    exam_time_seconds = exam_time * 60

    return exam_time_seconds

def calculate_score(exam_questions):

    '''
    Hàm dùng để:
    - chấm điểm cuối bài
    '''

    score = 0

    for q in exam_questions:

        if q["user_answer"] == q["correct_answer"]:

            score += 1

    return score

def show_question_list(exam_questions, current_index):

    print()
    print("===== DANH SÁCH CÂU HỎI =====")

    status_line = ""

    for i, q in enumerate(exam_questions):

        num = i + 1

        if q["is_answered"]:
            symbol = "✓"
        elif q["is_skipped"]:
            symbol = "✗"
        else:
            symbol = "•"

        if i == current_index:
            status_line += f"[{num}{symbol}] "
        else:
            status_line += f" {num}{symbol}  "

    print(status_line.strip())

def run_exam(exam_questions, exam_time):

    start_time = time.time()
    current_index = 0

    while True:

        elapsed_time = time.time() - start_time

        if elapsed_time >= exam_time:
            print()
            print("Hết giờ làm bài!")
            break

        # ── Hiện danh sách trạng thái ─────────────────────────────────
        show_question_list(exam_questions, current_index)

        q = exam_questions[current_index]

        # ── Hiện câu hỏi ──────────────────────────────────────────────
        print()
        print(f"─── Câu {current_index + 1} / {len(exam_questions)} ───")
        print(q["question"])

        for key, value in q["options"].items():
            print(key + ":", value)

        if q["is_answered"]:
            print(f"(Đã chọn: {q['user_answer']})")

        remaining = int(exam_time - elapsed_time)
        print(f"[Còn {remaining // 60}p {remaining % 60}s]")

        user_input = input(
            "Đáp án (A/B/C/D) | N=tiếp | P=trước | Gn = Làm câu thứ n | S=bỏ qua | Q=nộp bài: "
        ).strip().upper()

        # ── Xử lý input ───────────────────────────────────────────────

        if user_input == "Q":
            print()
            print("Nộp bài!")
            break

        elif user_input == "N":
            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("→ Đây là câu cuối cùng.")

        elif user_input == "P":
            if current_index > 0:
                current_index -= 1
            else:
                print("→ Đây là câu đầu tiên.")

        elif user_input == "S":
            q["is_answered"] = False
            q["user_answer"] = None
            q["is_skipped"] = True
            print("→ Đã bỏ qua.")
            if current_index < len(exam_questions) - 1:
                current_index += 1

        elif user_input.startswith("G"):
            try:
                target = int(user_input[1:]) - 1   # lấy số sau chữ G
                if 0 <= target < len(exam_questions):
                    current_index = target
                else:
                    print(f"→ Chỉ có {len(exam_questions)} câu thôi!")
            except ValueError:
                print("→ Cú pháp: G<số>, ví dụ G4 để nhảy câu 4.")

        elif user_input in ["A", "B", "C", "D"]:
            q["user_answer"] = user_input
            q["is_answered"] = True
            q["is_skipped"] = False     # bỏ qua rồi quay lại làm vẫn được

            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("→ Câu cuối. Nhập Q để nộp bài.")

        else:
            print("→ Không hợp lệ.")

    # ── Tính thời gian & điểm ─────────────────────────────────────────
    finish_time = time.time()
    total_time = min(finish_time - start_time, exam_time)

    minutes = int(total_time // 60)
    seconds = int(total_time % 60)

    print()

    if total_time >= 60:
        print(f"Bạn đã làm bài được {minutes} phút {seconds} giây")
    else:
        print(f"Bạn đã làm bài được {seconds} giây")

    print()

    score = calculate_score(exam_questions)
    print("Tổng điểm:", score, "/", len(exam_questions))

    save_result(score, exam_questions, total_time)

def start_exam():

    '''
    Hàm điều khiển toàn bộ flow chương trình.

    Flow:
    chọn topic
        ↓
    load câu hỏi
        ↓
    chọn thời gian
        ↓
    chạy bài thi
    '''

    selected_topics = choose_topics()

    exam_questions = load_questions(
        selected_topics
    )

    exam_time = choose_time()

    run_exam(
        exam_questions,
        exam_time
    )