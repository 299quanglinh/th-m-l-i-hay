# CHƯƠNG TRÌNH THI TRẮC NGHIỆM

## 1. Giới thiệu

Đây là chương trình thi trắc nghiệm được xây dựng bằng Python, có thể chạy bằng giao diện Tkinter hoặc cửa sổ dòng lệnh. Chương trình hỗ trợ quản lý ngân hàng câu hỏi, cấu hình đề thi, làm bài có giới hạn thời gian, tự động chấm điểm và lưu kết quả của nhiều lần thi.

Dữ liệu câu hỏi và kết quả thi được lưu trong các file văn bản tại thư mục `DATA`.

## 2. Chức năng chính

### 2.1. Quản lý ngân hàng câu hỏi

Người quản trị có thể:

- Xem toàn bộ câu hỏi.
- Thêm câu hỏi mới.
- Xóa câu hỏi theo ID.

Mỗi câu hỏi gồm:

- ID câu hỏi.
- Môn hoặc chủ đề.
- Độ khó: Dễ hoặc Khó.
- Nội dung câu hỏi.
- Bốn phương án A, B, C, D.
- Đáp án đúng.

Chương trình không cung cấp chức năng sửa câu hỏi trong menu. Khi cần chỉnh sửa nội dung câu hỏi đã có, người quản trị có thể sửa trực tiếp trong file `DATA/questions.txt` và phải giữ nguyên cấu trúc dữ liệu của từng dòng.

### 2.2. Thi trắc nghiệm

Người thi có thể:

- Nhập mã thí sinh và họ tên.
- Chọn một hoặc nhiều môn/chủ đề.
- Chọn độ khó: Dễ, Khó hoặc cả hai.
- Chọn số lượng câu hỏi.
- Nhập thời gian làm bài.
- Làm bài bằng các lệnh trên bàn phím.
- Nộp bài chủ động hoặc để hệ thống tự động thu bài khi hết giờ.

Các lệnh trong khi làm bài:

- `A`, `B`, `C`, `D`: chọn đáp án.
- `N`: chuyển sang câu tiếp theo.
- `P`: quay lại câu trước.
- `S`: bỏ qua câu hiện tại.
- `Q`: nộp bài.

Khi sinh đề, chương trình xáo trộn thứ tự câu hỏi và thứ tự các phương án. Đáp án đúng được cập nhật tương ứng sau khi xáo trộn.

### 2.3. Báo cáo kết quả

Chương trình hỗ trợ:

- Xem toàn bộ kết quả đã lưu.
- Tìm kết quả theo mã hoặc tên thí sinh.
- Xóa toàn bộ lịch sử kết quả.

Mỗi kết quả thi lưu các thông tin chính:

- Mã lần thi.
- Mã và họ tên thí sinh.
- Thời điểm thi.
- Môn/chủ đề đã chọn.
- Số câu đúng, sai và bỏ qua.
- Điểm theo thang 10.
- Thời gian quy định và thời gian đã sử dụng.
- Trạng thái nộp bài.

## 3. Kỹ thuật được sử dụng

Chương trình có sử dụng và tự cài đặt một số cấu trúc, thuật toán cơ bản:

- Danh sách liên kết đơn `LinkedList`.
- Tìm kiếm tuần tự.
- Thuật toán xáo trộn Fisher-Yates.
- Thư viện `random` để lấy số ngẫu nhiên khi xáo trộn.
- Kiểm tra dữ liệu đầu vào ở các màn hình chính.
- Chia chương trình thành các mô-đun và hàm riêng biệt.
- Đọc và ghi dữ liệu bằng file text.

Thư viện `inputimeout` được sử dụng để giới hạn thời gian nhập đáp án và tự động thu bài khi hết giờ.

## 4. Cấu trúc thư mục

thi_trac_nghiem_hoan_chinh/
│
├── DATA/
│   ├── questions.txt          # Ngân hàng câu hỏi
│   └── results.txt            # Lịch sử kết quả thi
│
├── modules/
│   ├── __init__.py            # Đánh dấu thư mục modules là package
│   ├── exam.py                # Cấu hình đề và tổ chức thi
│   ├── file_manager.py        # Đọc, ghi và tạo file dữ liệu
│   ├── linked_list.py         # Danh sách liên kết tự cài đặt
│   ├── models.py              # Các lớp dữ liệu
│   ├── question_bank.py       # Xem, thêm và xóa câu hỏi
│   ├── random_utils.py        # Xáo trộn Fisher-Yates trên LinkedList
│   ├── results.py             # Xem, tìm và xóa kết quả
│   └── text_utils.py          # Các hàm xử lý chuỗi
│
├── main.py                    # Điểm bắt đầu của chương trình console
├── app_gui.py                 # Giao diện Tkinter
├── cai_thu_vien.bat           # Cài thư viện trên Windows
├── chay_chuong_trinh.bat      # Chạy chương trình trên Windows

 README.md                   # Tài liệu hướng dẫn

Các thư mục `__pycache__` và file `.pyc` do Python tự tạo ra khi chạy chương trình. Có thể xóa các thư mục này mà không ảnh hưởng đến mã nguồn.

## 5. Yêu cầu môi trường

- Python 3.x.
- Thư viện `inputimeout` phiên bản 1.0.4 nếu chạy bản console có tính giờ nhập đáp án.

## 6. Cài đặt

### Cách 1: Cài bằng file BAT trên Windows

chạy file:

cai_thu_vien.bat

### Cách 2: Cài trong Terminal

Mở Terminal tại thư mục dự án và chạy:

```bash
python -m pip install inputimeout==1.0.4
```

## 7. Chạy chương trình

### Cách 1: Chạy bằng file BAT

Nhấp đúp vào:

```text
chay_chuong_trinh.bat
```

### Cách 2: Chạy giao diện trong Terminal

```bash
python app_gui.py
```

### Cách 3: Chạy bản console trong Terminal

```bash
python main.py
```

Menu chính của chương trình:


========== CHƯƠNG TRÌNH THI TRẮC NGHIỆM ==========
1. Quản lý ngân hàng câu hỏi
2. Làm bài thi
3. Báo cáo kết quả
0. Kết thúc chương trình


## 8. Dữ liệu câu hỏi

Ngân hàng câu hỏi được lưu trong:

```text
DATA/questions.txt
```

Mỗi câu hỏi được lưu trên một dòng. Các trường dữ liệu được phân cách bằng ký tự `|`.

Cấu trúc tổng quát:

```text
ID|Môn/chủ đề|Độ khó|Nội dung|Phương án A|Phương án B|Phương án C|Phương án D|Đáp án đúng
```

Ví dụ:

```text
1|Đạo hàm|DE|Đạo hàm của x^2 là gì?|x|2x|x^2|2|B
```

Quy ước độ khó:

- `DE`: Dễ.
- `KHO`: Khó.

Khi sửa trực tiếp file, không nên dùng ký tự `|` trong nội dung câu hỏi hoặc phương án vì đây là ký tự phân cách dữ liệu.

## 9. Dữ liệu kết quả

Kết quả các lần thi được lưu trong:

```text
DATA/results.txt
```

Chương trình tự động ghi thêm kết quả sau mỗi lần thi. Không nên sửa thủ công file này trong lúc chương trình đang chạy.

## 10. Một số lưu ý

- Cần cài `inputimeout` trước khi thi bằng bản console. Giao diện Tkinter không phụ thuộc trực tiếp vào thư viện này.
- Không xóa `DATA/questions.txt` nếu muốn giữ ngân hàng câu hỏi hiện tại.
- Có thể xóa `DATA/results.txt` để làm sạch lịch sử; chương trình sẽ tạo lại file khi cần.
- Có thể xóa các thư mục `__pycache__` trước khi nộp bài.
- Khi chuyển dự án sang máy khác, cần giữ nguyên cấu trúc thư mục để các lệnh import và đường dẫn dữ liệu hoạt động đúng.
