from modules.exam import start_exam
from modules.file_manager import ensure_data_files
from modules.question_bank import question_bank_menu
from modules.results import results_menu

def main():
    ensure_data_files()

    while True:
        print("\n" + "=" * 72)
        print("             CHƯƠNG TRÌNH HỖ TRỢ THI TRẮC NGHIỆM")
        print("=" * 72)
        print("1. Quản lý ngân hàng câu hỏi")
        print("2. Làm bài thi")
        print("3. Báo cáo kết quả nhiều lần thi")
        print("0. Kết thúc chương trình")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            question_bank_menu()
        elif choice == "2":
            start_exam()
        elif choice == "3":
            results_menu()
        elif choice == "0":
            print("Chương trình đã kết thúc.")
            return
        else:
            print("Lựa chọn không hợp lệ. Vui lòng nhập lại.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nChương trình đã bị người dùng dừng.")
