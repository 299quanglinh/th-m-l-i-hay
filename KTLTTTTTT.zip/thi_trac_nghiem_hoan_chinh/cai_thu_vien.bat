@echo off
python -m pip install inputimeout==1.0.4
pause
