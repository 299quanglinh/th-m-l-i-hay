class Question:

    def __init__(
        self,
        question_id,
        subject,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    ):
        self.question_id = question_id
        self.subject = subject
        self.difficulty = difficulty
        self.content = content
        self.option_a = option_a
        self.option_b = option_b
        self.option_c = option_c
        self.option_d = option_d
        self.correct_answer = correct_answer

        self.user_answer = ""
        self.is_answered = False
        self.is_skipped = False

    def clone(self):
        return Question(
            self.question_id,
            self.subject,
            self.difficulty,
            self.content,
            self.option_a,
            self.option_b,
            self.option_c,
            self.option_d,
            self.correct_answer,
        )

class AnswerOption:

    def __init__(self, text, is_correct):
        self.text = text
        self.is_correct = is_correct

class ExamResult:

    def __init__(
        self,
        exam_id,
        candidate_id,
        candidate_name,
        exam_time_text,
        subjects,
        total_questions,
        correct_count,
        wrong_count,
        skipped_count,
        score_ten,
        limit_seconds,
        used_seconds,
        submit_status,
    ):
        self.exam_id = exam_id
        self.candidate_id = candidate_id
        self.candidate_name = candidate_name
        self.exam_time_text = exam_time_text
        self.subjects = subjects
        self.total_questions = total_questions
        self.correct_count = correct_count
        self.wrong_count = wrong_count
        self.skipped_count = skipped_count
        self.score_ten = score_ten
        self.limit_seconds = limit_seconds
        self.used_seconds = used_seconds
        self.submit_status = submit_status
