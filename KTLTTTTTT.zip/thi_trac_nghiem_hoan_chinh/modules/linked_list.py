class Node:

    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:

    def __init__(self):
        self.head = None
        self.tail = None
        self._size = 0

    def append(self, data):
        new_node = Node(data)

        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

        self._size += 1

    def get(self, index):
        return self._get_node(index).data

    def remove_at(self, index):
        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số xóa nằm ngoài phạm vi danh sách.")

        if index == 0:
            removed_node = self.head
            self.head = self.head.next
            self._size -= 1

            if self._size == 0:
                self.tail = None

            return removed_node.data

        previous = self._get_node(index - 1)
        removed_node = previous.next
        previous.next = removed_node.next

        if removed_node is self.tail:
            self.tail = previous

        self._size -= 1
        return removed_node.data

    def contains(self, item):
        current = self.head

        while current is not None:
            if current.data == item:
                return True
            current = current.next

        return False

    def swap(self, first_index, second_index):
        if first_index == second_index:
            return

        first_node = self._get_node(first_index)
        second_node = self._get_node(second_index)
        temporary = first_node.data
        first_node.data = second_node.data
        second_node.data = temporary

    def copy_shallow(self):
        copied = LinkedList()
        current = self.head

        while current is not None:
            copied.append(current.data)
            current = current.next

        return copied

    def _get_node(self, index):
        if index < 0 or index >= self._size:
            raise IndexError("Chỉ số truy cập nằm ngoài phạm vi danh sách.")

        current = self.head
        current_index = 0

        while current_index < index:
            current = current.next
            current_index += 1

        return current

    def __len__(self):
        return self._size

    def __iter__(self):
        current = self.head

        while current is not None:
            yield current.data
            current = current.next

    def __getitem__(self, index):
        return self.get(index)

    def __contains__(self, item):
        return self.contains(item)
