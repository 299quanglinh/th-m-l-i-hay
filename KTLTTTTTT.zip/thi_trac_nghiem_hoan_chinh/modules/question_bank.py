from modules.file_manager import (
    load_questions,
    next_question_id,
    save_questions,
)
from modules.models import Question

def display_question(question, index=None):
    prefix = ""

    if index is not None:
        prefix = f"[{index}] "

    difficulty = "Dễ" if question.difficulty == "DE" else "Khó"

    print("-" * 72)
    print(
        f"{prefix}ID: {question.question_id} | "
        f"Môn/chủ đề: {question.subject} | "
        f"Độ khó: {difficulty}"
    )
    print(f"Câu hỏi: {question.content}")
    print(f"A. {question.option_a}")
    print(f"B. {question.option_b}")
    print(f"C. {question.option_c}")
    print(f"D. {question.option_d}")
    print(f"Đáp án đúng: {question.correct_answer}")

def show_all_questions():
    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi đang trống.")
        return

    print("\n========== DANH SÁCH CÂU HỎI ==========")
    index = 1

    for question in questions:
        display_question(question, index)
        index += 1

    print("-" * 72)
    print(f"Tổng số câu hỏi: {len(questions)}")

def input_difficulty():
    while True:
        print("1. Dễ")
        print("2. Khó")
        choice = input("Chọn độ khó: ").strip()

        if choice == "1":
            return "DE"

        if choice == "2":
            return "KHO"

        print("Lựa chọn không hợp lệ. Vui lòng nhập 1 hoặc 2.")

def input_correct_answer():
    while True:
        answer = input("Nhập đáp án đúng (A/B/C/D): ").strip().upper()

        if answer in ("A", "B", "C", "D"):
            return answer

        print("Đáp án chỉ được là A, B, C hoặc D.")

def add_question():
    questions = load_questions()
    question_id = next_question_id(questions)

    print("\n========== THÊM CÂU HỎI ==========")
    subject = input("Nhập môn/chủ đề: ").strip()
    difficulty = input_difficulty()
    content = input("Nhập nội dung câu hỏi: ").strip()
    option_a = input("Nhập phương án A: ").strip()
    option_b = input("Nhập phương án B: ").strip()
    option_c = input("Nhập phương án C: ").strip()
    option_d = input("Nhập phương án D: ").strip()
    correct_answer = input_correct_answer()

    new_question = Question(
        question_id,
        subject,
        difficulty,
        content,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_answer,
    )

    questions.append(new_question)
    save_questions(questions)
    print(f"Đã thêm câu hỏi có ID {question_id}.")

def find_question_index_by_id(questions, question_id):
    index = 0

    for question in questions:
        if question.question_id == question_id:
            return index
        index += 1

    return -1

def delete_question():
    questions = load_questions()

    if len(questions) == 0:
        print("Ngân hàng câu hỏi đang trống.")
        return

    question_id = int(input("Nhập ID câu hỏi cần xóa: ").strip())
    index = find_question_index_by_id(questions, question_id)

    if index == -1:
        print("Không tìm thấy câu hỏi có ID này.")
        return

    display_question(questions[index])

    confirm_delete = input("Bạn chắc chắn muốn xóa câu hỏi này? (Y/N): ").strip().upper()

    if confirm_delete != "Y":
        print("Đã hủy thao tác xóa.")
        return

    questions.remove_at(index)
    save_questions(questions)
    print("Đã xóa câu hỏi.")

def question_bank_menu():
    while True:
        print("\n========== QUẢN LÝ NGÂN HÀNG CÂU HỎI ==========")
        print("1. Xem toàn bộ câu hỏi")
        print("2. Thêm câu hỏi")
        print("3. Xóa câu hỏi")
        print("0. Quay lại menu chính")

        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_all_questions()
        elif choice == "2":
            add_question()
        elif choice == "3":
            delete_question()
        elif choice == "0":
            return
        else:
            print("Lựa chọn không hợp lệ.")
