import time
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

from modules.exam import (
    DIFFICULTY_ALL,
    calculate_exam_counts,
    collect_eligible_questions,
    generate_exam,
    get_unique_subjects,
    subject_list_to_text,
)
from modules.file_manager import (
    append_result,
    clear_results_file,
    ensure_data_files,
    load_questions,
    load_results,
    next_exam_id,
    next_question_id,
    save_questions,
)
from modules.linked_list import LinkedList
from modules.models import ExamResult, Question
from modules.text_utils import contains_text, format_seconds, normalize_spaces

class QuizApplication(tk.Tk):

    def __init__(self):
        super().__init__()

        ensure_data_files()

        self.title("Chương trình thi trắc nghiệm")
        self.geometry("1180x760")
        self.minsize(980, 650)
        self.protocol("WM_DELETE_WINDOW", self.handle_close)

        self.configure(bg="#f4f6f8")
        self.style = ttk.Style(self)
        self.configure_styles()

        self.current_screen = None
        self.timer_job = None
        self.exam_active = False
        self.exam_submitted = False

        self.subject_choices = LinkedList()
        self.question_buttons = LinkedList()
        self.exam_questions = LinkedList()
        self.current_question_index = 0
        self.selected_subjects = LinkedList()
        self.candidate_id = ""
        self.candidate_name = ""
        self.limit_seconds = 0
        self.exam_started_at = 0.0
        self.exam_deadline = 0.0
        self.last_result = None

        self.question_table = None
        self.question_detail = None
        self.result_table = None
        self.result_detail = None

        self.bind("<Key>", self.handle_exam_key)
        self.show_home_screen()

    def configure_styles(self):
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.style.configure("Title.TLabel", font=("Arial", 24, "bold"))
        self.style.configure("Heading.TLabel", font=("Arial", 17, "bold"))
        self.style.configure("Subheading.TLabel", font=("Arial", 12, "bold"))
        self.style.configure("Body.TLabel", font=("Arial", 11))
        self.style.configure("Large.TButton", font=("Arial", 12), padding=12)
        self.style.configure("Action.TButton", font=("Arial", 10, "bold"), padding=8)
        self.style.configure("Exam.TRadiobutton", font=("Arial", 12), padding=8)
        self.style.configure("Treeview", rowheight=28, font=("Arial", 10))
        self.style.configure("Treeview.Heading", font=("Arial", 10, "bold"))

    def handle_close(self):
        if self.exam_active and not self.exam_submitted:
            confirmed = messagebox.askyesno(
                "Thoát chương trình",
                "Bài thi đang diễn ra. Thoát lúc này sẽ không lưu kết quả.\n"
                "Bạn vẫn muốn thoát?",
                parent=self,
            )

            if not confirmed:
                return

        self.cancel_timer()
        self.destroy()

    def cancel_timer(self):
        if self.timer_job is not None:
            try:
                self.after_cancel(self.timer_job)
            except tk.TclError:
                pass

            self.timer_job = None

    def clear_screen(self):
        self.cancel_timer()

        for widget in self.winfo_children():
            widget.destroy()

        self.current_screen = None

    def create_page(self, title, subtitle=""):
        self.clear_screen()

        page = ttk.Frame(self, padding=22)
        page.pack(fill="both", expand=True)

        ttk.Label(page, text=title, style="Title.TLabel").pack(pady=(4, 4))

        if subtitle != "":
            ttk.Label(page, text=subtitle, style="Body.TLabel").pack(pady=(0, 18))
        else:
            ttk.Frame(page, height=12).pack()

        self.current_screen = page
        return page

    def show_home_screen(self):
        self.exam_active = False
        page = self.create_page(
            "CHƯƠNG TRÌNH THI TRẮC NGHIỆM",
            "Ứng dụng chạy local, dữ liệu được lưu trong thư mục DATA.",
        )

        questions = load_questions()
        results = load_results()

        summary = ttk.Frame(page)
        summary.pack(pady=(8, 26))

        ttk.Label(
            summary,
            text=f"Ngân hàng: {len(questions)} câu hỏi",
            style="Subheading.TLabel",
        ).grid(row=0, column=0, padx=24)

        ttk.Label(
            summary,
            text=f"Lịch sử: {len(results)} lần thi",
            style="Subheading.TLabel",
        ).grid(row=0, column=1, padx=24)

        menu_frame = ttk.Frame(page)
        menu_frame.pack(pady=10)

        ttk.Button(menu_frame, text="Quản lý ngân hàng câu hỏi", width=34, style="Large.TButton", command=self.show_question_bank_screen).pack(pady=8)

        ttk.Button(menu_frame, text="Cấu hình và làm bài thi", width=34, style="Large.TButton", command=self.show_exam_setup_screen).pack(pady=8)

        ttk.Button(menu_frame, text="Báo cáo kết quả nhiều lần thi", width=34, style="Large.TButton", command=self.show_results_screen).pack(pady=8)

        ttk.Button(menu_frame, text="Thoát chương trình", width=34, style="Large.TButton", command=self.handle_close).pack(pady=8)

    def show_question_bank_screen(self):
        page = self.create_page(
            "QUẢN LÝ NGÂN HÀNG CÂU HỎI",
            "Chọn một dòng để xem chi tiết. Chương trình hỗ trợ xem, thêm và xóa.",
        )

        toolbar = ttk.Frame(page)
        toolbar.pack(fill="x", pady=(0, 10))

        ttk.Button(toolbar, text="Thêm câu hỏi", style="Action.TButton", command=self.open_add_question_dialog).pack(side="left", padx=(0, 8))

        ttk.Button(toolbar, text="Xóa câu đã chọn", style="Action.TButton", command=self.delete_selected_question).pack(side="left", padx=8)

        ttk.Button(toolbar, text="Làm mới", command=self.refresh_question_table).pack(side="left", padx=8)

        ttk.Button(toolbar, text="Quay lại menu chính", command=self.show_home_screen).pack(side="right")

        content = ttk.Panedwindow(page, orient="vertical")
        content.pack(fill="both", expand=True)

        table_frame = ttk.Frame(content)
        detail_frame = ttk.LabelFrame(content, text="Chi tiết câu hỏi", padding=10)
        content.add(table_frame, weight=3)
        content.add(detail_frame, weight=2)

        columns = ("id", "subject", "difficulty", "content", "answer")
        self.question_table = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
        )

        self.question_table.heading("id", text="ID")
        self.question_table.heading("subject", text="Chủ đề")
        self.question_table.heading("difficulty", text="Độ khó")
        self.question_table.heading("content", text="Nội dung")
        self.question_table.heading("answer", text="Đáp án")

        self.question_table.column("id", width=55, anchor="center", stretch=False)
        self.question_table.column("subject", width=145, anchor="w")
        self.question_table.column("difficulty", width=85, anchor="center", stretch=False)
        self.question_table.column("content", width=650, anchor="w")
        self.question_table.column("answer", width=70, anchor="center", stretch=False)

        vertical_scroll = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.question_table.yview,
        )
        horizontal_scroll = ttk.Scrollbar(
            table_frame,
            orient="horizontal",
            command=self.question_table.xview,
        )

        self.question_table.configure(
            yscrollcommand=vertical_scroll.set,
            xscrollcommand=horizontal_scroll.set,
        )

        self.question_table.grid(row=0, column=0, sticky="nsew")
        vertical_scroll.grid(row=0, column=1, sticky="ns")
        horizontal_scroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        self.question_table.bind("<<TreeviewSelect>>", self.show_question_detail)

        self.question_detail = tk.Text(
            detail_frame,
            height=9,
            wrap="word",
            font=("Arial", 11),
            state="disabled",
        )
        self.question_detail.pack(fill="both", expand=True)

        self.refresh_question_table()

    def refresh_question_table(self):
        if self.question_table is None or not self.question_table.winfo_exists():
            return

        for item in self.question_table.get_children():
            self.question_table.delete(item)

        questions = load_questions()

        for question in questions:
            difficulty = "Dễ" if question.difficulty == "DE" else "Khó"
            self.question_table.insert(
                "",
                "end",
                values=(
                    question.question_id,
                    question.subject,
                    difficulty,
                    question.content,
                    question.correct_answer,
                ),
            )

        self.set_question_detail_text(
            f"Tổng số câu hỏi: {len(questions)}\n"
            "Hãy chọn một câu trong bảng để xem bốn phương án."
        )

    def set_question_detail_text(self, content):
        if self.question_detail is None or not self.question_detail.winfo_exists():
            return

        self.question_detail.configure(state="normal")
        self.question_detail.delete("1.0", "end")
        self.question_detail.insert("1.0", content)
        self.question_detail.configure(state="disabled")

    def show_question_detail(self, _event=None):
        selected = self.question_table.selection()

        if len(selected) == 0:
            return

        values = self.question_table.item(selected[0], "values")

        if len(values) == 0:
            return

        try:
            question_id = int(values[0])
        except (ValueError, TypeError):
            return

        questions = load_questions()

        for question in questions:
            if question.question_id == question_id:
                difficulty = "Dễ" if question.difficulty == "DE" else "Khó"
                detail = (
                    f"ID: {question.question_id}\n"
                    f"Chủ đề: {question.subject}\n"
                    f"Độ khó: {difficulty}\n\n"
                    f"Câu hỏi: {question.content}\n\n"
                    f"A. {question.option_a}\n"
                    f"B. {question.option_b}\n"
                    f"C. {question.option_c}\n"
                    f"D. {question.option_d}\n\n"
                    f"Đáp án đúng: {question.correct_answer}"
                )
                self.set_question_detail_text(detail)
                return

    def open_add_question_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("Thêm câu hỏi")
        dialog.geometry("720x650")
        dialog.minsize(650, 580)
        dialog.transient(self)
        dialog.grab_set()

        container = ttk.Frame(dialog, padding=18)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)

        ttk.Label(container, text="THÊM CÂU HỎI", style="Heading.TLabel").grid(
            row=0,
            column=0,
            columnspan=2,
            pady=(0, 18),
        )

        ttk.Label(container, text="Môn/chủ đề:").grid(
            row=1,
            column=0,
            sticky="w",
            padx=(0, 10),
            pady=6,
        )
        subject_entry = ttk.Entry(container)
        subject_entry.grid(row=1, column=1, sticky="ew", pady=6)

        ttk.Label(container, text="Độ khó:").grid(
            row=2,
            column=0,
            sticky="w",
            padx=(0, 10),
            pady=6,
        )
        difficulty_box = ttk.Combobox(
            container,
            values=("Dễ", "Khó"),
            state="readonly",
        )
        difficulty_box.current(0)
        difficulty_box.grid(row=2, column=1, sticky="ew", pady=6)

        ttk.Label(container, text="Nội dung:").grid(
            row=3,
            column=0,
            sticky="nw",
            padx=(0, 10),
            pady=6,
        )
        content_text = tk.Text(container, height=6, wrap="word", font=("Arial", 10))
        content_text.grid(row=3, column=1, sticky="nsew", pady=6)

        option_entries = LinkedList()
        row = 4
        key_code = ord("A")

        while key_code <= ord("D"):
            key = chr(key_code)
            ttk.Label(container, text=f"Phương án {key}:").grid(
                row=row,
                column=0,
                sticky="w",
                padx=(0, 10),
                pady=6,
            )
            entry = ttk.Entry(container)
            entry.grid(row=row, column=1, sticky="ew", pady=6)
            option_entries.append(entry)
            row += 1
            key_code += 1

        ttk.Label(container, text="Đáp án đúng:").grid(
            row=row,
            column=0,
            sticky="w",
            padx=(0, 10),
            pady=6,
        )
        answer_box = ttk.Combobox(
            container,
            values=("A", "B", "C", "D"),
            state="readonly",
        )
        answer_box.current(0)
        answer_box.grid(row=row, column=1, sticky="ew", pady=6)

        button_frame = ttk.Frame(container)
        button_frame.grid(row=row + 1, column=0, columnspan=2, pady=(20, 0))

        def save_new_question():
            subject = normalize_spaces(subject_entry.get())
            content = content_text.get("1.0", "end-1c").strip()

            if subject == "" or content == "":
                messagebox.showerror(
                    "Thiếu dữ liệu",
                    "Chủ đề và nội dung câu hỏi không được để trống.",
                    parent=dialog,
                )
                return

            option_values = LinkedList()

            for entry in option_entries:
                value = normalize_spaces(entry.get())

                if value == "":
                    messagebox.showerror(
                        "Thiếu dữ liệu",
                        "Cả bốn phương án đều phải có nội dung.",
                        parent=dialog,
                    )
                    return

                option_values.append(value)

            difficulty = "DE" if difficulty_box.get() == "Dễ" else "KHO"
            questions = load_questions()
            new_question = Question(
                next_question_id(questions),
                subject,
                difficulty,
                content,
                option_values[0],
                option_values[1],
                option_values[2],
                option_values[3],
                answer_box.get(),
            )

            questions.append(new_question)
            save_questions(questions)
            self.refresh_question_table()
            dialog.destroy()
            messagebox.showinfo(
                "Thành công",
                f"Đã thêm câu hỏi có ID {new_question.question_id}.",
                parent=self,
            )

        ttk.Button(button_frame, text="Lưu câu hỏi", style="Action.TButton", command=save_new_question).pack(side="left", padx=8)

        ttk.Button(button_frame, text="Hủy", command=dialog.destroy).pack(side="left", padx=8)

        container.rowconfigure(3, weight=1)
        subject_entry.focus_set()

    def delete_selected_question(self):
        selected = self.question_table.selection()

        if len(selected) == 0:
            messagebox.showwarning(
                "Chưa chọn câu hỏi",
                "Hãy chọn một câu hỏi trong bảng trước khi xóa.",
                parent=self,
            )
            return

        values = self.question_table.item(selected[0], "values")

        try:
            question_id = int(values[0])
        except (ValueError, TypeError, IndexError):
            messagebox.showerror("Lỗi", "Không đọc được ID câu hỏi.", parent=self)
            return

        confirmed = messagebox.askyesno(
            "Xác nhận xóa",
            f"Bạn chắc chắn muốn xóa câu hỏi có ID {question_id}?",
            parent=self,
        )

        if not confirmed:
            return

        questions = load_questions()
        index = 0
        found_index = -1

        for question in questions:
            if question.question_id == question_id:
                found_index = index
                break

            index += 1

        if found_index == -1:
            messagebox.showerror(
                "Không tìm thấy",
                "Câu hỏi không còn tồn tại trong file dữ liệu.",
                parent=self,
            )
            self.refresh_question_table()
            return

        questions.remove_at(found_index)
        save_questions(questions)
        self.refresh_question_table()
        messagebox.showinfo("Thành công", "Đã xóa câu hỏi.", parent=self)

    def show_exam_setup_screen(self):
        questions = load_questions()

        if len(questions) == 0:
            messagebox.showwarning(
                "Ngân hàng trống",
                "Hãy thêm câu hỏi trước khi tổ chức thi.",
                parent=self,
            )
            return

        page = self.create_page(
            "CẤU HÌNH BÀI THI",
            "Nhập thông tin thí sinh, chọn chủ đề, độ khó, số câu và thời gian.",
        )

        form = ttk.Frame(page)
        form.pack(fill="both", expand=True, padx=50)
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Mã thí sinh:", style="Subheading.TLabel").grid(
            row=0,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.candidate_id_entry = ttk.Entry(form, font=("Arial", 11))
        self.candidate_id_entry.grid(row=0, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Họ và tên:", style="Subheading.TLabel").grid(
            row=1,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.candidate_name_entry = ttk.Entry(form, font=("Arial", 11))
        self.candidate_name_entry.grid(row=1, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Chủ đề:", style="Subheading.TLabel").grid(
            row=2,
            column=0,
            sticky="nw",
            padx=(0, 15),
            pady=8,
        )

        subject_box = ttk.LabelFrame(form, text="Có thể chọn nhiều chủ đề", padding=10)
        subject_box.grid(row=2, column=1, sticky="ew", pady=8)

        self.subject_choices = LinkedList()
        available_subjects = get_unique_subjects(questions)
        subject_index = 0

        for subject in available_subjects:
            variable = tk.BooleanVar(value=True)
            self.subject_choices.append((subject, variable))

            ttk.Checkbutton(
                subject_box,
                text=subject,
                variable=variable,
                command=self.update_eligible_question_count,
            ).grid(
                row=subject_index // 3,
                column=subject_index % 3,
                sticky="w",
                padx=12,
                pady=5,
            )
            subject_index += 1

        ttk.Label(form, text="Độ khó:", style="Subheading.TLabel").grid(
            row=3,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.difficulty_box = ttk.Combobox(
            form,
            values=("Cả Dễ và Khó", "Chỉ câu Dễ", "Chỉ câu Khó"),
            state="readonly",
            font=("Arial", 11),
        )
        self.difficulty_box.current(0)
        self.difficulty_box.grid(row=3, column=1, sticky="ew", pady=8)
        self.difficulty_box.bind(
            "<<ComboboxSelected>>",
            lambda _event: self.update_eligible_question_count(),
        )

        ttk.Label(form, text="Số câu:", style="Subheading.TLabel").grid(
            row=4,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.question_count_entry = ttk.Entry(form, font=("Arial", 11))
        self.question_count_entry.insert(0, "10")
        self.question_count_entry.grid(row=4, column=1, sticky="ew", pady=8)

        ttk.Label(form, text="Thời gian (phút):", style="Subheading.TLabel").grid(
            row=5,
            column=0,
            sticky="w",
            padx=(0, 15),
            pady=8,
        )
        self.time_entry = ttk.Entry(form, font=("Arial", 11))
        self.time_entry.insert(0, "15")
        self.time_entry.grid(row=5, column=1, sticky="ew", pady=8)

        self.eligible_count_label = ttk.Label(
            form,
            text="",
            style="Subheading.TLabel",
        )
        self.eligible_count_label.grid(
            row=6,
            column=0,
            columnspan=2,
            pady=(18, 8),
        )

        button_frame = ttk.Frame(form)
        button_frame.grid(row=7, column=0, columnspan=2, pady=20)

        ttk.Button(button_frame, text="Bắt đầu làm bài", style="Large.TButton", command=self.begin_exam_from_setup).pack(side="left", padx=10)

        ttk.Button(button_frame, text="Quay lại", style="Large.TButton", command=self.show_home_screen).pack(side="left", padx=10)

        self.update_eligible_question_count()
        self.candidate_id_entry.focus_set()

    def get_selected_subjects_from_setup(self):
        selected_subjects = LinkedList()

        for choice in self.subject_choices:
            subject, variable = choice

            if variable.get():
                selected_subjects.append(subject)

        return selected_subjects

    def get_selected_difficulty_code(self):
        selected = self.difficulty_box.get()

        if selected == "Chỉ câu Dễ":
            return "DE"

        if selected == "Chỉ câu Khó":
            return "KHO"

        return DIFFICULTY_ALL

    def update_eligible_question_count(self):
        if not hasattr(self, "eligible_count_label"):
            return

        selected_subjects = self.get_selected_subjects_from_setup()

        if len(selected_subjects) == 0:
            self.eligible_count_label.configure(text="Chưa chọn chủ đề nào.")
            return

        eligible = collect_eligible_questions(
            load_questions(),
            selected_subjects,
            self.get_selected_difficulty_code(),
        )
        self.eligible_count_label.configure(
            text=f"Số câu phù hợp hiện có: {len(eligible)}"
        )

    def begin_exam_from_setup(self):
        candidate_id = normalize_spaces(self.candidate_id_entry.get())
        candidate_name = normalize_spaces(self.candidate_name_entry.get())

        if candidate_id == "" or candidate_name == "":
            messagebox.showerror(
                "Thiếu thông tin",
                "Mã thí sinh và họ tên không được để trống.",
                parent=self,
            )
            return

        selected_subjects = self.get_selected_subjects_from_setup()

        if len(selected_subjects) == 0:
            messagebox.showerror(
                "Chưa chọn chủ đề",
                "Hãy chọn ít nhất một chủ đề.",
                parent=self,
            )
            return

        try:
            number_of_questions = int(self.question_count_entry.get().strip())
            minutes = int(self.time_entry.get().strip())
        except ValueError:
            messagebox.showerror(
                "Dữ liệu không hợp lệ",
                "Số câu và thời gian phải là số nguyên.",
                parent=self,
            )
            return

        if number_of_questions < 1:
            messagebox.showerror(
                "Số câu không hợp lệ",
                "Số câu hỏi phải lớn hơn hoặc bằng 1.",
                parent=self,
            )
            return

        if minutes < 1 or minutes > 180:
            messagebox.showerror(
                "Thời gian không hợp lệ",
                "Thời gian phải nằm trong khoảng từ 1 đến 180 phút.",
                parent=self,
            )
            return

        difficulty = self.get_selected_difficulty_code()
        eligible = collect_eligible_questions(
            load_questions(),
            selected_subjects,
            difficulty,
        )

        if len(eligible) == 0:
            messagebox.showerror(
                "Không có câu hỏi",
                "Không có câu hỏi phù hợp với cấu hình đã chọn.",
                parent=self,
            )
            return

        if number_of_questions > len(eligible):
            messagebox.showerror(
                "Số câu vượt quá dữ liệu",
                f"Chỉ có {len(eligible)} câu phù hợp. Hãy nhập số nhỏ hơn.",
                parent=self,
            )
            return

        confirmed = messagebox.askyesno(
            "Bắt đầu bài thi",
            "Đề sẽ được sinh ngẫu nhiên và đồng hồ bắt đầu ngay.\n"
            "Bạn đã sẵn sàng?",
            parent=self,
        )

        if not confirmed:
            return

        self.candidate_id = candidate_id
        self.candidate_name = candidate_name
        self.selected_subjects = selected_subjects
        self.limit_seconds = minutes * 60
        self.exam_questions = generate_exam(
            eligible,
            number_of_questions,
        )
        self.current_question_index = 0
        self.exam_submitted = False
        self.exam_active = True
        self.exam_started_at = time.monotonic()
        self.exam_deadline = self.exam_started_at + self.limit_seconds
        self.show_exam_screen()

    def show_exam_screen(self):
        self.clear_screen()
        self.exam_active = True

        page = ttk.Frame(self, padding=14)
        page.pack(fill="both", expand=True)
        self.current_screen = page

        header = ttk.Frame(page)
        header.pack(fill="x", pady=(0, 10))

        candidate_text = f"{self.candidate_id} - {self.candidate_name}"
        ttk.Label(
            header,
            text=candidate_text,
            style="Subheading.TLabel",
        ).pack(side="left")

        self.timer_label = ttk.Label(
            header,
            text="",
            font=("Arial", 18, "bold"),
        )
        self.timer_label.pack(side="right")

        ttk.Separator(page, orient="horizontal").pack(fill="x", pady=(0, 10))

        body = ttk.Panedwindow(page, orient="horizontal")
        body.pack(fill="both", expand=True)

        navigation_frame = ttk.LabelFrame(
            body,
            text="Danh sách câu",
            padding=10,
        )
        question_frame = ttk.Frame(body, padding=(20, 8))
        body.add(navigation_frame, weight=1)
        body.add(question_frame, weight=4)

        canvas = tk.Canvas(navigation_frame, highlightthickness=0, width=210)
        scrollbar = ttk.Scrollbar(
            navigation_frame,
            orient="vertical",
            command=canvas.yview,
        )
        button_holder = ttk.Frame(canvas)
        holder_window = canvas.create_window((0, 0), window=button_holder, anchor="nw")

        button_holder.bind(
            "<Configure>",
            lambda _event: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.bind(
            "<Configure>",
            lambda event: canvas.itemconfigure(holder_window, width=event.width),
        )
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.question_buttons = LinkedList()
        index = 0

        while index < len(self.exam_questions):
            button = tk.Button(
                button_holder,
                text=str(index + 1),
                width=4,
                height=2,
                font=("Arial", 10, "bold"),
                command=lambda selected_index=index: self.go_to_question(selected_index),
            )
            button.grid(
                row=index // 4,
                column=index % 4,
                padx=4,
                pady=4,
                sticky="nsew",
            )
            self.question_buttons.append((index, button))
            index += 1

        row_index = 0
        while row_index < 4:
            button_holder.columnconfigure(row_index, weight=1)
            row_index += 1

        self.progress_label = ttk.Label(
            question_frame,
            text="",
            style="Subheading.TLabel",
        )
        self.progress_label.pack(anchor="w", pady=(0, 8))

        self.question_subject_label = ttk.Label(
            question_frame,
            text="",
            style="Body.TLabel",
        )
        self.question_subject_label.pack(anchor="w", pady=(0, 12))

        self.question_content_label = ttk.Label(
            question_frame,
            text="",
            font=("Arial", 15, "bold"),
            wraplength=760,
            justify="left",
        )
        self.question_content_label.pack(anchor="w", fill="x", pady=(0, 18))

        self.answer_variable = tk.StringVar(value="")
        self.option_buttons = LinkedList()
        option_keys = ("A", "B", "C", "D")

        for key in option_keys:
            option_button = ttk.Radiobutton(
                question_frame,
                text="",
                value=key,
                variable=self.answer_variable,
                command=self.record_selected_answer,
                style="Exam.TRadiobutton",
            )
            option_button.pack(anchor="w", fill="x", pady=4)
            self.option_buttons.append(option_button)

        self.answer_status_label = ttk.Label(
            question_frame,
            text="",
            style="Body.TLabel",
        )
        self.answer_status_label.pack(anchor="w", pady=(12, 8))

        control_frame = ttk.Frame(question_frame)
        control_frame.pack(side="bottom", fill="x", pady=(20, 5))

        ttk.Button(control_frame, text="← Câu trước", style="Action.TButton", command=self.previous_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Bỏ qua", style="Action.TButton", command=self.skip_current_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Câu tiếp →", style="Action.TButton", command=self.next_question).pack(side="left", padx=5)

        ttk.Button(control_frame, text="Nộp bài", style="Action.TButton", command=lambda: self.submit_exam(False)).pack(side="right", padx=5)

        ttk.Label(
            question_frame,
            text="Phím tắt: A/B/C/D chọn đáp án, ←/→ chuyển câu, S bỏ qua, Q nộp bài.",
            style="Body.TLabel",
        ).pack(side="bottom", anchor="w", pady=(8, 0))

        self.load_current_question()
        self.update_timer()

    def load_current_question(self):
        question = self.exam_questions[self.current_question_index]
        difficulty = "Dễ" if question.difficulty == "DE" else "Khó"

        self.progress_label.configure(
            text=(
                f"Câu {self.current_question_index + 1}/{len(self.exam_questions)}"
            )
        )
        self.question_subject_label.configure(
            text=f"Chủ đề: {question.subject} | Độ khó: {difficulty}"
        )
        self.question_content_label.configure(text=question.content)

        option_texts = LinkedList()
        option_texts.append(question.option_a)
        option_texts.append(question.option_b)
        option_texts.append(question.option_c)
        option_texts.append(question.option_d)

        index = 0

        for button in self.option_buttons:
            key = chr(ord("A") + index)
            button.configure(text=f"{key}. {option_texts[index]}")
            index += 1

        self.answer_variable.set(question.user_answer)

        if question.is_answered:
            self.answer_status_label.configure(
                text=f"Đáp án đã chọn: {question.user_answer}"
            )
        elif question.is_skipped:
            self.answer_status_label.configure(text="Trạng thái: đã đánh dấu bỏ qua")
        else:
            self.answer_status_label.configure(text="Trạng thái: chưa trả lời")

        self.update_question_button_styles()

    def record_selected_answer(self):
        if not self.exam_active:
            return

        answer = self.answer_variable.get()

        if answer == "":
            return

        question = self.exam_questions[self.current_question_index]
        question.user_answer = answer
        question.is_answered = True
        question.is_skipped = False
        self.answer_status_label.configure(text=f"Đáp án đã chọn: {answer}")
        self.update_question_button_styles()

    def update_question_button_styles(self):
        for item in self.question_buttons:
            index, button = item
            question = self.exam_questions[index]

            if index == self.current_question_index:
                background = "#2563eb"
                foreground = "white"
            elif question.is_answered:
                background = "#16a34a"
                foreground = "white"
            elif question.is_skipped:
                background = "#f59e0b"
                foreground = "black"
            else:
                background = "#e5e7eb"
                foreground = "black"

            button.configure(
                bg=background,
                fg=foreground,
                activebackground=background,
                activeforeground=foreground,
            )

    def go_to_question(self, index):
        if index < 0 or index >= len(self.exam_questions):
            return

        self.current_question_index = index
        self.load_current_question()

    def previous_question(self):
        if self.current_question_index > 0:
            self.current_question_index -= 1
            self.load_current_question()
        else:
            messagebox.showinfo("Thông báo", "Bạn đang ở câu đầu tiên.", parent=self)

    def next_question(self):
        if self.current_question_index < len(self.exam_questions) - 1:
            self.current_question_index += 1
            self.load_current_question()
        else:
            messagebox.showinfo("Thông báo", "Bạn đang ở câu cuối cùng.", parent=self)

    def skip_current_question(self):
        question = self.exam_questions[self.current_question_index]
        question.user_answer = ""
        question.is_answered = False
        question.is_skipped = True
        self.answer_variable.set("")
        self.update_question_button_styles()

        if self.current_question_index < len(self.exam_questions) - 1:
            self.current_question_index += 1

        self.load_current_question()

    def update_timer(self):
        if not self.exam_active or self.exam_submitted:
            return

        remaining = int(self.exam_deadline - time.monotonic())

        if remaining < 0:
            remaining = 0

        minutes = remaining // 60
        seconds = remaining % 60
        self.timer_label.configure(text=f"Còn lại: {minutes:02d}:{seconds:02d}")

        if remaining <= 0:
            self.submit_exam(True)
            return

        self.timer_job = self.after(250, self.update_timer)

    def submit_exam(self, auto_submit=False):
        if not self.exam_active or self.exam_submitted:
            return

        if not auto_submit:
            confirmed = messagebox.askyesno(
                "Xác nhận nộp bài",
                "Bạn chắc chắn muốn nộp bài?",
                parent=self,
            )

            if not confirmed:
                return

        self.exam_submitted = True
        self.exam_active = False
        self.cancel_timer()

        used_seconds = int(time.monotonic() - self.exam_started_at)

        if used_seconds > self.limit_seconds:
            used_seconds = self.limit_seconds

        counts = calculate_exam_counts(self.exam_questions)
        correct_count = counts[0]
        wrong_count = counts[1]
        skipped_count = counts[2]
        score_ten = correct_count * 10.0 / len(self.exam_questions)
        submit_status = (
            "Hết giờ - tự động thu bài"
            if auto_submit
            else "Nộp bài chủ động"
        )

        result = ExamResult(
            next_exam_id(load_results()),
            self.candidate_id,
            self.candidate_name,
            datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            subject_list_to_text(self.selected_subjects),
            len(self.exam_questions),
            correct_count,
            wrong_count,
            skipped_count,
            score_ten,
            self.limit_seconds,
            used_seconds,
            submit_status,
        )
        append_result(result)
        self.last_result = result

        if auto_submit:
            messagebox.showinfo(
                "Hết giờ",
                "Thời gian đã hết. Hệ thống đã tự động thu và chấm bài.",
                parent=self,
            )

        self.show_exam_result_screen()

    def handle_exam_key(self, event):
        if not self.exam_active or self.exam_submitted:
            return

        key = event.keysym.upper()

        if key == "A" or key == "B" or key == "C" or key == "D":
            self.answer_variable.set(key)
            self.record_selected_answer()
        elif key == "LEFT":
            self.previous_question()
        elif key == "RIGHT":
            self.next_question()
        elif key == "S":
            self.skip_current_question()
        elif key == "Q":
            self.submit_exam(False)

    def show_exam_result_screen(self):
        result = self.last_result
        page = self.create_page(
            "KẾT QUẢ BÀI THI",
            "Kết quả đã được lưu vào DATA/results.txt.",
        )

        card = ttk.LabelFrame(page, text=f"Lần thi {result.exam_id}", padding=24)
        card.pack(fill="x", padx=120, pady=20)
        card.columnconfigure(1, weight=1)

        rows = LinkedList()
        rows.append(("Thí sinh", f"{result.candidate_id} - {result.candidate_name}"))
        rows.append(("Chủ đề", result.subjects))
        rows.append(("Tổng số câu", str(result.total_questions)))
        rows.append(("Số câu đúng", str(result.correct_count)))
        rows.append(("Số câu sai", str(result.wrong_count)))
        rows.append(("Số câu bỏ qua", str(result.skipped_count)))
        rows.append(("Điểm hệ 10", f"{result.score_ten:.2f}"))
        rows.append(("Thời gian dùng", format_seconds(result.used_seconds)))
        rows.append(("Trạng thái", result.submit_status))

        row_number = 0

        for label_text, value_text in rows:
            ttk.Label(card, text=f"{label_text}:", style="Subheading.TLabel").grid(
                row=row_number,
                column=0,
                sticky="w",
                padx=(0, 25),
                pady=5,
            )
            ttk.Label(card, text=value_text, style="Body.TLabel").grid(
                row=row_number,
                column=1,
                sticky="w",
                pady=5,
            )
            row_number += 1

        button_frame = ttk.Frame(page)
        button_frame.pack(pady=16)

        ttk.Button(button_frame, text="Xem đáp án chi tiết", style="Large.TButton", command=self.show_exam_review_screen).pack(side="left", padx=8)

        ttk.Button(button_frame, text="Xem lịch sử kết quả", style="Large.TButton", command=self.show_results_screen).pack(side="left", padx=8)

        ttk.Button(button_frame, text="Về menu chính", style="Large.TButton", command=self.show_home_screen).pack(side="left", padx=8)

    def show_exam_review_screen(self):
        page = self.create_page(
            "ĐỐI CHIẾU ĐÁP ÁN",
            "Chọn một dòng để xem nội dung và bốn phương án chi tiết.",
        )

        toolbar = ttk.Frame(page)
        toolbar.pack(fill="x", pady=(0, 10))
        ttk.Button(toolbar, text="Quay lại kết quả", command=self.show_exam_result_screen).pack(side="right")

        content = ttk.Panedwindow(page, orient="vertical")
        content.pack(fill="both", expand=True)

        table_frame = ttk.Frame(content)
        detail_frame = ttk.LabelFrame(content, text="Chi tiết", padding=10)
        content.add(table_frame, weight=3)
        content.add(detail_frame, weight=2)

        review_table = ttk.Treeview(
            table_frame,
            columns=("number", "subject", "user", "correct", "status"),
            show="headings",
            selectmode="browse",
        )
        review_table.heading("number", text="Câu")
        review_table.heading("subject", text="Chủ đề")
        review_table.heading("user", text="Bạn chọn")
        review_table.heading("correct", text="Đáp án đúng")
        review_table.heading("status", text="Kết quả")
        review_table.column("number", width=60, anchor="center", stretch=False)
        review_table.column("subject", width=170)
        review_table.column("user", width=110, anchor="center")
        review_table.column("correct", width=110, anchor="center")
        review_table.column("status", width=110, anchor="center")

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=review_table.yview)
        review_table.configure(yscrollcommand=scroll.set)
        review_table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        detail_text = tk.Text(
            detail_frame,
            height=10,
            wrap="word",
            font=("Arial", 11),
            state="disabled",
        )
        detail_text.pack(fill="both", expand=True)

        index = 0

        for question in self.exam_questions:
            if question.user_answer == "":
                user_answer = "Bỏ qua"
                status = "BỎ QUA"
            elif question.user_answer == question.correct_answer:
                user_answer = question.user_answer
                status = "ĐÚNG"
            else:
                user_answer = question.user_answer
                status = "SAI"

            review_table.insert(
                "",
                "end",
                iid=str(index),
                values=(
                    index + 1,
                    question.subject,
                    user_answer,
                    question.correct_answer,
                    status,
                ),
            )
            index += 1

        def show_review_detail(_event=None):
            selected = review_table.selection()

            if len(selected) == 0:
                return

            try:
                selected_index = int(selected[0])
            except ValueError:
                return

            question = self.exam_questions[selected_index]
            user_answer = question.user_answer if question.user_answer != "" else "Bỏ qua"
            detail = (
                f"Câu {selected_index + 1}: {question.content}\n\n"
                f"A. {question.option_a}\n"
                f"B. {question.option_b}\n"
                f"C. {question.option_c}\n"
                f"D. {question.option_d}\n\n"
                f"Bạn chọn: {user_answer}\n"
                f"Đáp án đúng: {question.correct_answer}"
            )
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", detail)
            detail_text.configure(state="disabled")

        review_table.bind("<<TreeviewSelect>>", show_review_detail)

        if len(self.exam_questions) > 0:
            review_table.selection_set("0")
            review_table.focus("0")
            show_review_detail()

    def show_results_screen(self):
        self.exam_active = False
        page = self.create_page(
            "BÁO CÁO KẾT QUẢ",
            "Có thể tìm theo mã hoặc tên thí sinh và xem chi tiết từng lần thi.",
        )

        toolbar = ttk.Frame(page)
        toolbar.pack(fill="x", pady=(0, 10))

        ttk.Label(toolbar, text="Từ khóa:").pack(side="left")
        self.result_search_entry = ttk.Entry(toolbar, width=30)
        self.result_search_entry.pack(side="left", padx=8)
        self.result_search_entry.bind(
            "<Return>",
            lambda _event: self.search_result_records(),
        )

        ttk.Button(toolbar, text="Tìm kiếm", command=self.search_result_records).pack(side="left", padx=4)

        ttk.Button(toolbar, text="Xem tất cả", command=self.refresh_result_table).pack(side="left", padx=4)

        ttk.Button(toolbar, text="Xóa toàn bộ lịch sử", command=self.clear_all_results).pack(side="left", padx=12)

        ttk.Button(toolbar, text="Quay lại menu chính", command=self.show_home_screen).pack(side="right")

        content = ttk.Panedwindow(page, orient="vertical")
        content.pack(fill="both", expand=True)

        table_frame = ttk.Frame(content)
        detail_frame = ttk.LabelFrame(content, text="Chi tiết lần thi", padding=10)
        content.add(table_frame, weight=3)
        content.add(detail_frame, weight=2)

        columns = (
            "exam_id",
            "candidate_id",
            "name",
            "time",
            "subjects",
            "score",
            "correct",
            "wrong",
            "skipped",
            "used",
            "status",
        )
        self.result_table = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
        )

        headings = (
            ("exam_id", "Lần"),
            ("candidate_id", "Mã TS"),
            ("name", "Họ tên"),
            ("time", "Thời điểm"),
            ("subjects", "Chủ đề"),
            ("score", "Điểm"),
            ("correct", "Đúng"),
            ("wrong", "Sai"),
            ("skipped", "Bỏ qua"),
            ("used", "Thời gian"),
            ("status", "Trạng thái"),
        )

        for key, title in headings:
            self.result_table.heading(key, text=title)

        self.result_table.column("exam_id", width=55, anchor="center", stretch=False)
        self.result_table.column("candidate_id", width=95, anchor="center")
        self.result_table.column("name", width=170)
        self.result_table.column("time", width=150)
        self.result_table.column("subjects", width=190)
        self.result_table.column("score", width=70, anchor="center")
        self.result_table.column("correct", width=60, anchor="center")
        self.result_table.column("wrong", width=60, anchor="center")
        self.result_table.column("skipped", width=70, anchor="center")
        self.result_table.column("used", width=105, anchor="center")
        self.result_table.column("status", width=190)

        vertical_scroll = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.result_table.yview,
        )
        horizontal_scroll = ttk.Scrollbar(
            table_frame,
            orient="horizontal",
            command=self.result_table.xview,
        )
        self.result_table.configure(
            yscrollcommand=vertical_scroll.set,
            xscrollcommand=horizontal_scroll.set,
        )
        self.result_table.grid(row=0, column=0, sticky="nsew")
        vertical_scroll.grid(row=0, column=1, sticky="ns")
        horizontal_scroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        self.result_table.bind("<<TreeviewSelect>>", self.show_result_detail)

        self.result_detail = tk.Text(
            detail_frame,
            height=9,
            wrap="word",
            font=("Arial", 11),
            state="disabled",
        )
        self.result_detail.pack(fill="both", expand=True)

        self.current_result_records = LinkedList()
        self.refresh_result_table()

    def set_result_detail_text(self, content):
        if self.result_detail is None or not self.result_detail.winfo_exists():
            return

        self.result_detail.configure(state="normal")
        self.result_detail.delete("1.0", "end")
        self.result_detail.insert("1.0", content)
        self.result_detail.configure(state="disabled")

    def refresh_result_table(self, records=None):
        if self.result_table is None or not self.result_table.winfo_exists():
            return

        if records is None:
            records = load_results()

        self.current_result_records = records

        for item in self.result_table.get_children():
            self.result_table.delete(item)

        for result in records:
            self.result_table.insert(
                "",
                "end",
                iid=str(result.exam_id),
                values=(
                    result.exam_id,
                    result.candidate_id,
                    result.candidate_name,
                    result.exam_time_text,
                    result.subjects,
                    f"{result.score_ten:.2f}",
                    result.correct_count,
                    result.wrong_count,
                    result.skipped_count,
                    format_seconds(result.used_seconds),
                    result.submit_status,
                ),
            )

        self.set_result_detail_text(f"Tổng số kết quả đang hiển thị: {len(records)}")

    def search_result_records(self):
        keyword = normalize_spaces(self.result_search_entry.get())

        if keyword == "":
            self.refresh_result_table()
            return

        matched = LinkedList()

        for result in load_results():
            if contains_text(result.candidate_id, keyword) or contains_text(
                result.candidate_name,
                keyword,
            ):
                matched.append(result)

        self.refresh_result_table(matched)

        if len(matched) == 0:
            messagebox.showinfo(
                "Không tìm thấy",
                "Không có kết quả phù hợp với từ khóa.",
                parent=self,
            )

    def find_result_by_exam_id(self, exam_id):
        for result in self.current_result_records:
            if result.exam_id == exam_id:
                return result

        return None

    def show_result_detail(self, _event=None):
        selected = self.result_table.selection()

        if len(selected) == 0:
            return

        try:
            exam_id = int(selected[0])
        except ValueError:
            return

        result = self.find_result_by_exam_id(exam_id)

        if result is None:
            return

        detail = (
            f"Mã lần thi: {result.exam_id}\n"
            f"Mã thí sinh: {result.candidate_id}\n"
            f"Họ và tên: {result.candidate_name}\n"
            f"Thời điểm: {result.exam_time_text}\n"
            f"Chủ đề: {result.subjects}\n\n"
            f"Tổng số câu: {result.total_questions}\n"
            f"Đúng/Sai/Bỏ qua: "
            f"{result.correct_count}/{result.wrong_count}/{result.skipped_count}\n"
            f"Điểm hệ 10: {result.score_ten:.2f}\n"
            f"Thời gian quy định: {format_seconds(result.limit_seconds)}\n"
            f"Thời gian đã dùng: {format_seconds(result.used_seconds)}\n"
            f"Trạng thái nộp bài: {result.submit_status}"
        )
        self.set_result_detail_text(detail)

    def clear_all_results(self):
        confirmed = messagebox.askyesno(
            "Xóa lịch sử",
            "Bạn chắc chắn muốn xóa toàn bộ lịch sử kết quả?",
            parent=self,
        )

        if not confirmed:
            return

        clear_results_file()
        self.refresh_result_table()
        messagebox.showinfo(
            "Thành công",
            "Đã xóa toàn bộ lịch sử kết quả.",
            parent=self,
        )

if __name__ == "__main__":
    app = QuizApplication()
    app.mainloop()
