def clear_results():

    '''
    Hàm dùng để:
    - xóa toàn bộ lịch sử kết quả
    '''

    with open(
        "DATA/results.txt",
        "w",
        encoding="utf-8"
    ) as f:

        f.write("")

    print()
    print("Đã xóa toàn bộ lịch sử!")


def show_results():

    '''
    Hàm dùng để:
    - đọc lịch sử làm bài
    - hiển thị kết quả

    Dùng str.split("\n") thay vì readlines() (trả về list)
    rồi duyệt bằng dict index
    '''

    try:

        with open(
            "DATA/results.txt",
            "r",
            encoding="utf-8"
        ) as f:

            # Đọc toàn bộ nội dung dưới dạng str, không dùng readlines()
            raw_content = f.read()

    except FileNotFoundError:

        print()
        print("Chưa có file kết quả!")

        return

    print()
    print("===== KẾT QUẢ =====")

    # Tách từng dòng bằng "\n" -> nhận được str thô
    # rồi lưu vào dict thay vì list
    # key: thứ tự (0, 1, ...)  |  value: nội dung dòng

    results_dict = {}
    count = 0

    start = 0
    length = len(raw_content)

    # Tự duyệt chuỗi để tách dòng, không dùng split() trả về list
    for i in range(length + 1):

        if i == length or raw_content[i] == "\n":

            line = raw_content[start:i].strip()

            if line != "":  # bỏ qua dòng trống
                results_dict[count] = line
                count += 1

            start = i + 1

    # Nếu không có kết quả nào
    if count == 0:

        print("Bạn chưa làm bài thi nào.")
        return

    # In từng kết quả
    for i in range(count):

        print(
            f"Lần thi {i + 1}: "
            f"{results_dict[i]}"
        )


def save_result(
    score,
    exam_questions,
    total_time
):

    '''
    Hàm dùng để:
    - lưu kết quả bài thi
    - lưu thời gian làm bài
    '''

    minutes = int(
        total_time // 60
    )

    seconds = int(
        total_time % 60
    )

    with open(
        "DATA/results.txt",
        "a",
        encoding="utf-8"
    ) as f:

        f.write(
            f"Điểm: "
            f"{score}/{len(exam_questions)} | "
            f"Thời gian: "
            f"{minutes} phút "
            f"{seconds} giây\n"
        )
