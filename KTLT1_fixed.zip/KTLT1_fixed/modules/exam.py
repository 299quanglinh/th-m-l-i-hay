import json
import random
import time

from modules.results import save_result


def choose_topics():

    '''
    Hàm dùng để:
    - hiển thị danh sách topic
    - nhận input từ user
    - chuyển lựa chọn thành tên file topic

    Ví dụ:
    User nhập:
    1 3

    Hàm sẽ trả về dict:
    {0: "daoham", 1: "tichphan"}
    '''

    print()
    print("===== CHỌN TOPIC =====")
    print("1. Đạo hàm")
    print("2. Nguyên hàm")
    print("3. Tích phân")

    topic_map = {
        "1": "daoham",
        "2": "nguyenham",
        "3": "tichphan"
    }

    topic_input = input(
        "Nhập topic muốn làm: "
    )

    topic_choices = topic_input.split()

    # Dùng dict thay cho list để lưu các topic đã chọn
    # key: thứ tự (0, 1, 2, ...)  |  value: tên topic
    selected_topics = {}
    count = 0

    for choice in topic_choices:

        if choice in topic_map:

            selected_topics[count] = topic_map[choice]
            count += 1

    return selected_topics


def shuffle_options(question):

    '''
    Hàm dùng để:
    - đảo vị trí đáp án A B C D
    - cập nhật lại correct_answer

    Thuật toán shuffle (Fisher-Yates) không dùng list:
    - dùng dict với key "0","1","2","3" làm mảng tạm
    - random vị trí rồi swap
    '''

    options = question["options"]
    correct_answer = question["correct_answer"]
    correct_value = options[correct_answer]

    # Chuyển dict options sang dict tạm dùng index số nguyên
    # thay vì list(options.items())
    option_keys = {}    # {0: "A", 1: "B", 2: "C", 3: "D"}
    option_vals = {}    # {0: "...", 1: "...", 2: "...", 3: "..."}

    i = 0
    for k, v in options.items():
        option_keys[i] = k
        option_vals[i] = v
        i += 1

    size = i  # = 4

    # Thuật toán Fisher-Yates shuffle trên dict
    for idx in range(size):

        random_index = random.randint(0, size - 1)

        # Swap option_vals tại idx và random_index
        option_vals[idx], option_vals[random_index] = (
            option_vals[random_index],
            option_vals[idx]
        )

    new_keys = {0: "A", 1: "B", 2: "C", 3: "D"}

    new_options = {}

    for idx in range(size):

        new_options[new_keys[idx]] = option_vals[idx]

        # Nếu value hiện tại là đáp án đúng
        # thì cập nhật correct_answer mới
        if option_vals[idx] == correct_value:

            question["correct_answer"] = new_keys[idx]

    question["options"] = new_options

    return question


def shuffle_questions(exam_questions):

    '''
    Hàm dùng để:
    - đảo toàn bộ thứ tự câu hỏi trong dict exam_questions

    Thuật toán Fisher-Yates shuffle trên dict:
    key là index 0..n-1, swap value giữa 2 vị trí ngẫu nhiên
    '''

    size = len(exam_questions)

    for i in range(size):

        random_index = random.randint(0, size - 1)

        exam_questions[i], exam_questions[random_index] = (
            exam_questions[random_index],
            exam_questions[i]
        )

    return exam_questions


def load_questions(selected_topics):

    '''
    Hàm dùng để:
    - đọc file json
    - random câu hỏi
    - shuffle đáp án
    - thêm vào exam_questions (dict)
    - shuffle toàn bộ đề
    '''

    # Dùng dict thay cho list để lưu câu hỏi
    # key: thứ tự (0, 1, 2, ...)  |  value: câu hỏi
    exam_questions = {}
    exam_count = 0

    for i in range(len(selected_topics)):

        topic = selected_topics[i]

        number_of_questions = int(
            input(
                f"Bạn muốn làm bao nhiêu câu {topic}: "
            )
        )

        path = f"DATA/{topic}.json"

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            questions = json.load(f)

        # Dùng dict thay cho list để chống random trùng
        # key: index đã chọn  |  value: True
        selected_indexes = {}

        while len(selected_indexes) < number_of_questions:

            random_index = random.randint(
                0,
                len(questions) - 1
            )

            if random_index not in selected_indexes:

                selected_indexes[random_index] = True

                question = shuffle_options(
                    questions[random_index]
                )

                question["user_answer"] = None
                question["is_answered"] = False
                question["is_skipped"] = False

                exam_questions[exam_count] = question
                exam_count += 1

    # Shuffle toàn bộ đề
    shuffle_questions(exam_questions)

    return exam_questions


def choose_time():

    '''
    Hàm dùng để:
    - nhận thời gian từ user
    - đổi phút sang giây
    '''

    exam_time = int(
        input(
            "Nhập thời gian làm bài (phút): "
        )
    )

    exam_time_seconds = exam_time * 60

    return exam_time_seconds


def calculate_score(exam_questions):

    '''
    Hàm dùng để:
    - chấm điểm cuối bài
    '''

    score = 0

    for i in range(len(exam_questions)):

        q = exam_questions[i]

        if q["user_answer"] == q["correct_answer"]:

            score += 1

    return score


def show_question_list(exam_questions, current_index):

    print()
    print("===== DANH SÁCH CÂU HỎI =====")

    status_line = ""

    for i in range(len(exam_questions)):

        q = exam_questions[i]
        num = i + 1

        if q["is_answered"]:
            symbol = "✓"
        elif q["is_skipped"]:
            symbol = "✗"
        else:
            symbol = "•"

        if i == current_index:
            status_line += f"[{num}{symbol}] "
        else:
            status_line += f" {num}{symbol}  "

    print(status_line.strip())


def run_exam(exam_questions, exam_time):

    start_time = time.time()
    current_index = 0

    while True:

        elapsed_time = time.time() - start_time

        if elapsed_time >= exam_time:
            print()
            print("Hết giờ làm bài!")
            break

        # ── Hiện danh sách trạng thái ─────────────────────────────────
        show_question_list(exam_questions, current_index)

        q = exam_questions[current_index]

        # ── Hiện câu hỏi ──────────────────────────────────────────────
        print()
        print(f"─── Câu {current_index + 1} / {len(exam_questions)} ───")
        print(q["question"])

        for key, value in q["options"].items():
            print(key + ":", value)

        if q["is_answered"]:
            print(f"(Đã chọn: {q['user_answer']})")

        remaining = int(exam_time - elapsed_time)
        print(f"[Còn {remaining // 60}p {remaining % 60}s]")

        user_input = input(
            "Đáp án (A/B/C/D) | N=tiếp | P=trước | Gn = Làm câu thứ n | S=bỏ qua | Q=nộp bài: "
        ).strip().upper()

        # ── Xử lý input ───────────────────────────────────────────────

        if user_input == "Q":
            print()
            print("Nộp bài!")
            break

        elif user_input == "N":
            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("→ Đây là câu cuối cùng.")

        elif user_input == "P":
            if current_index > 0:
                current_index -= 1
            else:
                print("→ Đây là câu đầu tiên.")

        elif user_input == "S":
            q["is_answered"] = False
            q["user_answer"] = None
            q["is_skipped"] = True
            print("→ Đã bỏ qua.")
            if current_index < len(exam_questions) - 1:
                current_index += 1

        elif user_input.startswith("G"):
            try:
                target = int(user_input[1:]) - 1
                if 0 <= target < len(exam_questions):
                    current_index = target
                else:
                    print(f"→ Chỉ có {len(exam_questions)} câu thôi!")
            except ValueError:
                print("→ Cú pháp: G<số>, ví dụ G4 để nhảy câu 4.")

        elif user_input in ["A", "B", "C", "D"]:
            q["user_answer"] = user_input
            q["is_answered"] = True
            q["is_skipped"] = False

            if current_index < len(exam_questions) - 1:
                current_index += 1
            else:
                print("→ Câu cuối. Nhập Q để nộp bài.")

        else:
            print("→ Không hợp lệ.")

    # ── Tính thời gian & điểm ─────────────────────────────────────────
    finish_time = time.time()
    total_time = min(finish_time - start_time, exam_time)

    minutes = int(total_time // 60)
    seconds = int(total_time % 60)

    print()

    if total_time >= 60:
        print(f"Bạn đã làm bài được {minutes} phút {seconds} giây")
    else:
        print(f"Bạn đã làm bài được {seconds} giây")

    print()

    score = calculate_score(exam_questions)
    print("Tổng điểm:", score, "/", len(exam_questions))

    save_result(score, exam_questions, total_time)


def start_exam():

    '''
    Hàm điều khiển toàn bộ flow chương trình.

    Flow:
    chọn topic
        ↓
    load câu hỏi
        ↓
    chọn thời gian
        ↓
    chạy bài thi
    '''

    selected_topics = choose_topics()

    exam_questions = load_questions(
        selected_topics
    )

    exam_time = choose_time()

    run_exam(
        exam_questions,
        exam_time
    )
